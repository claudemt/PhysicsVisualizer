# 刚体转动 MATLAB GUI（重写版）

## 这套代码解决什么问题

这一版不再把自由刚体的 `omega(t)` 交给普通数值积分去“猜”，而是：

1. **自由转动**：按讲义里的三种分支  
   `L^2 < 2 E I2`、`L^2 > 2 E I2`、`L^2 = 2 E I2`  
   分别使用 **Jacobi 椭圆函数** / **双曲函数** 写出解析解，并通过相位拟合匹配任意输入的 `omega(0)`。

2. **临界附近 + 阻尼**：用  
   `tau_d = -(c1 + c2 |omega|) omega`  
   扫描分离曲线附近的初值，直接看系统最终落入哪条稳定分支。

3. **旋转对称刚体在重力/磁场中的定点转动**：使用  
   `p_phi, p_psi` 守恒 + `U_eff(theta)`  
   的约化方法，而不是直接画一堆难懂的欧拉角方程。

---

## 文件结构

- `rigid_body_gui.m`：主 GUI
- `start_rigid_body_demo.m`：一键启动
- `rb_simulate_free_exact.m`：自由转动解析解
- `rb_simulate_branch_scan.m`：阻尼分支扫描
- `rb_simulate_top_fixed.m`：定点对称陀螺
- `rb_free_rhs_damped.m`：含阻尼欧拉方程
- `rb_plot_free.m` / `rb_plot_branch.m` / `rb_plot_top.m`：绘图
- `rb_passive_rotm_313x.m`：按讲义定义的欧拉角变换矩阵
- `rb_effective_potential.m`：`U_eff(theta)`
- `rb_presets.m`：示例参数
- `rb_parse_vector.m`：参数字符串解析
- `rb_play_animation.m`：动画

---

## 启动方式

```matlab
cd('rigid_body_matlab_exact_gui')
rigid_body_gui
```

或者：

```matlab
cd('rigid_body_matlab_exact_gui')
start_rigid_body_demo
```

---

## GUI 的三个模式

### 1. 自由转动（解析）

输入：

- `I = [I1 I2 I3]`，要求 `I1 <= I2 <= I3`
- `omega(0) = [w1 w2 w3]`
- `phi(0)`
- `tEnd`
- `nSamples`

输出 4 幅图：

- `omega1, omega2, omega3`
- 欧拉角 `theta, psi, phi`
- `omega` 空间中的 polhode（能量椭球与角动量椭球交线）
- `L` 在体坐标中的轨迹（单位球面）

### 2. 阻尼分支扫描

输入：

- `I = [I1 I2 I3]`
- `omega_spin`：中间轴附近的参考转速
- `epsSep`：离分离曲线有多近
- `[deltaMin deltaMax nScan inspect]`
- `[c1 c2]`
- `[tEnd nSamples]`

说明：

- `delta = 0` 对应你想强调的“临界附近”参考关系；
- `delta > 0` 与 `delta < 0` 会在阻尼作用下落向不同分支；
- `inspect` 决定下面 3 幅图里显示哪一条具体轨道。

### 3. 定点对称陀螺

输入：

- `[I1 I3]`
- `[M g a]`
- `[Q B]`，内部用 `Omega = Q B / (2 M)`
- `steady` 行：`[theta0 phiDot0 dTheta phi0 psi0]`
- `general` 行：`[theta0 phi0 psi0 thetaDot0 phiDot0 psiDot0]`
- `tEnd`
- `nSamples`

其中：

- 子模式 `steady`：用讲义的稳态进动公式自动求 `psiDot0` 与 `omega_p`
- 子模式 `general`：直接输入一般初值

输出 4 幅图：

- `theta(t)`，稳态模式下会叠加线性近似
- `U_eff(theta)` 与常量 `H`
- 对称轴在空间中的轨迹
- `phiDot(t), psiDot(t)`

---

## 建议先跑的预设

### 自由转动
- `网球拍定理：中间轴附近翻转`

### 阻尼分支
- `临界附近：线性阻尼`
- `临界附近：二次阻尼`

### 定点陀螺
- `讲义例 1（含磁场，稳态附近）`

这一组已经按讲义例 1 的无量纲参数归一化，应该看到：

- `psiDot0 / Omega ≈ 1.926`
- `omega_p / Omega ≈ 8.640`

---

## 物理上应该怎么看图

### 自由转动页
先看：

1. `omega_i(t)`  
2. `L` 在体坐标球面上的轨迹  
3. `polhode`

让学生先理解：

- 它不是“乱摆”，而是在两个守恒约束之下沿交线运动；
- 中间轴不稳定，不是口头说说，而是因为轨道被 separatrix 分开了。

### 阻尼分支页
核心是第四张图：

- 横轴：离临界值有多远
- 纵轴：最终落入轴 1 / 轴 3

这样学生会很直观地看到：  
**同一套动力学方程，在临界附近会分裂成不同结局。**

### 定点陀螺页
不要先讲欧拉角公式，先讲：

- `U_eff(theta)` 的谷底在哪；
- 为什么稳态进动对应 `U_eff` 的平衡点；
- 为什么小扰动会变成章动；
- 为什么 `omega_p` 可以同时从公式和数值曲线两边读出来。

---

## 一个重要说明

定点陀螺部分的 `theta` 方程，代码没有直接照抄最容易被 OCR / 排版误读的那一行，而是**从讲义给出的哈密顿量重新求 `-dU_eff/dtheta`** 来实现。  
这样做的原因是：只要 `H`、`p_phi`、`p_psi` 的表达式是对的，那么 `theta` 的动力学和小振动频率 `omega_p` 就会自动自洽。

---

## 兼容性

这套 GUI 使用了 `uifigure + uigridlayout + uidropdown + uiaxes`。  
建议 MATLAB 版本不要太老；较新的版本效果最好。

如果你只想要数值结果，不想用 GUI，也可以直接在命令行里调用：

```matlab
p.I = [1 2 3];
p.w0 = [0.18 1.65 0.12];
p.phi0 = 0;
p.tEnd = 20;
p.nSamples = 2000;
res = rb_simulate_free_exact(p);
```

或者：

```matlab
p.submode = 'steady';
p.I = [1 1/3];
p.M = 1; p.g = 7/12; p.a = 1;
p.Q = 2; p.B = 1;
p.steady = [1.47 7.684 0.02 0 0];
p.general = [1.47 0 0 0 7.684 1.9260128];
p.tEnd = 10;
p.nSamples = 3000;
res = rb_simulate_top_fixed(p);
```
