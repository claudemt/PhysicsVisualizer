function out = rb_simulate_top_fixed(p)
%RB_SIMULATE_TOP_FIXED Symmetric top with a fixed point under gravity / magnetic field.

I1 = p.I(1);
I3 = p.I(2);

if I1 <= 0 || I3 <= 0
    error('I1, I3 必须为正。');
end
if p.M <= 0
    error('质量 M 必须为正。');
end

Mga = p.M * p.g * p.a;
Omega = p.Q * p.B / (2 * p.M);

submode = lower(strtrim(p.submode));

switch submode
    case 'steady'
        thetaEq = p.steady(1);
        phiDotEq = p.steady(2);
        deltaTheta = p.steady(3);
        phi0 = p.steady(4);
        psi0 = p.steady(5);

        if abs(Omega) < 1.0e-12
            if abs(phiDotEq) < 1.0e-12
                error('Omega = 0 时，稳态模式下 phiDot0 不能太小。');
            end
            psiDotEq = Mga / (I3 * phiDotEq) - ((I3 - I1) / I3) * phiDotEq * cos(thetaEq);
            omegaP = sqrt(max(phiDotEq^2 - 2 * Mga * cos(thetaEq) / I1 + (Mga / (I1 * phiDotEq))^2, 0));
        else
            denom = phiDotEq + Omega;
            if abs(denom) < 1.0e-12
                error('稳态模式下 phiDot0 + Omega 不能接近 0。');
            end

            psiDotEq = Mga / (I3 * denom) ...
                - (((denom)^2 - Omega^2) * (I3 - I1) * cos(thetaEq)) / (I3 * denom);

            alpha = Mga / (I1 * Omega^2);
            beta = phiDotEq / Omega;
            gamma = I3 / I1;

            omegaP2 = alpha^2 / (1 + beta)^2 ...
                - 2 * alpha * cos(thetaEq) ...
                + (1 + beta)^2 ...
                + (gamma - 1) * (2 * alpha * cos(thetaEq) / (1 + beta)^2 - 3 * cos(thetaEq)^2 + 1) ...
                + (cos(thetaEq)^2 / (1 + beta)^2) * (gamma - 1)^2;

            omegaP = abs(Omega) * sqrt(max(omegaP2, 0));
        end

        pPsi = I3 * (psiDotEq + (phiDotEq + Omega) * cos(thetaEq));
        pPhi = pPsi * cos(thetaEq) + I1 * (phiDotEq + Omega) * sin(thetaEq)^2;

        y0 = [thetaEq + deltaTheta; 0; phi0; psi0];
        predictedThetaFcn = @(t) thetaEq + deltaTheta * cos(omegaP * t);
        phiDot0Shown = phiDotEq;
        psiDot0Shown = psiDotEq;

    case 'general'
        theta0 = p.general(1);
        phi0 = p.general(2);
        psi0 = p.general(3);
        thetaDot0 = p.general(4);
        phiDot0 = p.general(5);
        psiDot0 = p.general(6);

        pPsi = I3 * (psiDot0 + (phiDot0 + Omega) * cos(theta0));
        pPhi = pPsi * cos(theta0) + I1 * (phiDot0 + Omega) * sin(theta0)^2;

        y0 = [theta0; I1 * thetaDot0; phi0; psi0];
        predictedThetaFcn = [];
        omegaP = NaN;
        thetaEq = NaN;
        phiDot0Shown = phiDot0;
        psiDot0Shown = psiDot0;

    otherwise
        error('未知 top 子模式: %s', p.submode);
end

opts = odeset( ...
    'RelTol', 1.0e-10, ...
    'AbsTol', 1.0e-12, ...
    'MaxStep', max(p.tEnd / max(p.nSamples, 250), 1.0e-4));

sol = ode113(@(t, y) local_top_rhs(t, y, I1, I3, Mga, Omega, pPhi, pPsi), [0, p.tEnd], y0, opts);

t = linspace(0, p.tEnd, p.nSamples).';
Y = deval(sol, t).';

theta = Y(:, 1);
pTheta = Y(:, 2);
phi = unwrap(Y(:, 3));
psi = unwrap(Y(:, 4));

s = sin(theta);
c = cos(theta);
sSafe2 = max(s.^2, 1.0e-12);

thetaDot = pTheta / I1;
phiDot = (pPhi - pPsi * c) ./ (I1 * sSafe2) - Omega;
psiDot = pPsi / I3 - ((pPhi - pPsi * c) .* c) ./ (I1 * sSafe2);

energy = pPsi^2 / (2 * I3) ...
    - Omega * pPhi ...
    + pTheta.^2 / (2 * I1) ...
    + (pPhi - pPsi * c).^2 ./ (2 * I1 * sSafe2) ...
    + 0.5 * Omega^2 * (I1 * sSafe2 + I3 * c.^2) ...
    + Mga * c;

axisSpace = [sin(theta) .* sin(phi), -sin(theta) .* cos(phi), cos(theta)];

omegaNum = NaN;
thetaPred = NaN(size(t));
if ~isempty(predictedThetaFcn)
    thetaPred = predictedThetaFcn(t);
    omegaNum = local_estimate_frequency(t, theta - mean(theta));
end

out = struct();
out.mode = 'top_fixed';
out.submode = submode;
out.t = t;
out.theta = theta;
out.phi = phi;
out.psi = psi;
out.thetaDot = thetaDot;
out.phiDot = phiDot;
out.psiDot = psiDot;
out.energy = energy;
out.axisSpace = axisSpace;
out.pPhi = pPhi;
out.pPsi = pPsi;
out.I1 = I1;
out.I3 = I3;
out.Mga = Mga;
out.Omega = Omega;
out.thetaEq = thetaEq;
out.omegaP = omegaP;
out.omegaPNumerical = omegaNum;
out.thetaPred = thetaPred;
out.phiDot0Shown = phiDot0Shown;
out.psiDot0Shown = psiDot0Shown;
out.status = local_make_status(submode, Mga, Omega, pPhi, pPsi, thetaEq, phiDot0Shown, psiDot0Shown, omegaP, omegaNum);
end

function dy = local_top_rhs(~, y, I1, I3, Mga, Omega, pPhi, pPsi)
theta = y(1);
pTheta = y(2);

s = sin(theta);
c = cos(theta);
sSafe = sign(s) * max(abs(s), 1.0e-7);

thetaDot = pTheta / I1;
pThetaDot = Mga * s ...
    + Omega^2 * (I3 - I1) * s * c ...
    - ((pPhi - pPsi * c) * (pPsi - pPhi * c)) / (I1 * sSafe^3);

phiDot = (pPhi - pPsi * c) / (I1 * sSafe^2) - Omega;
psiDot = pPsi / I3 - ((pPhi - pPsi * c) * c) / (I1 * sSafe^2);

dy = [thetaDot; pThetaDot; phiDot; psiDot];
end

function omega = local_estimate_frequency(t, x)
x = x(:) - mean(x(:));

if numel(x) < 5
    omega = NaN;
    return;
end

dx = diff(x);
idx = find(dx(1:end-1) > 0 & dx(2:end) <= 0) + 1;

if numel(idx) >= 2
    T = mean(diff(t(idx)));
    omega = 2 * pi / T;
else
    omega = NaN;
end
end

function status = local_make_status(submode, Mga, Omega, pPhi, pPsi, thetaEq, phiDot0, psiDot0, omegaP, omegaNum)
status = { ...
    sprintf('Mga = %.8g,  Omega = %.8g', Mga, Omega), ...
    sprintf('守恒量: p_phi = %.8g,  p_psi = %.8g', pPhi, pPsi), ...
    sprintf('实现采用 H = p_theta^2/(2I1) + U_eff(theta) 约化后的严格方程。') ...
    };

if strcmpi(submode, 'steady')
    status{end + 1} = sprintf('稳态输入: theta0 = %.6g, phiDot0 = %.6g, psiDot0 = %.6g', thetaEq, phiDot0, psiDot0);
    status{end + 1} = sprintf('微扰角频率: omega_p(pred) = %.8g,  omega_p(num) = %.8g', omegaP, omegaNum);
end
end
