function out = rb_simulate_free_exact(p)
%RB_SIMULATE_FREE_EXACT Exact free rigid-body motion using lecture formulas.
%
% Required fields:
%   p.I        = [I1 I2 I3], with I1 <= I2 <= I3
%   p.w0       = [w1(0) w2(0) w3(0)]
%   p.phi0     = initial Euler angle phi
%   p.tEnd     = end time
%   p.nSamples = number of time samples

I = p.I(:).';
if numel(I) ~= 3 || any(I <= 0)
    error('I 必须是 3 个正数。');
end
if ~(I(1) <= I(2) && I(2) <= I(3))
    error('自由转动解析模式要求 I1 <= I2 <= I3。');
end

w0 = p.w0(:).';
if numel(w0) ~= 3
    error('w0 必须是 3 个分量。');
end

I1 = I(1);
I2 = I(2);
I3 = I(3);

E = 0.5 * (I1 * w0(1)^2 + I2 * w0(2)^2 + I3 * w0(3)^2);
L2 = (I1 * w0(1))^2 + (I2 * w0(2))^2 + (I3 * w0(3))^2;
L = sqrt(L2);

if L < 1.0e-14 || E < 1.0e-14
    error('omega(0) 不能全为零。');
end

sepDelta = L2 - 2 * E * I2;
tol = 1.0e-10 * max([1.0, abs(L2), abs(2 * E * I2)]);

t = linspace(0, p.tEnd, p.nSamples).';
w = zeros(numel(t), 3);

if abs(sepDelta) <= tol
    caseId = 3;
    caseName = 'L^2 = 2 E I_2（分界/双曲函数）';

    wSep = sqrt(2 * E / I2);
    sepRate = wSep * sqrt((I2 - I1) * (I3 - I2) / (I1 * I3));

    A = wSep * sqrt(I2 * (I3 - I2) / (I1 * (I3 - I1)));
    C = wSep * sqrt(I2 * (I2 - I1) / (I3 * (I3 - I1)));

    s1 = local_safe_sign(w0(1));
    s3 = local_safe_sign(w0(3));
    s2 = s1 * s3;

    if abs(w0(2) / wSep) < 1
        tau0 = atanh(max(min(w0(2) / (s2 * wSep), 1 - 1.0e-12), -1 + 1.0e-12));
    else
        tau0 = 0.0;
    end

    tau = sepRate * t + tau0;
    sechTau = 1 ./ cosh(tau);

    w(:, 1) = s1 * A * sechTau;
    w(:, 2) = s2 * wSep * tanh(tau);
    w(:, 3) = s3 * C * sechTau;

    period = inf;
    m = 1.0;
    nu = sepRate;
    phase0 = tau0;

else
    if sepDelta < 0
        caseId = 1;
        caseName = 'L^2 < 2 E I_2（sn / cn / dn 支）';

        A = sqrt((2 * E * I3 - L2) / (I1 * (I3 - I1)));
        B = sqrt((L2 - 2 * E * I1) / (I2 * (I2 - I1)));
        C = sqrt((L2 - 2 * E * I1) / (I3 * (I3 - I1)));
        m = ((I3 - I2) * (L2 - 2 * E * I1)) / ((I2 - I1) * (2 * E * I3 - L2));
        m = local_clamp(m, 0.0, 1.0 - 1.0e-12);

        nu = sqrt((I2 - I1) * (2 * E * I3 - L2) / (I1 * I2 * I3));
        s1 = local_safe_sign(w0(1));
        phase0 = local_fit_phase_case1(w0, A, B, C, m, s1);

        u = nu * t + phase0;
        [sn, cn, dn] = ellipj(u, m);

        w(:, 1) = s1 * A * dn;
        w(:, 2) = s1 * B * sn;
        w(:, 3) = C * cn;

    else
        caseId = 2;
        caseName = 'L^2 > 2 E I_2（cn / sn / dn 支）';

        A = sqrt((2 * E * I3 - L2) / (I1 * (I3 - I1)));
        B = sqrt((2 * E * I3 - L2) / (I2 * (I3 - I2)));
        C = sqrt((L2 - 2 * E * I1) / (I3 * (I3 - I1)));
        m = ((I2 - I1) * (2 * E * I3 - L2)) / ((I3 - I2) * (L2 - 2 * E * I1));
        m = local_clamp(m, 0.0, 1.0 - 1.0e-12);

        nu = sqrt((I3 - I2) * (L2 - 2 * E * I1) / (I1 * I2 * I3));
        s3 = local_safe_sign(w0(3));
        phase0 = local_fit_phase_case2(w0, A, B, C, m, s3);

        u = nu * t + phase0;
        [sn, cn, dn] = ellipj(u, m);

        w(:, 1) = A * cn;
        w(:, 2) = s3 * B * sn;
        w(:, 3) = s3 * C * dn;
    end

    K = ellipke(m);
    period = 4 * K / nu;
end

Lbody = [I1 * w(:, 1), I2 * w(:, 2), I3 * w(:, 3)];
LhatBody = Lbody / L;

theta = acos(local_clamp((I3 * w(:, 3)) / L, -1.0, 1.0));
psi = unwrap(atan2(I1 * w(:, 1), I2 * w(:, 2)));

denPhi = I1^2 * w(:, 1).^2 + I2^2 * w(:, 2).^2;
phiDot = zeros(size(t));
mask = denPhi > 1.0e-12;
phiDot(mask) = L * (I1 * w(mask, 1).^2 + I2 * w(mask, 2).^2) ./ denPhi(mask);
phi = p.phi0 + cumtrapz(t, phiDot);

Echeck = 0.5 * (I1 * w(:, 1).^2 + I2 * w(:, 2).^2 + I3 * w(:, 3).^2);
Lcheck = sqrt((I1 * w(:, 1)).^2 + (I2 * w(:, 2)).^2 + (I3 * w(:, 3)).^2);

driftE = max(abs(Echeck - E)) / max(abs(E), 1.0);
driftL = max(abs(Lcheck - L)) / max(abs(L), 1.0);

out = struct();
out.mode = 'free_exact';
out.t = t;
out.omega = w;
out.theta = theta;
out.psi = psi;
out.phi = phi;
out.phiDot = phiDot;
out.inertia = I;
out.E = E;
out.L = L;
out.L2 = L2;
out.lambda = L2 / (2 * E);
out.caseId = caseId;
out.caseName = caseName;
out.period = period;
out.Lbody = Lbody;
out.LhatBody = LhatBody;
out.maxRelativeDriftE = driftE;
out.maxRelativeDriftL = driftL;
out.phase0 = phase0;
out.nu = nu;
out.m = m;
out.status = { ...
    sprintf('分支判据: %s', caseName), ...
    sprintf('E = %.8g,  |L| = %.8g,  lambda = L^2/(2E) = %.8g', E, L, out.lambda), ...
    sprintf('max|ΔE|/E = %.3e,  max|Δ|L||/|L| = %.3e', driftE, driftL), ...
    sprintf('Euler z 轴按讲义固定为角动量方向；phi(0) = %.4g', p.phi0) ...
    };
end

function s = local_safe_sign(x)
if x < 0
    s = -1;
else
    s = 1;
end
end

function y = local_clamp(x, lo, hi)
y = min(max(x, lo), hi);
end

function u0 = local_fit_phase_case1(w0, A, B, C, m, s1)
K = ellipke(m);
uGrid = linspace(0, 4 * K, 4001);
[sn, cn, dn] = ellipj(uGrid, m);

err = (s1 * A * dn - w0(1)).^2 ...
    + (s1 * B * sn - w0(2)).^2 ...
    + (C * cn - w0(3)).^2;

[~, idx] = min(err);
left = uGrid(max(1, idx - 2));
right = uGrid(min(numel(uGrid), idx + 2));

fun = @(u) local_phase_err_case1(u, w0, A, B, C, m, s1);
if right > left
    u0 = fminbnd(fun, left, right);
else
    u0 = uGrid(idx);
end

if u0 > 2 * K
    u0 = u0 - 4 * K;
end
end

function val = local_phase_err_case1(u, w0, A, B, C, m, s1)
[sn, cn, dn] = ellipj(u, m);
val = (s1 * A * dn - w0(1)).^2 ...
    + (s1 * B * sn - w0(2)).^2 ...
    + (C * cn - w0(3)).^2;
end

function u0 = local_fit_phase_case2(w0, A, B, C, m, s3)
K = ellipke(m);
uGrid = linspace(0, 4 * K, 4001);
[sn, cn, dn] = ellipj(uGrid, m);

err = (A * cn - w0(1)).^2 ...
    + (s3 * B * sn - w0(2)).^2 ...
    + (s3 * C * dn - w0(3)).^2;

[~, idx] = min(err);
left = uGrid(max(1, idx - 2));
right = uGrid(min(numel(uGrid), idx + 2));

fun = @(u) local_phase_err_case2(u, w0, A, B, C, m, s3);
if right > left
    u0 = fminbnd(fun, left, right);
else
    u0 = uGrid(idx);
end

if u0 > 2 * K
    u0 = u0 - 4 * K;
end
end

function val = local_phase_err_case2(u, w0, A, B, C, m, s3)
[sn, cn, dn] = ellipj(u, m);
val = (A * cn - w0(1)).^2 ...
    + (s3 * B * sn - w0(2)).^2 ...
    + (s3 * C * dn - w0(3)).^2;
end
