function vec = rb_parse_vector(txt, nExpected, fieldName)
%RB_PARSE_VECTOR Parse a numeric vector from an edit field string.
if nargin < 2
    nExpected = [];
end
if nargin < 3
    fieldName = 'unnamed';
end

if isstring(txt)
    txt = char(txt);
end

txt = strtrim(txt);
if isempty(txt)
    error('参数 "%s" 不能为空。', fieldName);
end

txt = strrep(txt, ',', ' ');
txt = strrep(txt, ';', ' ');
vec = sscanf(txt, '%f').';

if isempty(vec)
    error('参数 "%s" 不是有效的数值串。', fieldName);
end

if ~isempty(nExpected) && numel(vec) ~= nExpected
    error('参数 "%s" 需要 %d 个数值，当前读到 %d 个。', fieldName, nExpected, numel(vec));
end
end
