function rb_plot_branch(ax, res)
%RB_PLOT_BRANCH Plot branch-scan results under damping.
if numel(ax) ~= 4
    error('rb_plot_branch 需要 4 个坐标轴句柄。');
end

for k = 1:4
    cla(ax(k));
    grid(ax(k), 'on');
    hold(ax(k), 'on');
end

t = res.t;
w = res.omega;
I = res.inertia;

plot(ax(1), t, w(:, 1), 'LineWidth', 1.4, 'DisplayName', '\omega_1');
plot(ax(1), t, w(:, 2), 'LineWidth', 1.4, 'DisplayName', '\omega_2');
plot(ax(1), t, w(:, 3), 'LineWidth', 1.4, 'DisplayName', '\omega_3');
xlabel(ax(1), 't');
ylabel(ax(1), '\omega_i');
title(ax(1), sprintf('inspect: delta = %.4g', res.deltaInspect));
legend(ax(1), 'Location', 'best');

plot(ax(2), t, res.lambda, 'LineWidth', 1.6, 'DisplayName', '\lambda(t) = L^2/(2E)');
yline(ax(2), I(1), '--', 'I_1', 'HandleVisibility', 'off');
yline(ax(2), I(2), '--', 'I_2', 'HandleVisibility', 'off');
yline(ax(2), I(3), '--', 'I_3', 'HandleVisibility', 'off');
xlabel(ax(2), 't');
ylabel(ax(2), '\lambda(t)');
title(ax(2), '阻尼下的“等效惯量”流向哪条稳定分支');
legend(ax(2), 'Location', 'best');

plot3(ax(3), w(:, 1), w(:, 2), w(:, 3), 'LineWidth', 1.8, 'DisplayName', 'trajectory');
scatter3(ax(3), w(1, 1), w(1, 2), w(1, 3), 40, 'o', 'filled', 'DisplayName', 'start');
scatter3(ax(3), w(end, 1), w(end, 2), w(end, 3), 40, 'd', 'filled', 'DisplayName', 'end');
xlabel(ax(3), '\omega_1');
ylabel(ax(3), '\omega_2');
zlabel(ax(3), '\omega_3');
title(ax(3), '临界附近一条具体轨道');
legend(ax(3), 'Location', 'best');
axis(ax(3), 'equal');
view(ax(3), 35, 20);

idx1 = res.branch == 1;
idx2 = res.branch == 2;
idx3 = res.branch == 3;

if any(idx1)
    scatter(ax(4), res.scanVals(idx1), res.branch(idx1), 40, '^', 'filled', 'DisplayName', '落入轴 1 分支');
end
if any(idx2)
    scatter(ax(4), res.scanVals(idx2), res.branch(idx2), 40, 'o', 'filled', 'DisplayName', '落入轴 2 分支');
end
if any(idx3)
    scatter(ax(4), res.scanVals(idx3), res.branch(idx3), 40, 'd', 'filled', 'DisplayName', '落入轴 3 分支');
end

xline(ax(4), 0, '--', '临界值', 'HandleVisibility', 'off');
xlabel(ax(4), '\delta');
ylabel(ax(4), '最终分支');
yticks(ax(4), [1 2 3]);
yticklabels(ax(4), {'轴 1', '轴 2', '轴 3'});
title(ax(4), '近分离曲线的分支选择');
legend(ax(4), 'Location', 'best');
end
