function rigid_body_gui()
%RIGID_BODY_GUI Interactive GUI for exact free rotation and fixed-point symmetric-top motion.
%
% Main pedagogical focus:
%   1) 网球拍定理 / 自由转动：严格使用讲义中的 Jacobi 椭圆函数分支
%   2) 临界附近 + 阻尼：展示完全不同的末态分支
%   3) 旋转对称刚体在重力 / 磁场中的定点转动：守恒量约化 + 有效势

app = struct();
app.result = [];

freePresets = rb_presets('free');
branchPresets = rb_presets('branch');
topPresets = rb_presets('top');

buildUI();
applyFreePreset(freePresets(1).name);
applyBranchPreset(branchPresets(1).name);
applyTopPreset(topPresets(1).name);
updateModeNote();

    function buildUI()
        app.fig = uifigure( ...
            'Name', '刚体转动公式可视化 GUI', ...
            'Position', [40, 40, 1500, 900]);

        app.main = uigridlayout(app.fig, [1, 2]);
        app.main.ColumnWidth = {380, '1x'};
        app.main.RowHeight = {'1x'};
        app.main.Padding = [8, 8, 8, 8];
        app.main.ColumnSpacing = 8;

        left = uipanel(app.main, 'Title', '模式与参数');
        left.Layout.Row = 1;
        left.Layout.Column = 1;

        right = uipanel(app.main, 'Title', '图像输出');
        right.Layout.Row = 1;
        right.Layout.Column = 2;

        leftGrid = uigridlayout(left, [4, 1]);
        leftGrid.RowHeight = {'fit', '1x', 'fit', 150};
        leftGrid.ColumnWidth = {'1x'};
        leftGrid.Padding = [8, 8, 8, 8];
        leftGrid.RowSpacing = 8;

        app.note = uilabel(leftGrid, ...
            'Text', '', ...
            'WordWrap', 'on', ...
            'HorizontalAlignment', 'left');
        app.note.Layout.Row = 1;
        app.note.Layout.Column = 1;

        app.tabs = uitabgroup(leftGrid);
        app.tabs.Layout.Row = 2;
        app.tabs.Layout.Column = 1;
        app.tabs.SelectionChangedFcn = @(~, ~) updateModeNote();

        % ---------------- Free exact tab ----------------
        app.tabFree = uitab(app.tabs, 'Title', '自由转动（解析）');
        gFree = uigridlayout(app.tabFree, [7, 2]);
        gFree.RowHeight = {'fit', 'fit', 'fit', 'fit', 'fit', 'fit', '1x'};
        gFree.ColumnWidth = {130, '1x'};

        [~, app.freePreset] = addDropdown(gFree, 1, '预设', {freePresets.name}, @onAnyPresetChange);
        [~, app.freeI] = addTextField(gFree, 2, 'I = [I1 I2 I3]', '');
        [~, app.freeW0] = addTextField(gFree, 3, 'omega(0) = [w1 w2 w3]', '');
        [~, app.freePhi0] = addTextField(gFree, 4, 'phi(0)', '');
        [~, app.freeTEnd] = addTextField(gFree, 5, 'tEnd', '');
        [~, app.freeNSamples] = addTextField(gFree, 6, 'nSamples', '');
        app.freeHelp = uilabel(gFree, 'Text', '要求按 I1 <= I2 <= I3 输入。该模式中的惯性系 z 轴固定为角动量方向。', 'WordWrap', 'on');
        app.freeHelp.Layout.Row = 7;
        app.freeHelp.Layout.Column = [1, 2];

        % ---------------- Branch tab ----------------
        app.tabBranch = uitab(app.tabs, 'Title', '阻尼分支扫描');
        gBranch = uigridlayout(app.tabBranch, [8, 2]);
        gBranch.RowHeight = {'fit', 'fit', 'fit', 'fit', 'fit', 'fit', 'fit', '1x'};
        gBranch.ColumnWidth = {130, '1x'};

        [~, app.branchPreset] = addDropdown(gBranch, 1, '预设', {branchPresets.name}, @onAnyPresetChange);
        [~, app.branchI] = addTextField(gBranch, 2, 'I = [I1 I2 I3]', '');
        [~, app.branchWSpin] = addTextField(gBranch, 3, 'omega_spin', '');
        [~, app.branchEps] = addTextField(gBranch, 4, 'epsSep', '');
        [~, app.branchScan] = addTextField(gBranch, 5, '[deltaMin deltaMax nScan inspect]', '');
        [~, app.branchDamping] = addTextField(gBranch, 6, '[c1 c2]', '');
        [~, app.branchTEnd] = addTextField(gBranch, 7, '[tEnd nSamples]', '');
        app.branchHelp = uilabel(gBranch, ...
            'Text', 'epsSep 控制分离曲线附近的接近程度；delta 控制偏离临界关系的方向与大小。', ...
            'WordWrap', 'on');
        app.branchHelp.Layout.Row = 8;
        app.branchHelp.Layout.Column = [1, 2];

        % ---------------- Top tab ----------------
        app.tabTop = uitab(app.tabs, 'Title', '定点对称陀螺');
        gTop = uigridlayout(app.tabTop, [10, 2]);
        gTop.RowHeight = {'fit', 'fit', 'fit', 'fit', 'fit', 'fit', 'fit', 'fit', 'fit', '1x'};
        gTop.ColumnWidth = {130, '1x'};

        [~, app.topPreset] = addDropdown(gTop, 1, '预设', {topPresets.name}, @onAnyPresetChange);
        [~, app.topSubmode] = addDropdown(gTop, 2, '子模式', {'steady', 'general'}, []);
        [~, app.topI] = addTextField(gTop, 3, '[I1 I3]', '');
        [~, app.topMgaParts] = addTextField(gTop, 4, '[M g a]', '');
        [~, app.topQBParts] = addTextField(gTop, 5, '[Q B]', '');
        [~, app.topSteady] = addTextField(gTop, 6, '[theta0 phiDot0 dTheta phi0 psi0]', '');
        [~, app.topGeneral] = addTextField(gTop, 7, '[theta0 phi0 psi0 thetaDot0 phiDot0 psiDot0]', '');
        [~, app.topTEnd] = addTextField(gTop, 8, 'tEnd', '');
        [~, app.topNSamples] = addTextField(gTop, 9, 'nSamples', '');
        app.topHelp = uilabel(gTop, ...
            'Text', ['steady: 自动由讲义稳态公式生成 p_phi, p_psi，并比较预测/数值 omega_p。' newline ...
                     'general: 直接输入一般初值 [theta phi psi thetaDot phiDot psiDot]。'], ...
            'WordWrap', 'on');
        app.topHelp.Layout.Row = 10;
        app.topHelp.Layout.Column = [1, 2];

        % Buttons
        buttonGrid = uigridlayout(leftGrid, [1, 3]);
        buttonGrid.Layout.Row = 3;
        buttonGrid.Layout.Column = 1;
        buttonGrid.ColumnWidth = {'1x', '1x', '1x'};
        app.runButton = uibutton(buttonGrid, 'Text', '运行', 'ButtonPushedFcn', @(~, ~) onRun());
        app.playButton = uibutton(buttonGrid, 'Text', '播放动画', 'ButtonPushedFcn', @(~, ~) onPlay());
        app.clearButton = uibutton(buttonGrid, 'Text', '清空图像', 'ButtonPushedFcn', @(~, ~) onClear());

        app.log = uitextarea(leftGrid, 'Editable', 'off');
        app.log.Layout.Row = 4;
        app.log.Layout.Column = 1;
        app.log.Value = {'GUI 已启动。请选择模式，修改参数，然后点击“运行”。'};

        % Right plots
        rightGrid = uigridlayout(right, [2, 2]);
        rightGrid.RowHeight = {'1x', '1x'};
        rightGrid.ColumnWidth = {'1x', '1x'};
        rightGrid.Padding = [6, 6, 6, 6];
        rightGrid.RowSpacing = 6;
        rightGrid.ColumnSpacing = 6;

        app.ax = gobjects(4, 1);
        for k = 1:4
            app.ax(k) = uiaxes(rightGrid);
            app.ax(k).Layout.Row = ceil(k / 2);
            app.ax(k).Layout.Column = 1 + mod(k - 1, 2);
            grid(app.ax(k), 'on');
            hold(app.ax(k), 'on');
        end
    end

    function [lbl, dd] = addDropdown(parent, row, textLabel, items, callbackFcn)
        lbl = uilabel(parent, 'Text', textLabel);
        lbl.Layout.Row = row;
        lbl.Layout.Column = 1;

        dd = uidropdown(parent, 'Items', items, 'Value', items{1});
        dd.Layout.Row = row;
        dd.Layout.Column = 2;
        if ~isempty(callbackFcn)
            dd.ValueChangedFcn = callbackFcn;
        end
    end

    function [lbl, field] = addTextField(parent, row, textLabel, defaultValue)
        lbl = uilabel(parent, 'Text', textLabel);
        lbl.Layout.Row = row;
        lbl.Layout.Column = 1;

        field = uieditfield(parent, 'text', 'Value', defaultValue);
        field.Layout.Row = row;
        field.Layout.Column = 2;
    end

    function onAnyPresetChange(src, ~)
        if isequal(src, app.freePreset)
            applyFreePreset(app.freePreset.Value);
        elseif isequal(src, app.branchPreset)
            applyBranchPreset(app.branchPreset.Value);
        elseif isequal(src, app.topPreset)
            applyTopPreset(app.topPreset.Value);
        end
    end

    function applyFreePreset(name)
        idx = find(strcmp({freePresets.name}, name), 1);
        if isempty(idx)
            return;
        end
        p = freePresets(idx);
        app.freePreset.Value = p.name;
        app.freeI.Value = vec2str(p.I);
        app.freeW0.Value = vec2str(p.w0);
        app.freePhi0.Value = num2str(p.phi0, '%.12g');
        app.freeTEnd.Value = num2str(p.tEnd, '%.12g');
        app.freeNSamples.Value = num2str(p.nSamples, '%.12g');
    end

    function applyBranchPreset(name)
        idx = find(strcmp({branchPresets.name}, name), 1);
        if isempty(idx)
            return;
        end
        p = branchPresets(idx);
        app.branchPreset.Value = p.name;
        app.branchI.Value = vec2str(p.I);
        app.branchWSpin.Value = num2str(p.wSpin, '%.12g');
        app.branchEps.Value = num2str(p.epsSep, '%.12g');
        app.branchScan.Value = vec2str(p.scan);
        app.branchDamping.Value = vec2str(p.damping);
        app.branchTEnd.Value = vec2str([p.tEnd, p.nSamples]);
    end

    function applyTopPreset(name)
        idx = find(strcmp({topPresets.name}, name), 1);
        if isempty(idx)
            return;
        end
        p = topPresets(idx);
        app.topPreset.Value = p.name;
        app.topSubmode.Value = p.submode;
        app.topI.Value = vec2str(p.I);
        app.topMgaParts.Value = vec2str(p.MgaParts);
        app.topQBParts.Value = vec2str(p.QBParts);
        app.topSteady.Value = vec2str(p.steady);
        app.topGeneral.Value = vec2str(p.general);
        app.topTEnd.Value = num2str(p.tEnd, '%.12g');
        app.topNSamples.Value = num2str(p.nSamples, '%.12g');
    end

    function s = vec2str(v)
        s = strtrim(sprintf('%.12g ', v));
    end

    function updateModeNote()
        if isequal(app.tabs.SelectedTab, app.tabFree)
            app.note.Text = ['这一页严格使用你讲义中的自由转动解析公式：' newline ...
                '先按 L^2 与 2 E I2 的关系分支，再用 Jacobi sn/cn/dn 与相位拟合匹配任意输入的 omega(0)。'];
        elseif isequal(app.tabs.SelectedTab, app.tabBranch)
            app.note.Text = ['这一页把临界附近的小差别直接可视化：' newline ...
                '先按分离曲线关系构造初值，再加上 tau_d = -(c1 + c2 |omega|) omega，看末态落入轴 1 还是轴 3。'];
        else
            app.note.Text = ['这一页聚焦旋转对称刚体在重力/磁场中的定点转动：' newline ...
                '用 p_phi, p_psi 的守恒把问题约化到 theta；一个图讲清 U_eff(theta)，一个图讲清进动/章动。'];
        end
    end

    function onRun()
        try
            if isequal(app.tabs.SelectedTab, app.tabFree)
                p = parseFreeInputs();
                res = rb_simulate_free_exact(p);
                rb_plot_free(app.ax, res);
            elseif isequal(app.tabs.SelectedTab, app.tabBranch)
                p = parseBranchInputs();
                res = rb_simulate_branch_scan(p);
                rb_plot_branch(app.ax, res);
            else
                p = parseTopInputs();
                res = rb_simulate_top_fixed(p);
                rb_plot_top(app.ax, res);
            end

            app.result = res;
            app.log.Value = res.status;

        catch ME
            app.log.Value = {['错误: ' ME.message]};
            uialert(app.fig, ME.message, '计算失败');
        end
    end

    function onPlay()
        if isempty(app.result)
            uialert(app.fig, '请先运行一次，得到结果后再播放动画。', '没有可播放的结果');
            return;
        end

        try
            rb_play_animation(app.result);
        catch ME
            app.log.Value = [{['动画失败: ' ME.message]}, app.log.Value];
            uialert(app.fig, ME.message, '动画失败');
        end
    end

    function onClear()
        for k = 1:4
            cla(app.ax(k));
            grid(app.ax(k), 'on');
            hold(app.ax(k), 'on');
        end
        app.log.Value = {'图像已清空。'};
        app.result = [];
    end

    function p = parseFreeInputs()
        p = struct();
        p.I = rb_parse_vector(app.freeI.Value, 3, 'I = [I1 I2 I3]');
        p.w0 = rb_parse_vector(app.freeW0.Value, 3, 'omega(0)');
        p.phi0 = str2double(app.freePhi0.Value);
        p.tEnd = str2double(app.freeTEnd.Value);
        p.nSamples = round(str2double(app.freeNSamples.Value));

        if ~isfinite(p.phi0)
            error('phi(0) 不是有效数字。');
        end
        if ~isfinite(p.tEnd) || p.tEnd <= 0
            error('tEnd 必须为正。');
        end
        if ~isfinite(p.nSamples) || p.nSamples < 50
            error('nSamples 至少应为 50。');
        end
    end

    function p = parseBranchInputs()
        p = struct();
        p.I = rb_parse_vector(app.branchI.Value, 3, 'I = [I1 I2 I3]');
        p.wSpin = str2double(app.branchWSpin.Value);
        p.epsSep = str2double(app.branchEps.Value);
        p.scan = rb_parse_vector(app.branchScan.Value, 4, '[deltaMin deltaMax nScan inspect]');
        p.c1 = NaN;
        p.c2 = NaN;
        damping = rb_parse_vector(app.branchDamping.Value, 2, '[c1 c2]');
        p.c1 = damping(1);
        p.c2 = damping(2);
        tpack = rb_parse_vector(app.branchTEnd.Value, 2, '[tEnd nSamples]');
        p.tEnd = tpack(1);
        p.nSamples = round(tpack(2));

        if ~isfinite(p.wSpin) || p.wSpin <= 0
            error('omega_spin 必须为正。');
        end
        if ~isfinite(p.epsSep)
            error('epsSep 不是有效数字。');
        end
        if p.scan(2) <= p.scan(1)
            error('deltaMax 必须大于 deltaMin。');
        end
        if round(p.scan(3)) < 5
            error('nScan 至少应为 5。');
        end
        if ~isfinite(p.tEnd) || p.tEnd <= 0
            error('tEnd 必须为正。');
        end
        if ~isfinite(p.nSamples) || p.nSamples < 50
            error('nSamples 至少应为 50。');
        end
    end

    function p = parseTopInputs()
        p = struct();
        p.submode = lower(strtrim(app.topSubmode.Value));
        p.I = rb_parse_vector(app.topI.Value, 2, '[I1 I3]');
        mgaParts = rb_parse_vector(app.topMgaParts.Value, 3, '[M g a]');
        qbParts = rb_parse_vector(app.topQBParts.Value, 2, '[Q B]');

        p.M = mgaParts(1);
        p.g = mgaParts(2);
        p.a = mgaParts(3);
        p.Q = qbParts(1);
        p.B = qbParts(2);

        p.steady = rb_parse_vector(app.topSteady.Value, 5, 'steady 参数');
        p.general = rb_parse_vector(app.topGeneral.Value, 6, 'general 参数');

        p.tEnd = str2double(app.topTEnd.Value);
        p.nSamples = round(str2double(app.topNSamples.Value));

        if ~isfinite(p.tEnd) || p.tEnd <= 0
            error('tEnd 必须为正。');
        end
        if ~isfinite(p.nSamples) || p.nSamples < 50
            error('nSamples 至少应为 50。');
        end
    end
end
