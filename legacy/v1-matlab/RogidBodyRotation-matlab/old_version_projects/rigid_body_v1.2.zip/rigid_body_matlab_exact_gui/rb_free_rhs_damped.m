function dw = rb_free_rhs_damped(~, w, I, c1, c2)
%RB_FREE_RHS_DAMPED Euler equations with isotropic linear / quadratic damping.
I1 = I(1);
I2 = I(2);
I3 = I(3);

wn = norm(w);
tau = -(c1 + c2 * wn) * w(:);

dw = zeros(3, 1);
dw(1) = (tau(1) - (I3 - I2) * w(2) * w(3)) / I1;
dw(2) = (tau(2) - (I1 - I3) * w(3) * w(1)) / I2;
dw(3) = (tau(3) - (I2 - I1) * w(1) * w(2)) / I3;
end
