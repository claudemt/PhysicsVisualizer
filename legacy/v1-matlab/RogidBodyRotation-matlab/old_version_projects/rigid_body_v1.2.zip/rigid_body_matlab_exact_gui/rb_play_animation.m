function rb_play_animation(res)
%RB_PLAY_ANIMATION Open a simple animation figure for the current result.

switch lower(res.mode)
    case 'free_exact'
        local_play_free(res);

    case 'top_fixed'
        local_play_top(res);

    otherwise
        error('当前结果类型不支持动画: %s', res.mode);
end
end

function local_play_free(res)
fig = figure('Name', '自由转动动画', 'Color', 'w');
ax = axes('Parent', fig);
grid(ax, 'on');
hold(ax, 'on');
axis(ax, 'equal');
xlabel(ax, 'x');
ylabel(ax, 'y');
zlabel(ax, 'z');
title(ax, '体轴 triad 与角速度矢量');
view(ax, 35, 20);

[xs, ys, zs] = sphere(36);
surf(ax, xs, ys, zs, 'FaceAlpha', 0.04, 'EdgeAlpha', 0.08, 'HandleVisibility', 'off');
plot3(ax, [0 0], [0 0], [-1.2 1.2], '--', 'HandleVisibility', 'off');
quiver3(ax, 0, 0, 0, 0, 0, 1.1, 0, 'LineWidth', 2.0, 'DisplayName', 'L');

h1 = plot3(ax, [0 0], [0 0], [0 0], 'LineWidth', 2.2, 'DisplayName', 'e_1');
h2 = plot3(ax, [0 0], [0 0], [0 0], 'LineWidth', 2.2, 'DisplayName', 'e_2');
h3 = plot3(ax, [0 0], [0 0], [0 0], 'LineWidth', 2.2, 'DisplayName', 'e_3');
hW = quiver3(ax, 0, 0, 0, 0, 0, 0, 0, 'LineWidth', 1.8, 'DisplayName', '\omega');
legend(ax, 'Location', 'best');

idx = unique(round(linspace(1, numel(res.t), min(220, numel(res.t)))));
wScale = max(sqrt(sum(res.omega.^2, 2)));
wScale = max(wScale, 1.0);

for j = 1:numel(idx)
    k = idx(j);
    R = rb_passive_rotm_313x(res.phi(k), res.theta(k), res.psi(k));
    e1 = R(1, :);
    e2 = R(2, :);
    e3 = R(3, :);

    set(h1, 'XData', [0, e1(1)], 'YData', [0, e1(2)], 'ZData', [0, e1(3)]);
    set(h2, 'XData', [0, e2(1)], 'YData', [0, e2(2)], 'ZData', [0, e2(3)]);
    set(h3, 'XData', [0, e3(1)], 'YData', [0, e3(2)], 'ZData', [0, e3(3)]);

    omegaSpace = res.omega(k, 1) * e1 + res.omega(k, 2) * e2 + res.omega(k, 3) * e3;
    set(hW, 'XData', 0, 'YData', 0, 'ZData', 0, ...
        'UData', omegaSpace(1) / wScale, ...
        'VData', omegaSpace(2) / wScale, ...
        'WData', omegaSpace(3) / wScale);

    drawnow;
end
end

function local_play_top(res)
fig = figure('Name', '定点陀螺动画', 'Color', 'w');
ax = axes('Parent', fig);
grid(ax, 'on');
hold(ax, 'on');
axis(ax, 'equal');
xlabel(ax, 'x');
ylabel(ax, 'y');
zlabel(ax, 'z');
title(ax, '对称轴在空间中的进动 / 章动');
view(ax, 35, 20);

[xs, ys, zs] = sphere(36);
surf(ax, xs, ys, zs, 'FaceAlpha', 0.04, 'EdgeAlpha', 0.08, 'HandleVisibility', 'off');
plot3(ax, [0 0], [0 0], [-1.2 1.2], '--', 'HandleVisibility', 'off');

hTop = plot3(ax, [0 0], [0 0], [0 0], 'LineWidth', 3.0, 'DisplayName', 'symmetry axis');
hTrail = plot3(ax, 0, 0, 0, 'LineWidth', 1.2, 'DisplayName', 'tip trail');
legend(ax, 'Location', 'best');

idx = unique(round(linspace(1, numel(res.t), min(260, numel(res.t)))));
trail = nan(numel(idx), 3);

for j = 1:numel(idx)
    k = idx(j);
    n3 = res.axisSpace(k, :);
    trail(j, :) = n3;

    set(hTop, 'XData', [0, n3(1)], 'YData', [0, n3(2)], 'ZData', [0, n3(3)]);
    set(hTrail, 'XData', trail(1:j, 1), 'YData', trail(1:j, 2), 'ZData', trail(1:j, 3));

    drawnow;
end
end
