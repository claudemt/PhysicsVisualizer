function R = rb_passive_rotm_313x(phi, theta, psi)
%RB_PASSIVE_ROTM_313X Passive Euler rotation matrix used in the lecture notes.
% The lecture defines:
%   1) rotate x-y by phi around z
%   2) rotate y'-z' by theta around x'
%   3) rotate x''-y'' by psi around z''
% and gives [e1; e2; e3] = R [ex; ey; ez].

cph = cos(phi);
sph = sin(phi);
cth = cos(theta);
sth = sin(theta);
cps = cos(psi);
sps = sin(psi);

R = [ ...
    cps * cph - sps * sph * cth,  sph * cps + cth * cph * sps,  sth * sps; ...
   -sps * cph - cps * sph * cth, -sph * sps + cth * cph * cps,  sth * cps; ...
    sth * sph,                   -sth * cph,                    cth       ...
    ];
end
