function start_rigid_body_demo()
%START_RIGID_BODY_DEMO Convenience launcher.
rigid_body_gui();
end
