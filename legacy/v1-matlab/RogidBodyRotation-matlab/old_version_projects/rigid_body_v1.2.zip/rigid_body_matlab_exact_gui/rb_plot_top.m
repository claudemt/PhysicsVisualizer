function rb_plot_top(ax, res)
%RB_PLOT_TOP Plot fixed-point symmetric-top results.
if numel(ax) ~= 4
    error('rb_plot_top 需要 4 个坐标轴句柄。');
end

for k = 1:4
    cla(ax(k));
    grid(ax(k), 'on');
    hold(ax(k), 'on');
end

t = res.t;

plot(ax(1), t, res.theta, 'LineWidth', 1.6, 'DisplayName', '\theta(t)');
if strcmpi(res.submode, 'steady')
    plot(ax(1), t, res.thetaPred, '--', 'LineWidth', 1.2, 'DisplayName', '\theta_{lin}(t)');
end
xlabel(ax(1), 't');
ylabel(ax(1), '\theta [rad]');
title(ax(1), '章动角 \theta(t)');
legend(ax(1), 'Location', 'best');

thetaMin = max(1.0e-3, min(res.theta) - 0.20);
thetaMax = min(pi - 1.0e-3, max(res.theta) + 0.20);
thetaGrid = linspace(thetaMin, thetaMax, 600);
U = rb_effective_potential(thetaGrid, res.pPhi, res.pPsi, res.I1, res.I3, res.Mga, res.Omega);
plot(ax(2), thetaGrid, U, 'LineWidth', 1.8, 'DisplayName', 'U_{eff}(\theta)');
yline(ax(2), mean(res.energy), '--', 'H', 'DisplayName', 'H');
if strcmpi(res.submode, 'steady') && isfinite(res.thetaEq)
    xline(ax(2), res.thetaEq, '--', '\theta_0', 'DisplayName', '\theta_0');
end
xlabel(ax(2), '\theta');
ylabel(ax(2), 'energy-like scale');
title(ax(2), '有效势：H = p_\theta^2/(2I_1) + U_{eff}(\theta)');
legend(ax(2), 'Location', 'best');

[xs, ys, zs] = sphere(48);
surf(ax(3), xs, ys, zs, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.10, 'HandleVisibility', 'off');
plot3(ax(3), res.axisSpace(:, 1), res.axisSpace(:, 2), res.axisSpace(:, 3), 'LineWidth', 1.8, 'DisplayName', 'symmetry axis');
scatter3(ax(3), res.axisSpace(1, 1), res.axisSpace(1, 2), res.axisSpace(1, 3), 40, 'o', 'filled', 'DisplayName', 't=0');
plot3(ax(3), [0 0], [0 0], [-1.2 1.2], '--', 'HandleVisibility', 'off');
xlabel(ax(3), 'x');
ylabel(ax(3), 'y');
zlabel(ax(3), 'z');
title(ax(3), '对称轴在空间中的轨迹');
legend(ax(3), 'Location', 'best');
axis(ax(3), 'equal');
view(ax(3), 35, 20);

plot(ax(4), t, res.phiDot, 'LineWidth', 1.4, 'DisplayName', 'phiDot');
plot(ax(4), t, res.psiDot, 'LineWidth', 1.4, 'DisplayName', 'psiDot');
if strcmpi(res.submode, 'steady')
    yline(ax(4), res.phiDot0Shown, '--', 'HandleVisibility', 'off');
    yline(ax(4), res.psiDot0Shown, '--', 'HandleVisibility', 'off');
    title(ax(4), sprintf('进动/自旋速率；\\omega_p(pred)=%.4g, \\omega_p(num)=%.4g', res.omegaP, res.omegaPNumerical));
else
    title(ax(4), '进动/自旋速率');
end
xlabel(ax(4), 't');
ylabel(ax(4), 'rate [rad/s]');
legend(ax(4), 'Location', 'best');
end
