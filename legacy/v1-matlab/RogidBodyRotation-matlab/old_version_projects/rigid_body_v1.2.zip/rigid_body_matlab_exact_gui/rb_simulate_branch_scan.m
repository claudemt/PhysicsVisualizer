function out = rb_simulate_branch_scan(p)
%RB_SIMULATE_BRANCH_SCAN Near-separatrix branch selection with damping.

I = p.I(:).';
if numel(I) ~= 3 || any(I <= 0)
    error('I 必须是 3 个正数。');
end
if ~(I(1) <= I(2) && I(2) <= I(3))
    error('阻尼分支模式要求 I1 <= I2 <= I3。');
end

I1 = I(1);
I2 = I(2);
I3 = I(3);

if abs(p.epsSep) >= 1
    error('epsSep 必须满足 |epsSep| < 1。');
end
if p.wSpin <= 0
    error('wSpin 必须为正。');
end

Asep = p.wSpin * sqrt(I2 * (I3 - I2) / (I1 * (I3 - I1)));
Csep = p.wSpin * sqrt(I2 * (I2 - I1) / (I3 * (I3 - I1)));

scanVals = linspace(p.scan(1), p.scan(2), round(p.scan(3)));
deltaInspect = p.scan(4);

opts = odeset( ...
    'RelTol', 1.0e-8, ...
    'AbsTol', 1.0e-10, ...
    'MaxStep', max(p.tEnd / max(p.nSamples, 200), 1.0e-3));

branch = zeros(size(scanVals));
dominance = zeros(numel(scanVals), 3);

for k = 1:numel(scanVals)
    delta = scanVals(k);
    wInit = local_make_initial(I, p.wSpin, p.epsSep, delta);

    sol = ode113(@(t, w) rb_free_rhs_damped(t, w, I, p.c1, p.c2), [0, p.tEnd], wInit(:), opts);
    tEval = linspace(0, p.tEnd, max(400, round(p.nSamples / 2)));
    W = deval(sol, tEval).';

    wn = sqrt(sum(W.^2, 2));
    wn = max(wn, 1.0e-12);
    tail = max(1, round(0.85 * numel(tEval))) : numel(tEval);

    dominance(k, :) = mean(abs(W(tail, :)) ./ wn(tail), 1);
    [~, idx] = max(dominance(k, :));
    branch(k) = idx;
end

sampleInit = local_make_initial(I, p.wSpin, p.epsSep, deltaInspect);
sampleSol = ode113(@(t, w) rb_free_rhs_damped(t, w, I, p.c1, p.c2), [0, p.tEnd], sampleInit(:), opts);
t = linspace(0, p.tEnd, p.nSamples);
W = deval(sampleSol, t).';

E = 0.5 * (I1 * W(:, 1).^2 + I2 * W(:, 2).^2 + I3 * W(:, 3).^2);
L2 = (I1 * W(:, 1)).^2 + (I2 * W(:, 2)).^2 + (I3 * W(:, 3)).^2;
lambda = L2 ./ max(2 * E, 1.0e-12);

sampleDominance = mean(abs(W(max(1, round(0.85 * numel(t))) : end, :)) ...
    ./ max(sqrt(sum(W(max(1, round(0.85 * numel(t))) : end, :).^2, 2)), 1.0e-12), 1);
[~, finalBranch] = max(sampleDominance);

out = struct();
out.mode = 'branch_scan';
out.inertia = I;
out.t = t(:);
out.omega = W;
out.energy = E(:);
out.lambda = lambda(:);
out.scanVals = scanVals(:);
out.branch = branch(:);
out.dominance = dominance;
out.c1 = p.c1;
out.c2 = p.c2;
out.wSpin = p.wSpin;
out.epsSep = p.epsSep;
out.deltaInspect = deltaInspect;
out.sampleInit = sampleInit(:).';
out.finalBranch = finalBranch;
out.status = { ...
    sprintf('阻尼力矩: tau_d = -(c1 + c2 |omega|) omega,  c1 = %.4g, c2 = %.4g', p.c1, p.c2), ...
    sprintf('分离曲线附近参数: omega_spin = %.4g, epsSep = %.4g', p.wSpin, p.epsSep), ...
    sprintf('扫描 delta in [%.4g, %.4g], 共 %d 点', p.scan(1), p.scan(2), round(p.scan(3))), ...
    sprintf('当前 inspect delta = %.4g, 末态分支 = 轴 %d', deltaInspect, finalBranch) ...
    };
end

function wInit = local_make_initial(I, wSpin, epsSep, delta)
I1 = I(1);
I2 = I(2);
I3 = I(3);

Asep = wSpin * sqrt(I2 * (I3 - I2) / (I1 * (I3 - I1)));
Csep = wSpin * sqrt(I2 * (I2 - I1) / (I3 * (I3 - I1)));

eta = epsSep;
eta = max(min(eta, 1 - 1.0e-10), -1 + 1.0e-10);

w1 = Asep * eta;
w2 = sign(wSpin) * abs(wSpin) * sqrt(max(1 - eta^2, 0));
w3crit = Csep * abs(eta);
w3 = w3crit * (1 + delta);

wInit = [w1; w2; w3];
end
