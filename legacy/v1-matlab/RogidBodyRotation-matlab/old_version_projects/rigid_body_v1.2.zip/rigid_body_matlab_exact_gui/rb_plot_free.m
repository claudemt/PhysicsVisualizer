function rb_plot_free(ax, res)
%RB_PLOT_FREE Plot exact free-rotation results.
if numel(ax) ~= 4
    error('rb_plot_free 需要 4 个坐标轴句柄。');
end

for k = 1:4
    cla(ax(k));
    grid(ax(k), 'on');
    hold(ax(k), 'on');
end

t = res.t;
w = res.omega;
I = res.inertia;

plot(ax(1), t, w(:, 1), 'LineWidth', 1.5, 'DisplayName', '\omega_1');
plot(ax(1), t, w(:, 2), 'LineWidth', 1.5, 'DisplayName', '\omega_2');
plot(ax(1), t, w(:, 3), 'LineWidth', 1.5, 'DisplayName', '\omega_3');
xlabel(ax(1), 't');
ylabel(ax(1), '\omega_i');
title(ax(1), sprintf('自由转动解析解：%s', res.caseName));
legend(ax(1), 'Location', 'best');

yyaxis(ax(2), 'left');
plot(ax(2), t, res.theta, 'LineWidth', 1.5, 'DisplayName', '\theta');
plot(ax(2), t, res.psi, 'LineWidth', 1.2, 'DisplayName', '\psi');
ylabel(ax(2), '\theta, \psi [rad]');

yyaxis(ax(2), 'right');
plot(ax(2), t, res.phi, 'LineWidth', 1.2, 'DisplayName', '\phi');
ylabel(ax(2), '\phi [rad]');

xlabel(ax(2), 't');
title(ax(2), '欧拉角（按讲义中的 z || L 约定）');
legend(ax(2), {'\theta', '\psi', '\phi'}, 'Location', 'best');

[xe, ye, ze] = ellipsoid(0, 0, 0, sqrt(2 * res.E / I(1)), sqrt(2 * res.E / I(2)), sqrt(2 * res.E / I(3)), 40);
surf(ax(3), xe, ye, ze, 'FaceAlpha', 0.10, 'EdgeAlpha', 0.12, 'HandleVisibility', 'off');

[xl, yl, zl] = ellipsoid(0, 0, 0, res.L / I(1), res.L / I(2), res.L / I(3), 40);
surf(ax(3), xl, yl, zl, 'FaceAlpha', 0.10, 'EdgeAlpha', 0.10, 'HandleVisibility', 'off');

plot3(ax(3), w(:, 1), w(:, 2), w(:, 3), 'LineWidth', 1.8, 'DisplayName', 'polhode');
scatter3(ax(3), w(1, 1), w(1, 2), w(1, 3), 40, 'o', 'filled', 'DisplayName', 't=0');
scatter3(ax(3), w(end, 1), w(end, 2), w(end, 3), 40, 'd', 'filled', 'DisplayName', 't=t_{end}');
xlabel(ax(3), '\omega_1');
ylabel(ax(3), '\omega_2');
zlabel(ax(3), '\omega_3');
title(ax(3), 'Poinsot 图像：能量椭球与角动量椭球的交线');
legend(ax(3), 'Location', 'best');
axis(ax(3), 'equal');
view(ax(3), 35, 20);

[xs, ys, zs] = sphere(50);
surf(ax(4), xs, ys, zs, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.10, 'HandleVisibility', 'off');
plot3(ax(4), res.LhatBody(:, 1), res.LhatBody(:, 2), res.LhatBody(:, 3), 'LineWidth', 1.8, 'DisplayName', '\hat L in body frame');
scatter3(ax(4), res.LhatBody(1, 1), res.LhatBody(1, 2), res.LhatBody(1, 3), 40, 'o', 'filled', 'DisplayName', 't=0');

text(ax(4), 1.05, 0, 0, '+e_1');
text(ax(4), -1.15, 0, 0, '-e_1');
text(ax(4), 0, 1.05, 0, '+e_2');
text(ax(4), 0, -1.15, 0, '-e_2');
text(ax(4), 0, 0, 1.05, '+e_3');
text(ax(4), 0, 0, -1.15, '-e_3');

xlabel(ax(4), 'body 1');
ylabel(ax(4), 'body 2');
zlabel(ax(4), 'body 3');
title(ax(4), sprintf('\\lambda = L^2/(2E) = %.5g,  T = %.5g', res.lambda, res.period));
legend(ax(4), 'Location', 'best');
axis(ax(4), 'equal');
view(ax(4), 35, 20);
end
