function varargout = rigid_common_support(action, varargin)
%RIGID_COMMON_SUPPORT Shared helpers for rigid_body_rotation.
% Dispatcher file used to keep the whole package to four .m files.
%
% Usage examples:
%   presets = rigid_common_support('defaults');
%   rigid_common_support('style_axes', ax);
%   outDir = rigid_common_support('export_outputs', result, inputData, rootDir, 'rigid_body_rotation');

    if nargin < 1
        error('An action string is required.');
    end

    switch lower(string(action))
        case "defaults"
            varargout{1} = local_defaults();
        case "numvec_to_text"
            varargout{1} = local_numvec_to_text(varargin{1});
        case "parse_vector"
            varargout{1} = local_parse_numeric_vector(varargin{1}, varargin{2}, varargin{3});
        case "parse_scalar"
            varargout{1} = local_parse_scalar(varargin{1}, varargin{2});
        case "style_axes"
            local_style_axes(varargin{1});
        case "finish_2d_axes"
            local_finish_2d_axes(varargin{1});
        case "finish_3d_axes"
            if numel(varargin) >= 2
                local_finish_3d_axes(varargin{1}, varargin{2});
            else
                local_finish_3d_axes(varargin{1}, []);
            end
        case "render_preview"
            local_render_preview(varargin{1}, varargin{2});
        case "render_single_plot"
            local_render_single_plot(varargin{1}, varargin{2}, varargin{3});
        case "play_animation"
            local_play_animation(varargin{1}, varargin{2}, varargin{3}, varargin{4});
        case "export_outputs"
            varargout{1} = local_export_outputs(varargin{1}, varargin{2}, varargin{3}, varargin{4});
        case "set_empty_animation_axes"
            local_set_empty_animation_axes(varargin{1});
        case "axis_angle"
            varargout{1} = local_axis_angle(varargin{1}, varargin{2});
        case "euler313_to_quat"
            varargout{1} = local_euler313_to_quat(varargin{1});
        case "normalize_quat_array"
            varargout{1} = local_normalize_quat_array(varargin{1});
        case "omega_matrix"
            varargout{1} = local_omega_matrix(varargin{1});
        case "rotation_map"
            varargout{1} = local_rotation_map(varargin{1}, varargin{2});
        case "rotm_to_quat"
            varargout{1} = local_rotm_to_quat(varargin{1});
        case "quat_to_rotm"
            varargout{1} = local_quat_to_rotm(varargin{1});
        case "skew"
            varargout{1} = local_skew(varargin{1});
        otherwise
            error('Unknown rigid_common_support action: %s', char(string(action)));
    end
end

function presets = local_defaults()
    presets.free(1) = struct( ...
        'name', 'Tennis-racket flip', ...
        'I', [1 2 3], ...
        'w0', [0.18 2.2 0.04], ...
        'phi0', 0.0, ...
        'tEnd', 18, ...
        'nSamples', 2200);
    presets.free(2) = struct( ...
        'name', 'Near axis-1 rotation', ...
        'I', [1 2 3], ...
        'w0', [2.4 0.12 0.06], ...
        'phi0', 0.3, ...
        'tEnd', 18, ...
        'nSamples', 2200);
    presets.free(3) = struct( ...
        'name', 'Near axis-3 rotation', ...
        'I', [1 2 3], ...
        'w0', [0.08 0.14 2.0], ...
        'phi0', 0.6, ...
        'tEnd', 18, ...
        'nSamples', 2200);

    presets.fixed(1) = struct( ...
        'name', 'Regular-precession-like', ...
        'I', [1 1.4 2], ...
        'aBody', [0 0 1], ...
        'mass', 1, ...
        'g', 9.81, ...
        'euler0', [0 0.55 0], ...
        'w0', [0 0 15], ...
        'tEnd', 8, ...
        'nSamples', 2000);
    presets.fixed(2) = struct( ...
        'name', 'General top with nutation', ...
        'I', [1 1.8 2.2], ...
        'aBody', [0 0 1], ...
        'mass', 1, ...
        'g', 9.81, ...
        'euler0', [0.2 0.95 0.1], ...
        'w0', [0.8 0.1 10], ...
        'tEnd', 10, ...
        'nSamples', 2400);
    presets.fixed(3) = struct( ...
        'name', 'General heavy body', ...
        'I', [0.9 1.3 1.8], ...
        'aBody', [0.22 0.10 0.92], ...
        'mass', 1, ...
        'g', 9.81, ...
        'euler0', [0.35 1.00 0.25], ...
        'w0', [1.6 -0.5 8.5], ...
        'tEnd', 12, ...
        'nSamples', 2600);
end

function txt = local_numvec_to_text(v)
    vals = v(:).';
    if isempty(vals)
        txt = '[]';
        return;
    end
    pieces = arrayfun(@(x) sprintf('%.12g', x), vals, 'UniformOutput', false);
    txt = ['[' strjoin(pieces, ' ') ']'];
end

function v = local_parse_numeric_vector(str, n, name)
    s = strtrim(char(string(str)));
    if startsWith(s, '[') && endsWith(s, ']')
        s = s(2:end-1);
    end
    vals = sscanf(strrep(s, ',', ' '), '%f').';
    if numel(vals) ~= n || any(~isfinite(vals))
        error('Invalid vector for %s. Expected %d numbers.', name, n);
    end
    v = vals;
end

function x = local_parse_scalar(str, name)
    x = str2double(char(string(str)));
    if ~isscalar(x) || isnan(x) || ~isfinite(x)
        error('Invalid scalar for %s.', name);
    end
end

function local_render_preview(ax, result)
    for k = 1:7
        cla(ax{k});
        local_render_single_plot(ax{k}, result, k);
        drawnow limitrate;
    end
    local_play_animation(ax{8}, result, false, '');
end

function local_render_single_plot(ax, result, idx)
    t = result.t;
    wb = result.wBody;
    wl = result.wLab;
    Lb = result.LBody;
    tips = result.axisTips;
    [w3Scale, w3Legend] = local_pick_w3_scale(wb);
    w3Plot = wb(:,3) / w3Scale;

    switch idx
        case 1
            plot(ax, t, wl(:,1), 'LineWidth', 1.9, 'DisplayName', '$\omega_x$');
            hold(ax, 'on');
            plot(ax, t, wl(:,2), 'LineWidth', 1.9, 'DisplayName', '$\omega_y$');
            xlabel(ax, '$t\ \mathrm{(s)}$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega_{x,y}\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
            title(ax, '$\omega_x(t)$ and $\omega_y(t)$ in the lab frame', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_2d_axes(ax);

        case 2
            if strcmp(result.mode, 'free')
                plot(ax, wl(:,1), wl(:,2), 'LineWidth', 1.9, 'DisplayName', '$\left(\omega_x,\omega_y\right)$');
                hold(ax, 'on');
                plot(ax, wl(1,1), wl(1,2), 'o', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_0$');
                plot(ax, wl(end,1), wl(end,2), 's', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_f$');
                xlabel(ax, '$\omega_x\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
                ylabel(ax, '$\omega_y\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
                title(ax, 'Phase portrait of $\left(\omega_x,\omega_y\right)$ in the lab frame', 'Interpreter', 'latex');
                local_apply_legend(ax);
                local_finish_2d_axes(ax);
            else
                plot3(ax, wl(:,1), wl(:,2), wl(:,3), 'LineWidth', 1.9, 'DisplayName', '$\omega$ trajectory');
                hold(ax, 'on');
                plot3(ax, wl(1,1), wl(1,2), wl(1,3), 'o', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_0$');
                plot3(ax, wl(end,1), wl(end,2), wl(end,3), 's', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_f$');
                xlabel(ax, '$\omega_x\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
                ylabel(ax, '$\omega_y\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
                zlabel(ax, '$\omega_z\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
                title(ax, 'Trajectory of $\omega$ in the lab frame', 'Interpreter', 'latex');
                local_apply_legend(ax);
                local_finish_3d_axes(ax, wl);
            end

        case 3
            plot(ax, t, wb(:,1), 'LineWidth', 1.9, 'DisplayName', '$\omega_1$');
            hold(ax, 'on');
            plot(ax, t, wb(:,2), 'LineWidth', 1.9, 'DisplayName', '$\omega_2$');
            plot(ax, t, w3Plot, 'LineWidth', 1.9, 'DisplayName', w3Legend);
            xlabel(ax, '$t\ \mathrm{(s)}$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
            title(ax, '$\omega_1(t)$, $\omega_2(t)$, and $\omega_3(t)$ in the body frame', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_2d_axes(ax);

        case 4
            plot3(ax, wb(:,1), wb(:,2), wb(:,3), 'LineWidth', 1.9, 'DisplayName', '$\omega$ trajectory');
            hold(ax, 'on');
            plot3(ax, wb(1,1), wb(1,2), wb(1,3), 'o', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_0$');
            plot3(ax, wb(end,1), wb(end,2), wb(end,3), 's', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_f$');
            xlabel(ax, '$\omega_1\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega_2\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
            zlabel(ax, '$\omega_3\ \mathrm{(rad/s)}$', 'Interpreter', 'latex');
            title(ax, 'Trajectory of $\omega$ in the body frame', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_3d_axes(ax, wb);

        case 5
            plot3(ax, Lb(:,1), Lb(:,2), Lb(:,3), 'LineWidth', 1.9, 'DisplayName', '$L$ trajectory');
            hold(ax, 'on');
            plot3(ax, Lb(1,1), Lb(1,2), Lb(1,3), 'o', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_0$');
            plot3(ax, Lb(end,1), Lb(end,2), Lb(end,3), 's', 'MarkerSize', 7, 'LineWidth', 1.2, 'DisplayName', '$t=t_f$');
            xlabel(ax, '$L_1\ \mathrm{(arb.)}$', 'Interpreter', 'latex');
            ylabel(ax, '$L_2\ \mathrm{(arb.)}$', 'Interpreter', 'latex');
            zlabel(ax, '$L_3\ \mathrm{(arb.)}$', 'Interpreter', 'latex');
            title(ax, 'Trajectory of $L$ in the body frame', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_3d_axes(ax, Lb);

        case 6
            plot3(ax, wb(:,1), wb(:,2), wb(:,3), 'LineWidth', 1.9, 'DisplayName', '$\omega$');
            hold(ax, 'on');
            plot3(ax, Lb(:,1), Lb(:,2), Lb(:,3), 'LineWidth', 1.9, 'DisplayName', '$L$');
            xlabel(ax, '$c_1$', 'Interpreter', 'latex');
            ylabel(ax, '$c_2$', 'Interpreter', 'latex');
            zlabel(ax, '$c_3$', 'Interpreter', 'latex');
            title(ax, '$\omega$ and $L$ in the body frame (raw values)', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_3d_axes(ax, [wb; Lb]);

        case 7
            e1 = squeeze(tips(:,:,1));
            e2 = squeeze(tips(:,:,2));
            e3 = squeeze(tips(:,:,3));
            plot3(ax, e1(:,1), e1(:,2), e1(:,3), 'LineWidth', 1.9, 'DisplayName', '$\hat{e}_1$');
            hold(ax, 'on');
            plot3(ax, e2(:,1), e2(:,2), e2(:,3), 'LineWidth', 1.9, 'DisplayName', '$\hat{e}_2$');
            plot3(ax, e3(:,1), e3(:,2), e3(:,3), 'LineWidth', 1.9, 'DisplayName', '$\hat{e}_3$');
            xlabel(ax, '$x$', 'Interpreter', 'latex');
            ylabel(ax, '$y$', 'Interpreter', 'latex');
            zlabel(ax, '$z$', 'Interpreter', 'latex');
            title(ax, 'Tips of the body principal axes in the lab frame', 'Interpreter', 'latex');
            local_apply_legend(ax);
            local_finish_3d_axes(ax, [e1; e2; e3]);
    end
end

function outDir = local_export_outputs(result, inputData, outputRoot, mainFunctionName)
    if nargin < 4 || isempty(mainFunctionName)
        mainFunctionName = 'rigid_body_rotation';
    end
    if nargin < 3 || isempty(outputRoot)
        mainDir = fileparts(which(mainFunctionName));
        if isempty(mainDir)
            mainDir = fileparts(mfilename('fullpath'));
        end
        outputRoot = fullfile(mainDir, [mainFunctionName '_output']);
    end
    if ~exist(outputRoot, 'dir')
        mkdir(outputRoot);
    end

    stamp = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
    outDir = fullfile(outputRoot, stamp);
    mkdir(outDir);

    names = { ...
        'fig1_lab_xy_vs_t.png', ...
        'fig2_lab_phase_or_path.png', ...
        'fig3_body_components_vs_t.png', ...
        'fig4_body_omega_trajectory.png', ...
        'fig5_body_L_trajectory.png', ...
        'fig6_body_omega_and_L.png', ...
        'fig7_body_axis_tips.png'};

    for k = 1:7
        f = figure('Color', 'w', 'Position', [80 80 1280 960], 'Visible', 'off');
        ax = axes(f);
        local_style_axes(ax);
        local_render_single_plot(ax, result, k);
        exportgraphics(f, fullfile(outDir, names{k}), 'Resolution', 240);
        close(f);
    end

    local_play_animation([], result, true, fullfile(outDir, 'animation.mp4'));

    fid = fopen(fullfile(outDir, 'parameters.txt'), 'w');
    if fid < 0
        error('Failed to create parameters.txt.');
    end
    fprintf(fid, 'timestamp = %s\n', stamp);
    fprintf(fid, 'mode = %s\n', inputData.mode);
    fields = fieldnames(inputData);
    for k = 1:numel(fields)
        value = inputData.(fields{k});
        if isnumeric(value)
            fprintf(fid, '%s = %s\n', fields{k}, mat2str(value));
        else
            fprintf(fid, '%s = %s\n', fields{k}, char(string(value)));
        end
    end
    fclose(fid);
end

function local_play_animation(ax, result, writeVideoFlag, videoPath)
    tips = result.axisTips;
    wl = result.wLab;
    n = size(tips, 1);
    sampleIdx = unique(round(linspace(1, n, min(300, n))));
    tips = tips(sampleIdx,:,:);
    wl = wl(sampleIdx,:);

    [omegaScale, omegaLegend] = local_pick_animation_omega_scale(wl);
    wlPlot = wl / omegaScale;

    if writeVideoFlag
        fig = figure('Color', 'w', 'Position', [100 80 960 780]);
        axh = axes(fig);
    else
        axh = ax;
        cla(axh);
    end

    local_style_axes(axh);
    axh.Visible = 'on';
    xlabel(axh, '$x$', 'Interpreter', 'latex');
    ylabel(axh, '$y$', 'Interpreter', 'latex');
    zlabel(axh, '$z$', 'Interpreter', 'latex');
    title(axh, 'Body axes and $\omega$ in the lab frame', 'Interpreter', 'latex');

    pts = [reshape(tips, [], 3); wlPlot];
    local_finish_3d_axes(axh, pts);
    hold(axh, 'on');

    h1 = plot3(axh, [0 tips(1,1,1)], [0 tips(1,2,1)], [0 tips(1,3,1)], 'LineWidth', 2.3);
    h2 = plot3(axh, [0 tips(1,1,2)], [0 tips(1,2,2)], [0 tips(1,3,2)], 'LineWidth', 2.3);
    h3 = plot3(axh, [0 tips(1,1,3)], [0 tips(1,2,3)], [0 tips(1,3,3)], 'LineWidth', 2.3);
    hw = plot3(axh, [0 wlPlot(1,1)], [0 wlPlot(1,2)], [0 wlPlot(1,3)], 'LineWidth', 2.3);
    lgd = legend(axh, [h1 h2 h3 hw], {'$\hat{e}_1$', '$\hat{e}_2$', '$\hat{e}_3$', omegaLegend}, 'Interpreter', 'latex', 'Location', 'northeast');
    local_style_legend(lgd);
    drawnow;

    if writeVideoFlag
        writerObj = VideoWriter(videoPath, 'MPEG-4');
        writerObj.FrameRate = 30;
        open(writerObj);
    else
        writerObj = [];
    end

    for k = 1:size(tips, 1)
        set(h1, 'XData', [0 tips(k,1,1)], 'YData', [0 tips(k,2,1)], 'ZData', [0 tips(k,3,1)]);
        set(h2, 'XData', [0 tips(k,1,2)], 'YData', [0 tips(k,2,2)], 'ZData', [0 tips(k,3,2)]);
        set(h3, 'XData', [0 tips(k,1,3)], 'YData', [0 tips(k,2,3)], 'ZData', [0 tips(k,3,3)]);
        set(hw, 'XData', [0 wlPlot(k,1)], 'YData', [0 wlPlot(k,2)], 'ZData', [0 wlPlot(k,3)]);
        drawnow;
        if writeVideoFlag
            writeVideo(writerObj, getframe(fig));
        end
    end

    if writeVideoFlag
        close(writerObj);
        close(fig);
    end
end

function local_set_empty_animation_axes(ax)
    cla(ax);
    local_style_axes(ax);
    ax.Visible = 'on';
    xlim(ax, [-1.2 1.2]);
    ylim(ax, [-1.2 1.2]);
    zlim(ax, [-1.2 1.2]);
    pbaspect(ax, [1 1 1]);
    view(ax, 3);
    if isprop(ax, 'Projection')
        ax.Projection = 'perspective';
    end
    xlabel(ax, '$x$', 'Interpreter', 'latex');
    ylabel(ax, '$y$', 'Interpreter', 'latex');
    zlabel(ax, '$z$', 'Interpreter', 'latex');
    title(ax, 'Animation preview', 'Interpreter', 'latex');
    text(ax, 0, 0, 0, '$\mathrm{Run\ a\ simulation,\ then\ click\ Play.}$', ...
        'Interpreter', 'latex', 'HorizontalAlignment', 'center');
end

function local_style_axes(ax)
    hold(ax, 'off');
    grid(ax, 'on');
    box(ax, 'on');
    ax.FontSize = 12;
    ax.LineWidth = 1.0;
    if isprop(ax, 'TitleFontSizeMultiplier')
        ax.TitleFontSizeMultiplier = 1.65;
    end
    if isprop(ax, 'LabelFontSizeMultiplier')
        ax.LabelFontSizeMultiplier = 1.25;
    end
    if isprop(ax, 'TickLabelInterpreter')
        ax.TickLabelInterpreter = 'latex';
    end
    ax.XGrid = 'on';
    ax.YGrid = 'on';
    if isprop(ax, 'ZGrid')
        ax.ZGrid = 'on';
    end
end

function local_finish_2d_axes(ax)
    local_style_axes(ax);
    hold(ax, 'on');
    xline(ax, 0, ':k', 'HandleVisibility', 'off');
    yline(ax, 0, ':k', 'HandleVisibility', 'off');
    plot(ax, 0, 0, '.k', 'MarkerSize', 10, 'HandleVisibility', 'off');
    xr = xlim(ax);
    yr = ylim(ax);
    if diff(xr) <= 0
        xr = [-1 1];
    end
    if diff(yr) <= 0
        yr = [-1 1];
    end
    padX = 0.06 * max(diff(xr), 1e-8);
    padY = 0.10 * max(diff(yr), 1e-8);
    xlim(ax, [xr(1)-padX xr(2)+padX]);
    ylim(ax, [yr(1)-padY yr(2)+padY]);
end

function local_finish_3d_axes(ax, pts)
    local_style_axes(ax);
    ax.Visible = 'on';
    view(ax, 3);
    if isprop(ax, 'Projection')
        ax.Projection = 'perspective';
    end

    if nargin < 2 || isempty(pts)
        pts = [-1 -1 -1; 1 1 1];
    end
    pts = reshape(pts, [], 3);
    pts = pts(all(isfinite(pts), 2), :);
    if isempty(pts)
        pts = [-1 -1 -1; 1 1 1];
    end

    mins = min(pts, [], 1);
    maxs = max(pts, [], 1);
    spans = maxs - mins;
    maxSpan = max(spans);
    if ~isfinite(maxSpan) || maxSpan < 1e-6
        maxSpan = 1.0;
    end
    spans(spans < 0.10 * maxSpan) = 0.10 * maxSpan;
    centers = 0.5 * (mins + maxs);
    halfRanges = 0.60 * spans;

    xlim(ax, centers(1) + [-halfRanges(1), halfRanges(1)]);
    ylim(ax, centers(2) + [-halfRanges(2), halfRanges(2)]);
    zlim(ax, centers(3) + [-halfRanges(3), halfRanges(3)]);
    pbaspect(ax, [1 1 1]);

    hold(ax, 'on');
    xl = xlim(ax);
    yl = ylim(ax);
    zl = zlim(ax);
    plot3(ax, [xl(1) xl(2)], [0 0], [0 0], ':k', 'HandleVisibility', 'off');
    plot3(ax, [0 0], [yl(1) yl(2)], [0 0], ':k', 'HandleVisibility', 'off');
    plot3(ax, [0 0], [0 0], [zl(1) zl(2)], ':k', 'HandleVisibility', 'off');
    plot3(ax, 0, 0, 0, '.k', 'MarkerSize', 12, 'HandleVisibility', 'off');
end

function [scaleFactor, legendText] = local_pick_w3_scale(wb)
    w1Amp = max(abs(wb(:,1)));
    w2Amp = max(abs(wb(:,2)));
    refAmp = max([w1Amp, w2Amp, 1e-12]);
    w3Mean = mean(abs(wb(:,3)));
    if isfinite(w3Mean) && w3Mean > 5 * refAmp
        scaleFactor = 10;
        legendText = '$\omega_3/10$';
    else
        scaleFactor = 1;
        legendText = '$\omega_3$';
    end
end

function [scaleFactor, legendText] = local_pick_animation_omega_scale(wl)
    maxMag = max(vecnorm(wl, 2, 2));
    if isfinite(maxMag) && maxMag > 5
        scaleFactor = 10;
        legendText = '$\omega/10$';
    else
        scaleFactor = 1;
        legendText = '$\omega$';
    end
end

function local_apply_legend(ax)
    lgd = legend(ax, 'Interpreter', 'latex', 'Location', 'northeast');
    local_style_legend(lgd);
end

function local_style_legend(lgd)
    if isempty(lgd) || ~isgraphics(lgd)
        return;
    end
    lgd.FontSize = 13;
    if isprop(lgd, 'NumColumns')
        lgd.NumColumns = 1;
    end
    lgd.Box = 'on';
end

function R = local_axis_angle(axisv, ang)
    axisv = axisv(:) / norm(axisv);
    K = local_skew(axisv);
    R = eye(3) + sin(ang) * K + (1 - cos(ang)) * (K * K);
end

function q = local_euler313_to_quat(eul)
    eul = eul(:);
    R = local_axis_angle([0;0;1], eul(1)) * local_axis_angle([1;0;0], eul(2)) * local_axis_angle([0;0;1], eul(3));
    q = local_rotm_to_quat(R);
end

function Qn = local_normalize_quat_array(Q)
    Qn = Q;
    for k = 1:size(Q,1)
        q = Q(k,:);
        nq = norm(q);
        if nq < 1e-14
            Qn(k,:) = [1 0 0 0];
        else
            Qn(k,:) = q / nq;
        end
    end
end

function Om = local_omega_matrix(w)
    w = w(:);
    Om = [0, -w(1), -w(2), -w(3); ...
          w(1), 0,  w(3), -w(2); ...
          w(2), -w(3), 0,  w(1); ...
          w(3),  w(2), -w(1), 0];
end

function R = local_rotation_map(a, b)
    a = a(:) / norm(a);
    b = b(:) / norm(b);
    v = cross(a, b);
    c = dot(a, b);
    if c > 1 - 1e-12
        R = eye(3);
        return;
    elseif c < -1 + 1e-12
        tmp = null(a.');
        axisv = tmp(:,1);
        R = local_axis_angle(axisv, pi);
        return;
    end
    vx = local_skew(v);
    R = eye(3) + vx + vx * vx / (1 + c);
end

function q = local_rotm_to_quat(R)
    tr = trace(R);
    if tr > 0
        S = sqrt(tr + 1.0) * 2;
        qw = 0.25 * S;
        qx = (R(3,2) - R(2,3)) / S;
        qy = (R(1,3) - R(3,1)) / S;
        qz = (R(2,1) - R(1,2)) / S;
    elseif (R(1,1) > R(2,2)) && (R(1,1) > R(3,3))
        S = sqrt(1.0 + R(1,1) - R(2,2) - R(3,3)) * 2;
        qw = (R(3,2) - R(2,3)) / S;
        qx = 0.25 * S;
        qy = (R(1,2) + R(2,1)) / S;
        qz = (R(1,3) + R(3,1)) / S;
    elseif R(2,2) > R(3,3)
        S = sqrt(1.0 + R(2,2) - R(1,1) - R(3,3)) * 2;
        qw = (R(1,3) - R(3,1)) / S;
        qx = (R(1,2) + R(2,1)) / S;
        qy = 0.25 * S;
        qz = (R(2,3) + R(3,2)) / S;
    else
        S = sqrt(1.0 + R(3,3) - R(1,1) - R(2,2)) * 2;
        qw = (R(2,1) - R(1,2)) / S;
        qx = (R(1,3) + R(3,1)) / S;
        qy = (R(2,3) + R(3,2)) / S;
        qz = 0.25 * S;
    end
    q = [qw; qx; qy; qz];
    q = q / norm(q);
end

function R = local_quat_to_rotm(q)
    q = q(:);
    q = q / norm(q);
    w = q(1);
    x = q(2);
    y = q(3);
    z = q(4);
    R = [1 - 2*(y^2 + z^2),     2*(x*y - z*w),     2*(x*z + y*w); ...
             2*(x*y + z*w), 1 - 2*(x^2 + z^2),     2*(y*z - x*w); ...
             2*(x*z - y*w),     2*(y*z + x*w), 1 - 2*(x^2 + y^2)];
end

function S = local_skew(v)
    v = v(:);
    S = [0 -v(3) v(2); v(3) 0 -v(1); -v(2) v(1) 0];
end
