function rigid_body_rotation()
%RIGID_BODY_ROTATION GUI for two rigid-body modules:
%   1) free rotation
%   2) fixed-point motion in gravity
%
% The package intentionally uses only four .m files:
%   rigid_body_rotation.m
%   rigid_free_motion.m
%   rigid_fixed_rotation.m
%   rigid_common_support.m

    app = struct();
    app.result = [];
    app.lastInput = [];
    app.mainName = 'rigid_body_rotation';
    app.mainDir = fileparts(which(app.mainName));
    if isempty(app.mainDir)
        app.mainDir = fileparts(mfilename('fullpath'));
    end
    app.outputRootDefault = fullfile(app.mainDir, [app.mainName '_output']);
    app.presets = rigid_common_support('defaults');

    build_ui();
    apply_free_preset(app.presets.free(1).name);
    apply_fixed_preset(app.presets.fixed(1).name);
    write_log('Ready. Choose a mode, edit parameters, then click Run.');

    function build_ui()
        scr = get(groot, 'ScreenSize');
        figW = min(1320, max(960, scr(3) - 80));
        figH = min(820, max(640, scr(4) - 120));
        figW = min(figW, scr(3) - 40);
        figH = min(figH, scr(4) - 60);
        figX = max(20, round((scr(3) - figW) / 2));
        figY = max(20, round((scr(4) - figH) / 2));
        app.fig = uifigure( ...
            'Name', 'Rigid Body Rotation Explorer', ...
            'Position', [figX, figY, figW, figH], ...
            'AutoResizeChildren', 'off', ...
            'Color', [0.97 0.97 0.97]);
        app.fig.SizeChangedFcn = @on_resize;

        app.mainGrid = uigridlayout(app.fig, [1, 2]);
        app.mainGrid.Padding = [10 10 10 10];
        app.mainGrid.ColumnSpacing = 10;
        app.mainGrid.RowSpacing = 10;
        app.mainGrid.ColumnWidth = {360, '1x'};
        app.mainGrid.RowHeight = {'1x'};

        app.ctrlPanel = uipanel(app.mainGrid, 'Title', 'Controls', 'FontWeight', 'bold');
        app.ctrlPanel.Layout.Row = 1;
        app.ctrlPanel.Layout.Column = 1;

        app.previewPanel = uipanel(app.mainGrid, 'Title', 'Preview', 'FontWeight', 'bold');
        app.previewPanel.Layout.Row = 1;
        app.previewPanel.Layout.Column = 2;

        ctrlGrid = uigridlayout(app.ctrlPanel, [6, 1]);
        ctrlGrid.RowHeight = {'fit', 330, 'fit', 'fit', 'fit', '1x'};
        ctrlGrid.ColumnWidth = {'1x'};
        ctrlGrid.Padding = [10 10 10 10];
        ctrlGrid.RowSpacing = 8;

        app.infoLabel = uilabel(ctrlGrid, ...
            'Text', 'Two modes only: free rotation and fixed-point motion in gravity.', ...
            'WordWrap', 'on', ...
            'FontSize', 13);
        app.infoLabel.Layout.Row = 1;

        app.modeTabs = uitabgroup(ctrlGrid, 'SelectionChangedFcn', @on_mode_changed);
        app.modeTabs.Layout.Row = 2;

        build_free_tab();
        build_fixed_tab();
        build_output_box(ctrlGrid);
        build_button_row(ctrlGrid);
        build_log_box(ctrlGrid);

        previewGrid = uigridlayout(app.previewPanel, [1, 1]);
        previewGrid.RowHeight = {'1x'};
        previewGrid.ColumnWidth = {'1x'};
        previewGrid.Padding = [6 6 6 6];

        app.previewTabs = uitabgroup(previewGrid);
        app.previewTabs.Layout.Row = 1;
        app.previewTabs.Layout.Column = 1;

        tabNames = {'Lab XY', 'Lab phase/path', 'Body comps', 'Body path', 'Body L', 'Body omega/L', 'Axis tips', 'Animation'};
        tabTitles = { ...
            '$\omega_x(t)$ and $\omega_y(t)$ in the lab frame', ...
            'Phase portrait or trajectory of $\omega$ in the lab frame', ...
            '$\omega_1(t)$, $\omega_2(t)$, and $\omega_3(t)$ in the body frame', ...
            'Trajectory of $\omega$ in the body frame', ...
            'Trajectory of $L$ in the body frame', ...
            '$\omega$ and $L$ in the body frame', ...
            'Body-axis tips in the lab frame', ...
            'Animation preview'};

        app.axes = cell(8,1);
        app.tabs = gobjects(8,1);
        for k = 1:8
            app.tabs(k) = uitab(app.previewTabs, 'Title', tabNames{k});
            tg = uigridlayout(app.tabs(k), [1 1]);
            tg.Padding = [6 6 6 6];
            app.axes{k} = uiaxes(tg);
            app.axes{k}.Layout.Row = 1;
            app.axes{k}.Layout.Column = 1;
            rigid_common_support('style_axes', app.axes{k});
            title(app.axes{k}, tabTitles{k}, 'Interpreter', 'latex');
        end
        rigid_common_support('set_empty_animation_axes', app.axes{8});
        on_mode_changed();
        on_resize();
    end

    function build_free_tab()
        app.freeTab = uitab(app.modeTabs, 'Title', 'Free rotation');
        g = uigridlayout(app.freeTab, [7, 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {160,'1x'};
        g.Padding = [8 8 8 8];

        add_label(g, 1, 'Preset');
        app.freePreset = uidropdown(g, 'Items', {app.presets.free.name}, 'ValueChangedFcn', @on_preset_changed);
        app.freePreset.Layout.Row = 1; app.freePreset.Layout.Column = 2;

        add_label(g, 2, 'I = [I1 I2 I3]');
        app.freeI = uieditfield(g, 'text');
        app.freeI.Layout.Row = 2; app.freeI.Layout.Column = 2;

        add_label(g, 3, 'w0 = [w1 w2 w3]');
        app.freeW0 = uieditfield(g, 'text');
        app.freeW0.Layout.Row = 3; app.freeW0.Layout.Column = 2;

        add_label(g, 4, 'phi0');
        app.freePhi0 = uieditfield(g, 'text');
        app.freePhi0.Layout.Row = 4; app.freePhi0.Layout.Column = 2;

        add_label(g, 5, 'tEnd');
        app.freeTEnd = uieditfield(g, 'text');
        app.freeTEnd.Layout.Row = 5; app.freeTEnd.Layout.Column = 2;

        add_label(g, 6, 'nSamples');
        app.freeNSamples = uieditfield(g, 'text');
        app.freeNSamples.Layout.Row = 6; app.freeNSamples.Layout.Column = 2;

        app.freeHelp = uilabel(g, ...
            'Text', 'The lab $z$-axis is chosen along the constant angular-momentum vector. Figure 2 is the $(\omega_x,\omega_y)$ phase portrait.', ...
            'WordWrap', 'on', ...
            'Interpreter', 'latex');
        app.freeHelp.Layout.Row = 7; app.freeHelp.Layout.Column = [1 2];
    end

    function build_fixed_tab()
        app.fixedTab = uitab(app.modeTabs, 'Title', 'Fixed point in gravity');
        g = uigridlayout(app.fixedTab, [9, 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {160,'1x'};
        g.Padding = [8 8 8 8];

        add_label(g, 1, 'Preset');
        app.fixedPreset = uidropdown(g, 'Items', {app.presets.fixed.name}, 'ValueChangedFcn', @on_preset_changed);
        app.fixedPreset.Layout.Row = 1; app.fixedPreset.Layout.Column = 2;

        add_label(g, 2, 'I = [I1 I2 I3]');
        app.fixedI = uieditfield(g, 'text');
        app.fixedI.Layout.Row = 2; app.fixedI.Layout.Column = 2;

        add_label(g, 3, 'aBody = [a1 a2 a3]');
        app.fixedABody = uieditfield(g, 'text');
        app.fixedABody.Layout.Row = 3; app.fixedABody.Layout.Column = 2;

        add_label(g, 4, 'mass');
        app.fixedMass = uieditfield(g, 'text');
        app.fixedMass.Layout.Row = 4; app.fixedMass.Layout.Column = 2;

        add_label(g, 5, 'g');
        app.fixedG = uieditfield(g, 'text');
        app.fixedG.Layout.Row = 5; app.fixedG.Layout.Column = 2;

        add_label(g, 6, 'Euler0 = [phi theta psi]');
        app.fixedEuler0 = uieditfield(g, 'text');
        app.fixedEuler0.Layout.Row = 6; app.fixedEuler0.Layout.Column = 2;

        add_label(g, 7, 'w0 = [w1 w2 w3]');
        app.fixedW0 = uieditfield(g, 'text');
        app.fixedW0.Layout.Row = 7; app.fixedW0.Layout.Column = 2;

        add_label(g, 8, '[tEnd nSamples]');
        app.fixedTime = uieditfield(g, 'text');
        app.fixedTime.Layout.Row = 8; app.fixedTime.Layout.Column = 2;

        app.fixedHelp = uilabel(g, ...
            'Text', ['General heavy rigid body about a fixed point. ' ...
                     'Enter any initial Euler angles and any initial body-frame angular velocity. ' ...
                     'Regular precession is only one preset.'], ...
            'WordWrap', 'on');
        app.fixedHelp.Layout.Row = 9; app.fixedHelp.Layout.Column = [1 2];
    end

    function build_output_box(parent)
        pnl = uipanel(parent, 'Title', 'Output');
        pnl.Layout.Row = 3;
        g = uigridlayout(pnl, [2, 1]);
        g.RowHeight = {'fit', 'fit'};
        g.ColumnWidth = {'1x'};
        g.Padding = [8 8 8 8];

        app.outputRoot = uieditfield(g, 'text', 'Value', app.outputRootDefault, 'Editable', 'off');
        app.outputRoot.Layout.Row = 1;
        app.outputHint = uilabel(g, ...
            'Text', 'All exports go to rigid_body_rotation_output/<timestamp> under the main-function folder.', ...
            'WordWrap', 'on');
        app.outputHint.Layout.Row = 2;
    end

    function build_button_row(parent)
        g = uigridlayout(parent, [1, 4]);
        g.Layout.Row = 4;
        g.ColumnWidth = {'1x','1x','1x','1x'};
        g.ColumnSpacing = 8;
        app.runBtn = uibutton(g, 'Text', 'Run', 'ButtonPushedFcn', @on_run);
        app.exportBtn = uibutton(g, 'Text', 'Export', 'ButtonPushedFcn', @on_export);
        app.playBtn = uibutton(g, 'Text', 'Play', 'ButtonPushedFcn', @on_play);
        app.clearBtn = uibutton(g, 'Text', 'Clear', 'ButtonPushedFcn', @on_clear);
    end

    function build_log_box(parent)
        app.logBox = uitextarea(parent, 'Editable', 'off');
        app.logBox.Layout.Row = 6;
        app.logBox.Value = {'Ready.'};
    end

    function add_label(parent, row, str)
        lbl = uilabel(parent, 'Text', str);
        lbl.Layout.Row = row;
        lbl.Layout.Column = 1;
        lbl.FontWeight = 'bold';
    end

    function on_resize(~, ~)
        figPos = app.fig.Position;
        if figPos(3) < 1120
            app.mainGrid.RowHeight = {330, '1x'};
            app.mainGrid.ColumnWidth = {'1x'};
            app.ctrlPanel.Layout.Row = 1; app.ctrlPanel.Layout.Column = 1;
            app.previewPanel.Layout.Row = 2; app.previewPanel.Layout.Column = 1;
        else
            app.mainGrid.RowHeight = {'1x'};
            app.mainGrid.ColumnWidth = {360, '1x'};
            app.ctrlPanel.Layout.Row = 1; app.ctrlPanel.Layout.Column = 1;
            app.previewPanel.Layout.Row = 1; app.previewPanel.Layout.Column = 2;
        end
    end

    function on_mode_changed(~, ~)
        if isequal(app.modeTabs.SelectedTab, app.freeTab)
            app.infoLabel.Text = 'Mode 1: free rotation in the body frame, with lab-frame reconstruction.';
        else
            app.infoLabel.Text = 'Mode 2: fixed-point motion in gravity for a general rigid body.';
        end
    end

    function on_preset_changed(src, ~)
        if isequal(src, app.freePreset)
            apply_free_preset(app.freePreset.Value);
        else
            apply_fixed_preset(app.fixedPreset.Value);
        end
    end

    function apply_free_preset(name)
        idx = find(strcmp({app.presets.free.name}, name), 1, 'first');
        p = app.presets.free(idx);
        app.freePreset.Value = p.name;
        app.freeI.Value = rigid_common_support('numvec_to_text', p.I);
        app.freeW0.Value = rigid_common_support('numvec_to_text', p.w0);
        app.freePhi0.Value = sprintf('%.12g', p.phi0);
        app.freeTEnd.Value = sprintf('%.12g', p.tEnd);
        app.freeNSamples.Value = sprintf('%d', p.nSamples);
    end

    function apply_fixed_preset(name)
        idx = find(strcmp({app.presets.fixed.name}, name), 1, 'first');
        p = app.presets.fixed(idx);
        app.fixedPreset.Value = p.name;
        app.fixedI.Value = rigid_common_support('numvec_to_text', p.I);
        app.fixedABody.Value = rigid_common_support('numvec_to_text', p.aBody);
        app.fixedMass.Value = sprintf('%.12g', p.mass);
        app.fixedG.Value = sprintf('%.12g', p.g);
        app.fixedEuler0.Value = rigid_common_support('numvec_to_text', p.euler0);
        app.fixedW0.Value = rigid_common_support('numvec_to_text', p.w0);
        app.fixedTime.Value = rigid_common_support('numvec_to_text', [p.tEnd p.nSamples]);
    end

    function [modeName, inputData] = gather_input()
        if isequal(app.modeTabs.SelectedTab, app.freeTab)
            modeName = 'free';
            inputData.mode = 'free';
            inputData.I = rigid_common_support('parse_vector', app.freeI.Value, 3, 'I');
            inputData.w0 = rigid_common_support('parse_vector', app.freeW0.Value, 3, 'w0');
            inputData.phi0 = rigid_common_support('parse_scalar', app.freePhi0.Value, 'phi0');
            inputData.tEnd = rigid_common_support('parse_scalar', app.freeTEnd.Value, 'tEnd');
            inputData.nSamples = round(rigid_common_support('parse_scalar', app.freeNSamples.Value, 'nSamples'));
        else
            modeName = 'fixed';
            inputData.mode = 'fixed';
            inputData.I = rigid_common_support('parse_vector', app.fixedI.Value, 3, 'I');
            inputData.aBody = rigid_common_support('parse_vector', app.fixedABody.Value, 3, 'aBody');
            inputData.mass = rigid_common_support('parse_scalar', app.fixedMass.Value, 'mass');
            inputData.g = rigid_common_support('parse_scalar', app.fixedG.Value, 'g');
            inputData.euler0 = rigid_common_support('parse_vector', app.fixedEuler0.Value, 3, 'Euler0');
            inputData.w0 = rigid_common_support('parse_vector', app.fixedW0.Value, 3, 'w0');
            tmp = rigid_common_support('parse_vector', app.fixedTime.Value, 2, '[tEnd nSamples]');
            inputData.tEnd = tmp(1);
            inputData.nSamples = round(tmp(2));
        end

        if inputData.nSamples < 200
            error('nSamples must be at least 200.');
        end
        if inputData.tEnd <= 0
            error('tEnd must be positive.');
        end
    end

    function on_run(~, ~)
        try
            [modeName, inputData] = gather_input();
            if strcmp(modeName, 'free')
                app.result = rigid_free_motion(inputData);
            else
                app.result = rigid_fixed_rotation(inputData);
            end
            app.lastInput = inputData;
            rigid_common_support('render_preview', app.axes, app.result);
            app.previewTabs.SelectedTab = app.tabs(1);
            write_log(sprintf('Run finished: %s mode, %d samples.', app.result.mode, numel(app.result.t)));
        catch ME
            write_log(['Run failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Run error');
        end
    end

    function on_export(~, ~)
        try
            if isempty(app.result)
                error('No result is available. Click Run first.');
            end
            outDir = rigid_common_support('export_outputs', app.result, app.lastInput, app.outputRoot.Value, app.mainName);
            write_log(['Export complete: ' outDir]);
        catch ME
            write_log(['Export failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Export error');
        end
    end

    function on_play(~, ~)
        try
            if isempty(app.result)
                error('No result is available. Click Run first.');
            end
            rigid_common_support('play_animation', app.axes{8}, app.result, false, '');
            app.previewTabs.SelectedTab = app.tabs(8);
            write_log('Animation preview updated.');
        catch ME
            write_log(['Play failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Animation error');
        end
    end

    function on_clear(~, ~)
        for k = 1:numel(app.axes)
            cla(app.axes{k});
            rigid_common_support('style_axes', app.axes{k});
            title(app.axes{k}, '', 'Interpreter', 'latex');
        end
        rigid_common_support('set_empty_animation_axes', app.axes{8});
        app.result = [];
        app.lastInput = [];
        write_log('Preview cleared.');
    end

    function write_log(msg)
        oldValue = app.logBox.Value;
        if ischar(oldValue)
            oldValue = {oldValue};
        end
        stamp = char(datetime('now', 'Format', 'HH:mm:ss'));
        app.logBox.Value = [oldValue; {[stamp '  ' msg]}];
        drawnow limitrate;
    end
end
