function rb_style_axes(ax)
%RB_STYLE_AXES Apply a clean, consistent style to an axes or uiaxes.
    cla(ax);
    grid(ax, 'on');
    box(ax, 'on');
    hold(ax, 'on');
    ax.LineWidth = 1.0;
    ax.FontSize = 12;
    ax.TickLabelInterpreter = 'latex';
end
