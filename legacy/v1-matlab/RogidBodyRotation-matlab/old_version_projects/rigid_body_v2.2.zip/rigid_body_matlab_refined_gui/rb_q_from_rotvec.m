function q = rb_q_from_rotvec(v)
%RB_Q_FROM_ROTVEC Quaternion for a finite rotation vector.
    ang = norm(v);
    if ang < 1e-14
        q = [1; 0.5*v(:)];
        q = rb_qnormalize(q);
        return;
    end
    axisVec = v(:) / ang;
    q = [cos(0.5 * ang); axisVec * sin(0.5 * ang)];
    q = rb_qnormalize(q);
end
