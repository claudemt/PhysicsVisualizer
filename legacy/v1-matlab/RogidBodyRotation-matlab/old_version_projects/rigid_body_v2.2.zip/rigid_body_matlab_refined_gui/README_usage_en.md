# Rigid Body Motion Explorer

This package keeps only **two modes**:

1. **Free rotation**
2. **Fixed point in gravity**

## Start

```matlab
cd('rigid_body_matlab_refined_gui')
rigid_body_gui
```

or

```matlab
start_rigid_body_demo
```

## What is exported

Every export creates a time-stamped subfolder inside the selected output root.

Contents:

- `figure_01.png` : lab-frame `omega_x, omega_y` vs time
- `figure_02.png` : lab-frame trajectory of `omega`
- `figure_03.png` : body-frame `omega_1, omega_2, omega_3` vs time
- `figure_04.png` : body-frame trajectory of `omega`
- `figure_05.png` : body-frame trajectory of `L`
- `figure_06.png` : normalized body-frame overlay of `omega` and `L`
- `figure_07.png` : normalized body-axis tips in the lab frame
- `animation.mp4` or fallback AVI
- `parameters.txt`

## GUI notes

- The GUI is English-only.
- The preview area contains exactly **7 figure tabs + 1 animation tab**.
- `AutoResizeChildren` is disabled and the app uses `uigridlayout + SizeChangedFcn`.
- For narrow windows, the layout switches to a stacked configuration.
- For wider windows, the app uses a left control column and a large preview area.

## Plot-text notes

The labels use safer MATLAB LaTeX strings such as:

- `$\omega_x$`
- `$\omega_1$`
- `$\hat e_1$`

This package intentionally avoids fragile combinations such as unsupported bold math macros inside labels.

## Physics notes

### Free rotation
- Assumes `I1 <= I2 <= I3`
- Uses the lecture's branch structure for `L^2 < 2 E I2` and `L^2 > 2 E I2`
- Uses a high-accuracy fallback very close to the separatrix

### Fixed point in gravity
- Uses a quaternion-based rigid-body integrator
- Works for a **general** rigid body about a fixed point in gravity
- `aBody` is the vector from the fixed point to the center of mass, expressed in the body principal-axis frame

## Important simplifications requested in this revision

- Only 2 modes remain
- No damping scan
- No magnetic extension in the GUI
- The animation **does not draw `L`**
- Fig. 1 omits lab-frame `omega_z` because it is constant in the free-rotation convention used here
