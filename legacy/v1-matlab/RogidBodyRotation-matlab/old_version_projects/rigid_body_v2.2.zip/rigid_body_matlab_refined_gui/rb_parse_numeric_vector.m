function v = rb_parse_numeric_vector(txt, nExpected, nameText)
%RB_PARSE_NUMERIC_VECTOR Parse a numeric vector from text.
    if isstring(txt)
        txt = char(txt);
    end
    if isempty(txt)
        error('%s cannot be empty.', nameText);
    end
    cleaned = regexprep(txt, '[\[\],;]', ' ');
    v = str2num(cleaned); %#ok<ST2NM>
    if isempty(v) || ~isnumeric(v)
        error('Could not parse %s as numeric values.', nameText);
    end
    v = v(:).';
    if numel(v) ~= nExpected
        error('%s must contain exactly %d numbers.', nameText, nExpected);
    end
end
