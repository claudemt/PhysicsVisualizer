function res = rb_sim_fixed_gravity(p)
%RB_SIM_FIXED_GRAVITY Fixed-point motion of a general rigid body in gravity.

    I = p.I(:);
    aBody = p.aBody(:);
    w0 = p.w0(:);
    euler0 = p.euler0(:);

    if any(I <= 0)
        error('All inertia values must be positive.');
    end

    t = linspace(0, p.tEnd, p.nSamples).';
    R0 = rb_R_from_euler_zxz(euler0);
    q0 = rb_q_from_R(R0);
    y0 = [w0; q0];

    opts = odeset('RelTol', 1e-9, 'AbsTol', 1e-10, 'MaxStep', max(p.tEnd / p.nSamples, 1e-3));
    sol = ode113(@(tt, yy) rb_rhs_fixed(tt, yy, I, aBody, p.mass, p.g), [t(1) t(end)], y0, opts);
    Y = deval(sol, t).';

    wBody = Y(:, 1:3);
    qPath = Y(:, 4:7);

    n = numel(t);
    R = zeros(3,3,n);
    axesTips = zeros(n,3,3);
    wLab = zeros(n,3);
    LBody = I.' .* wBody;
    LLab = zeros(n,3);
    torqueBody = zeros(n,3);
    energy = zeros(n,1);

    gLab = [0;0;-p.g];
    for k = 1:n
        qk = rb_qnormalize(qPath(k, :).');
        Rk = rb_R_from_q(qk);
        R(:,:,k) = Rk;
        axesTips(k,:,1) = Rk(:,1).' / norm(Rk(:,1));
        axesTips(k,:,2) = Rk(:,2).' / norm(Rk(:,2));
        axesTips(k,:,3) = Rk(:,3).' / norm(Rk(:,3));
        wLab(k,:) = (Rk * wBody(k,:).').';
        LLab(k,:) = (Rk * LBody(k,:).').';

        gBody = Rk.' * gLab;
        torqueBody(k,:) = (p.mass * cross(aBody, gBody)).';
        rcmLab = Rk * aBody;
        energy(k) = 0.5 * sum(I.' .* (wBody(k,:).^2)) + p.mass * p.g * rcmLab(3);
    end

    res = struct();
    res.mode = 'fixed';
    res.branch = 'gravity';
    res.t = t;
    res.I = I;
    res.aBody = aBody;
    res.mass = p.mass;
    res.g = p.g;
    res.wBody = wBody;
    res.wLab = wLab;
    res.LBody = LBody;
    res.LLab = LLab;
    res.torqueBody = torqueBody;
    res.R = R;
    res.axesTips = axesTips;
    res.energy = energy;
    res.LNorm = vecnorm(LBody, 2, 2);
    res.parameters = p;
    res.notes = 'General heavy rigid body about a fixed point.';
end
