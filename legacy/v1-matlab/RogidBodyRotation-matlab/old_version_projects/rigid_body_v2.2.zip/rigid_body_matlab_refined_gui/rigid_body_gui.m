function rigid_body_gui()
%RIGID_BODY_GUI Compact GUI for rigid-body free rotation and fixed-point motion.
%
% English-only interface.
% Seven figures plus one animation preview.
% Export root: <main_function_name>_output/<timestamp>/
%
% Notes:
%   * Uses exact closed-form body-frame free rotation away from the separatrix.
%   * Uses quaternion-based time integration for fixed-point motion in gravity.
%   * Uses uigridlayout + SizeChangedFcn for responsive resizing.

    app = struct();
    app.result = [];
    app.lastInput = [];
    app.outputRootDefault = fullfile(fileparts(mfilename('fullpath')), [mfilename '_output']);
    app.presets = rb_defaults();

    build_ui();
    apply_free_preset(app.presets.free(1).name);
    apply_fixed_preset(app.presets.fixed(1).name);
    write_log('Ready. Choose a mode, edit parameters, then click Run.');

    function build_ui()
        app.fig = uifigure( ...
            'Name', 'Rigid Body Motion Explorer', ...
            'Position', [60, 50, 1500, 920], ...
            'AutoResizeChildren', 'off');
        app.fig.SizeChangedFcn = @on_resize;

        app.mainGrid = uigridlayout(app.fig, [2, 2]);
        app.mainGrid.RowHeight = {'1x', '1x'};
        app.mainGrid.ColumnWidth = {380, '1x'};
        app.mainGrid.Padding = [10 10 10 10];
        app.mainGrid.RowSpacing = 10;
        app.mainGrid.ColumnSpacing = 10;

        app.ctrlPanel = uipanel(app.mainGrid, 'Title', 'Controls');
        app.ctrlPanel.Layout.Row = [1 2];
        app.ctrlPanel.Layout.Column = 1;

        app.previewPanel = uipanel(app.mainGrid, 'Title', 'Preview');
        app.previewPanel.Layout.Row = [1 2];
        app.previewPanel.Layout.Column = 2;

        ctrlGrid = uigridlayout(app.ctrlPanel, [6, 1]);
        ctrlGrid.RowHeight = {'fit', 300, 'fit', 'fit', 'fit', '1x'};
        ctrlGrid.ColumnWidth = {'1x'};
        ctrlGrid.Padding = [10 10 10 10];
        ctrlGrid.RowSpacing = 8;

        app.infoLabel = uilabel(ctrlGrid, ...
            'Text', 'Two modes only: exact free rotation and fixed-point motion in gravity.', ...
            'WordWrap', 'on', ...
            'HorizontalAlignment', 'left');
        app.infoLabel.Layout.Row = 1;

        app.modeTabs = uitabgroup(ctrlGrid, 'SelectionChangedFcn', @on_mode_changed);
        app.modeTabs.Layout.Row = 2;

        build_free_tab();
        build_fixed_tab();
        build_output_box(ctrlGrid);
        build_button_row(ctrlGrid);
        build_log_box(ctrlGrid);

        previewGrid = uigridlayout(app.previewPanel, [1, 1]);
        previewGrid.RowHeight = {'1x'};
        previewGrid.ColumnWidth = {'1x'};
        previewGrid.Padding = [6 6 6 6];

        app.previewTabs = uitabgroup(previewGrid);
        app.previewTabs.Layout.Row = 1;
        app.previewTabs.Layout.Column = 1;

        tabTitles = { ...
            'Lab $\omega_x,\omega_y$ vs $t$', ...
            'Lab $\omega$ trajectory', ...
            'Body $\omega_1,\omega_2,\omega_3$ vs $t$', ...
            'Body $\omega$ trajectory', ...
            'Body $L$ trajectory', ...
            'Body normalized $\omega/L$ overlay', ...
            'Normalized body-axis tips in lab', ...
            'Animation'};

        app.axes = cell(8,1);
        app.tabs = gobjects(8,1);
        tabNames = {'Lab xy', 'Lab path', 'Body comp', 'Body path', 'Body L', 'Overlay', 'Axis tips', 'Animation'};
        for k = 1:8
            app.tabs(k) = uitab(app.previewTabs, 'Title', tabNames{k});
            tg = uigridlayout(app.tabs(k), [1 1]);
            tg.Padding = [6 6 6 6];
            tg.RowHeight = {'1x'};
            tg.ColumnWidth = {'1x'};
            app.axes{k} = uiaxes(tg);
            app.axes{k}.Layout.Row = 1;
            app.axes{k}.Layout.Column = 1;
            rb_style_axes(app.axes{k});
            title(app.axes{k}, tabTitles{k}, 'Interpreter', 'latex');
        end

        cla(app.axes{8});
        axis(app.axes{8}, 'equal');
        view(app.axes{8}, 3);
        xlabel(app.axes{8}, '$x$', 'Interpreter', 'latex');
        ylabel(app.axes{8}, '$y$', 'Interpreter', 'latex');
        zlabel(app.axes{8}, '$z$', 'Interpreter', 'latex');
        title(app.axes{8}, 'Animation preview', 'Interpreter', 'latex');
        text(app.axes{8}, 0, 0, 0, '$\mathrm{Run\ a\ simulation,\ then\ click\ Play.}$', ...
            'Interpreter', 'latex', 'HorizontalAlignment', 'center');

        on_mode_changed();
        on_resize();
    end

    function build_free_tab()
        app.freeTab = uitab(app.modeTabs, 'Title', 'Free rotation');

        g = uigridlayout(app.freeTab, [7, 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {135,'1x'};
        g.Padding = [8 8 8 8];
        g.RowSpacing = 7;

        add_label(g, 1, 'Preset');
        app.freePreset = uidropdown(g, 'Items', {app.presets.free.name}, ...
            'ValueChangedFcn', @on_preset_changed);
        app.freePreset.Layout.Row = 1; app.freePreset.Layout.Column = 2;

        add_label(g, 2, 'I = [I1 I2 I3]');
        app.freeI = uieditfield(g, 'text');
        app.freeI.Layout.Row = 2; app.freeI.Layout.Column = 2;

        add_label(g, 3, 'w0 = [w1 w2 w3]');
        app.freeW0 = uieditfield(g, 'text');
        app.freeW0.Layout.Row = 3; app.freeW0.Layout.Column = 2;

        add_label(g, 4, 'phi0');
        app.freePhi0 = uieditfield(g, 'text');
        app.freePhi0.Layout.Row = 4; app.freePhi0.Layout.Column = 2;

        add_label(g, 5, 'tEnd');
        app.freeTEnd = uieditfield(g, 'text');
        app.freeTEnd.Layout.Row = 5; app.freeTEnd.Layout.Column = 2;

        add_label(g, 6, 'nSamples');
        app.freeNSamples = uieditfield(g, 'text');
        app.freeNSamples.Layout.Row = 6; app.freeNSamples.Layout.Column = 2;

        app.freeHelp = uilabel(g, ...
            'Text', ['Assume I1 <= I2 <= I3. The lab z-axis is chosen along the constant angular momentum ' ...
                     'vector, so the lab-frame omega_z component is constant and omitted from Fig. 1.'], ...
            'WordWrap', 'on');
        app.freeHelp.Layout.Row = 7;
        app.freeHelp.Layout.Column = [1 2];
    end

    function build_fixed_tab()
        app.fixedTab = uitab(app.modeTabs, 'Title', 'Fixed point in gravity');

        g = uigridlayout(app.fixedTab, [9, 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {135,'1x'};
        g.Padding = [8 8 8 8];
        g.RowSpacing = 7;

        add_label(g, 1, 'Preset');
        app.fixedPreset = uidropdown(g, 'Items', {app.presets.fixed.name}, ...
            'ValueChangedFcn', @on_preset_changed);
        app.fixedPreset.Layout.Row = 1; app.fixedPreset.Layout.Column = 2;

        add_label(g, 2, 'I = [I1 I2 I3]');
        app.fixedI = uieditfield(g, 'text');
        app.fixedI.Layout.Row = 2; app.fixedI.Layout.Column = 2;

        add_label(g, 3, 'aBody = [a1 a2 a3]');
        app.fixedABody = uieditfield(g, 'text');
        app.fixedABody.Layout.Row = 3; app.fixedABody.Layout.Column = 2;

        add_label(g, 4, 'mass');
        app.fixedMass = uieditfield(g, 'text');
        app.fixedMass.Layout.Row = 4; app.fixedMass.Layout.Column = 2;

        add_label(g, 5, 'g');
        app.fixedG = uieditfield(g, 'text');
        app.fixedG.Layout.Row = 5; app.fixedG.Layout.Column = 2;

        add_label(g, 6, 'Euler0 = [phi theta psi]');
        app.fixedEuler0 = uieditfield(g, 'text');
        app.fixedEuler0.Layout.Row = 6; app.fixedEuler0.Layout.Column = 2;

        add_label(g, 7, 'w0 = [w1 w2 w3]');
        app.fixedW0 = uieditfield(g, 'text');
        app.fixedW0.Layout.Row = 7; app.fixedW0.Layout.Column = 2;

        add_label(g, 8, '[tEnd nSamples]');
        app.fixedTime = uieditfield(g, 'text');
        app.fixedTime.Layout.Row = 8; app.fixedTime.Layout.Column = 2;

        app.fixedHelp = uilabel(g, ...
            'Text', ['General heavy rigid body about a fixed point. aBody points from the fixed point to the center ' ...
                     'of mass, written in the body principal-axis frame.'], ...
            'WordWrap', 'on');
        app.fixedHelp.Layout.Row = 9;
        app.fixedHelp.Layout.Column = [1 2];
    end

    function build_output_box(parent)
        pnl = uipanel(parent, 'Title', 'Output');
        pnl.Layout.Row = 3;
        pnl.Layout.Column = 1;

        g = uigridlayout(pnl, [2, 3]);
        g.RowHeight = {'fit','fit'};
        g.ColumnWidth = {95,'1x',90};
        g.Padding = [8 8 8 8];

        add_label(g, 1, 'Root folder');
        app.outputRoot = uieditfield(g, 'text', 'Value', app.outputRootDefault);
        app.outputRoot.Layout.Row = 1; app.outputRoot.Layout.Column = 2;

        app.browseBtn = uibutton(g, 'Text', 'Browse', 'ButtonPushedFcn', @on_browse);
        app.browseBtn.Layout.Row = 1; app.browseBtn.Layout.Column = 3;

        app.outputHint = uilabel(g, ...
            'Text', 'Exported files go to a timestamped subfolder under the chosen root.', ...
            'WordWrap', 'on');
        app.outputHint.Layout.Row = 2;
        app.outputHint.Layout.Column = [1 3];
    end

    function build_button_row(parent)
        g = uigridlayout(parent, [1, 4]);
        g.Layout.Row = 4;
        g.Layout.Column = 1;
        g.ColumnWidth = {'1x','1x','1x','1x'};
        g.ColumnSpacing = 8;

        app.runBtn = uibutton(g, 'Text', 'Run', 'ButtonPushedFcn', @on_run);
        app.exportBtn = uibutton(g, 'Text', 'Export', 'ButtonPushedFcn', @on_export);
        app.playBtn = uibutton(g, 'Text', 'Play', 'ButtonPushedFcn', @on_play);
        app.clearBtn = uibutton(g, 'Text', 'Clear', 'ButtonPushedFcn', @on_clear);
    end

    function build_log_box(parent)
        app.logBox = uitextarea(parent, 'Editable', 'off');
        app.logBox.Layout.Row = 6;
        app.logBox.Layout.Column = 1;
        app.logBox.Value = {'Ready.'};
    end

    function add_label(parent, row, textString)
        lbl = uilabel(parent, 'Text', textString);
        lbl.Layout.Row = row;
        lbl.Layout.Column = 1;
    end

    function on_resize(~, ~)
        pos = app.fig.Position;
        w = pos(3);
        if w < 1180
            app.mainGrid.RowHeight = {360, '1x'};
            app.mainGrid.ColumnWidth = {'1x', '1x'};
            app.ctrlPanel.Layout.Row = 1;
            app.ctrlPanel.Layout.Column = [1 2];
            app.previewPanel.Layout.Row = 2;
            app.previewPanel.Layout.Column = [1 2];
        else
            if w < 1450
                leftWidth = 340;
            else
                leftWidth = 390;
            end
            app.mainGrid.RowHeight = {'1x','1x'};
            app.mainGrid.ColumnWidth = {leftWidth, '1x'};
            app.ctrlPanel.Layout.Row = [1 2];
            app.ctrlPanel.Layout.Column = 1;
            app.previewPanel.Layout.Row = [1 2];
            app.previewPanel.Layout.Column = 2;
        end
    end

    function on_mode_changed(~, ~)
        if isequal(app.modeTabs.SelectedTab, app.freeTab)
            app.infoLabel.Text = 'Mode 1: exact free rotation in the body frame, plus lab-frame reconstruction.';
        else
            app.infoLabel.Text = 'Mode 2: fixed-point motion in gravity for a general rigid body.';
        end
    end

    function on_preset_changed(src, ~)
        if isequal(src, app.freePreset)
            apply_free_preset(app.freePreset.Value);
        elseif isequal(src, app.fixedPreset)
            apply_fixed_preset(app.fixedPreset.Value);
        end
    end

    function apply_free_preset(name)
        idx = find(strcmp({app.presets.free.name}, name), 1, 'first');
        if isempty(idx), return; end
        p = app.presets.free(idx);
        app.freePreset.Value = p.name;
        app.freeI.Value = rb_numvec_to_text(p.I);
        app.freeW0.Value = rb_numvec_to_text(p.w0);
        app.freePhi0.Value = sprintf('%.12g', p.phi0);
        app.freeTEnd.Value = sprintf('%.12g', p.tEnd);
        app.freeNSamples.Value = sprintf('%d', p.nSamples);
    end

    function apply_fixed_preset(name)
        idx = find(strcmp({app.presets.fixed.name}, name), 1, 'first');
        if isempty(idx), return; end
        p = app.presets.fixed(idx);
        app.fixedPreset.Value = p.name;
        app.fixedI.Value = rb_numvec_to_text(p.I);
        app.fixedABody.Value = rb_numvec_to_text(p.aBody);
        app.fixedMass.Value = sprintf('%.12g', p.mass);
        app.fixedG.Value = sprintf('%.12g', p.g);
        app.fixedEuler0.Value = rb_numvec_to_text(p.euler0);
        app.fixedW0.Value = rb_numvec_to_text(p.w0);
        app.fixedTime.Value = rb_numvec_to_text([p.tEnd p.nSamples]);
    end

    function on_browse(~, ~)
        startFolder = app.outputRoot.Value;
        if isempty(startFolder) || ~isfolder(startFolder)
            startFolder = fileparts(app.outputRootDefault);
        end
        chosen = uigetdir(startFolder, 'Choose output root folder');
        if isequal(chosen, 0)
            return;
        end
        app.outputRoot.Value = chosen;
        write_log(['Output root set to: ' chosen]);
    end

    function [modeName, inputData] = gather_input()
        if isequal(app.modeTabs.SelectedTab, app.freeTab)
            modeName = 'free';
            inputData = struct();
            inputData.mode = 'free';
            inputData.I = rb_parse_numeric_vector(app.freeI.Value, 3, 'I');
            inputData.w0 = rb_parse_numeric_vector(app.freeW0.Value, 3, 'w0');
            inputData.phi0 = rb_parse_scalar(app.freePhi0.Value, 'phi0');
            inputData.tEnd = rb_parse_scalar(app.freeTEnd.Value, 'tEnd');
            inputData.nSamples = round(rb_parse_scalar(app.freeNSamples.Value, 'nSamples'));
        else
            modeName = 'fixed';
            inputData = struct();
            inputData.mode = 'fixed';
            inputData.I = rb_parse_numeric_vector(app.fixedI.Value, 3, 'I');
            inputData.aBody = rb_parse_numeric_vector(app.fixedABody.Value, 3, 'aBody');
            inputData.mass = rb_parse_scalar(app.fixedMass.Value, 'mass');
            inputData.g = rb_parse_scalar(app.fixedG.Value, 'g');
            inputData.euler0 = rb_parse_numeric_vector(app.fixedEuler0.Value, 3, 'Euler0');
            inputData.w0 = rb_parse_numeric_vector(app.fixedW0.Value, 3, 'w0');
            tmp = rb_parse_numeric_vector(app.fixedTime.Value, 2, '[tEnd nSamples]');
            inputData.tEnd = tmp(1);
            inputData.nSamples = round(tmp(2));
        end

        if inputData.nSamples < 200
            error('nSamples must be at least 200.');
        end
        if inputData.tEnd <= 0
            error('tEnd must be positive.');
        end
    end

    function on_run(~, ~)
        try
            [modeName, inputData] = gather_input();
            if strcmp(modeName, 'free')
                app.result = rb_sim_free_exact(inputData);
            else
                app.result = rb_sim_fixed_gravity(inputData);
            end
            app.lastInput = inputData;
            rb_render_preview(app.axes, app.result);
            app.previewTabs.SelectedTab = app.tabs(1);
            write_log(sprintf('Run finished: %s mode, %d samples.', app.result.mode, numel(app.result.t)));
        catch ME
            write_log(['Run failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Run error');
        end
    end

    function on_export(~, ~)
        try
            if isempty(app.result)
                error('No result is available. Click Run first.');
            end
            outDir = rb_export_outputs(app.result, app.lastInput, app.outputRoot.Value);
            write_log(['Export complete: ' outDir]);
        catch ME
            write_log(['Export failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Export error');
        end
    end

    function on_play(~, ~)
        try
            if isempty(app.result)
                error('No result is available. Click Run first.');
            end
            rb_play_animation(app.axes{8}, app.result, false, '');
            app.previewTabs.SelectedTab = app.tabs(8);
            write_log('Animation preview updated.');
        catch ME
            write_log(['Play failed: ' ME.message]);
            uialert(app.fig, ME.message, 'Animation error');
        end
    end

    function on_clear(~, ~)
        for k = 1:numel(app.axes)
            cla(app.axes{k});
            rb_style_axes(app.axes{k});
        end
        title(app.axes{8}, 'Animation preview', 'Interpreter', 'latex');
        text(app.axes{8}, 0, 0, 0, '$\mathrm{Run\ a\ simulation,\ then\ click\ Play.}$', ...
            'Interpreter', 'latex', 'HorizontalAlignment', 'center');
        app.result = [];
        app.lastInput = [];
        write_log('Preview cleared.');
    end

    function write_log(msg)
        oldValue = app.logBox.Value;
        if ischar(oldValue)
            oldValue = {oldValue};
        end
        stamp = char(datetime('now', 'Format', 'HH:mm:ss'));
        app.logBox.Value = [oldValue; {[stamp '  ' msg]}];
        drawnow limitrate;
    end
end
