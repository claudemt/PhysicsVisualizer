function res = rb_sim_free_ode_fallback(p)
%RB_SIM_FREE_ODE_FALLBACK High-accuracy numerical fallback near the separatrix.

    I = p.I(:);
    w0 = p.w0(:);
    t = linspace(0, p.tEnd, p.nSamples).';

    R0 = rb_initial_free_R(I, w0, p.phi0);
    q0 = rb_q_from_R(R0);
    y0 = [w0; q0];

    opts = odeset('RelTol', 1e-11, 'AbsTol', 1e-12, 'MaxStep', max(p.tEnd / p.nSamples, 1e-3));
    sol = ode113(@(tt, yy) rb_rhs_free(tt, yy, I), [t(1) t(end)], y0, opts);
    Y = deval(sol, t).';

    wBody = Y(:, 1:3);
    qPath = Y(:, 4:7);

    n = numel(t);
    R = zeros(3,3,n);
    axesTips = zeros(n,3,3);
    wLab = zeros(n,3);
    LBody = I.' .* wBody;
    LLab = zeros(n,3);

    for k = 1:n
        qk = rb_qnormalize(qPath(k, :).');
        Rk = rb_R_from_q(qk);
        R(:,:,k) = Rk;
        axesTips(k,:,1) = Rk(:,1).' / norm(Rk(:,1));
        axesTips(k,:,2) = Rk(:,2).' / norm(Rk(:,2));
        axesTips(k,:,3) = Rk(:,3).' / norm(Rk(:,3));
        wLab(k,:) = (Rk * wBody(k,:).').';
        LLab(k,:) = (Rk * LBody(k,:).').';
    end

    res = struct();
    res.mode = 'free';
    res.branch = 'fallback';
    res.t = t;
    res.I = I;
    res.wBody = wBody;
    res.wLab = wLab;
    res.LBody = LBody;
    res.LLab = LLab;
    res.R = R;
    res.axesTips = axesTips;
    res.energy = 0.5 * sum(wBody.^2 .* I.', 2);
    res.LNorm = vecnorm(LBody, 2, 2);
    res.parameters = p;
    res.notes = 'High-accuracy ODE fallback near the separatrix.';
end
