function R = rb_rotz(a)
%RB_ROTZ Active rotation about z.
    c = cos(a); s = sin(a);
    R = [c -s 0; s c 0; 0 0 1];
end
