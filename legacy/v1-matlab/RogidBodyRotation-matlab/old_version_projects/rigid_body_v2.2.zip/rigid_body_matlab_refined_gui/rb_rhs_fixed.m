function dydt = rb_rhs_fixed(~, y, I, aBody, mass, g)
%RB_RHS_FIXED Quaternion-based heavy rigid-body equations about a fixed point.
    w = y(1:3);
    q = rb_qnormalize(y(4:7));
    gLab = [0;0;-g];
    gBody = rb_R_from_q(q).' * gLab;
    tau = mass * cross(aBody, gBody);
    Iw = I .* w;
    wdot = (tau - cross(w, Iw)) ./ I;
    qdot = 0.5 * rb_qmult(q, [0; w]);
    dydt = [wdot; qdot];
end
