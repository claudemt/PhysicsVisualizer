function rb_write_parameters(filePath, res, inputData)
%RB_WRITE_PARAMETERS Write a plain-text parameter summary.

    fid = fopen(filePath, 'w');
    if fid < 0
        error('Could not create %s.', filePath);
    end
    cleanup = onCleanup(@() fclose(fid));

    fprintf(fid, 'Rigid Body Motion Explorer export\n');
    fprintf(fid, 'Timestamp: %s\n', char(datetime('now')));
    fprintf(fid, 'Mode: %s\n', res.mode);
    fprintf(fid, 'Branch: %s\n', res.branch);
    fprintf(fid, 'Notes: %s\n', res.notes);
    fprintf(fid, '\n');

    fields = fieldnames(inputData);
    for k = 1:numel(fields)
        name = fields{k};
        value = inputData.(name);
        if isnumeric(value)
            if isscalar(value)
                fprintf(fid, '%s = %.16g\n', name, value);
            else
                fprintf(fid, '%s = %s\n', name, mat2str(value, 16));
            end
        else
            fprintf(fid, '%s = %s\n', name, char(string(value)));
        end
    end

    fprintf(fid, '\nDiagnostics\n');
    fprintf(fid, 'E(t0) = %.16g\n', res.energy(1));
    fprintf(fid, 'E(tEnd) = %.16g\n', res.energy(end));
    fprintf(fid, '|L|(t0) = %.16g\n', res.LNorm(1));
    fprintf(fid, '|L|(tEnd) = %.16g\n', res.LNorm(end));
end
