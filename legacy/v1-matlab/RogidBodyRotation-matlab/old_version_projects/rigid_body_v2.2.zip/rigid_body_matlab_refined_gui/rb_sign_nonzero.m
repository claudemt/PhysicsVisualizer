function s = rb_sign_nonzero(x)
%RB_SIGN_NONZERO Sign with zero mapped to +1.
    if x < 0
        s = -1;
    else
        s = 1;
    end
end
