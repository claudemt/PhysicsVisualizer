function rb_render_single_plot(ax, res, idx)
%RB_RENDER_SINGLE_PLOT Render one of the seven export figures.

    t = res.t(:);
    wLab = res.wLab;
    wBody = res.wBody;
    LBody = res.LBody;
    axesTips = res.axesTips;

    switch idx
        case 1
            plot(ax, t, wLab(:,1), 'LineWidth', 1.5, 'DisplayName', '$\omega_x$');
            plot(ax, t, wLab(:,2), 'LineWidth', 1.5, 'DisplayName', '$\omega_y$');
            xlabel(ax, '$t$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega$', 'Interpreter', 'latex');
            title(ax, 'Lab $\omega_x,\omega_y$ vs $t$', 'Interpreter', 'latex');
            legend(ax, 'Interpreter', 'latex', 'Location', 'best');

        case 2
            plot3(ax, wLab(:,1), wLab(:,2), wLab(:,3), 'LineWidth', 1.6);
            xlabel(ax, '$\omega_x$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega_y$', 'Interpreter', 'latex');
            zlabel(ax, '$\omega_z$', 'Interpreter', 'latex');
            title(ax, 'Lab-frame trajectory of $\omega$', 'Interpreter', 'latex');
            axis(ax, 'equal'); view(ax, 3);

        case 3
            plot(ax, t, wBody(:,1), 'LineWidth', 1.5, 'DisplayName', '$\omega_1$');
            plot(ax, t, wBody(:,2), 'LineWidth', 1.5, 'DisplayName', '$\omega_2$');
            plot(ax, t, wBody(:,3), 'LineWidth', 1.5, 'DisplayName', '$\omega_3$');
            xlabel(ax, '$t$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega$', 'Interpreter', 'latex');
            title(ax, 'Body $\omega_1,\omega_2,\omega_3$ vs $t$', 'Interpreter', 'latex');
            legend(ax, 'Interpreter', 'latex', 'Location', 'best');

        case 4
            plot3(ax, wBody(:,1), wBody(:,2), wBody(:,3), 'LineWidth', 1.6);
            xlabel(ax, '$\omega_1$', 'Interpreter', 'latex');
            ylabel(ax, '$\omega_2$', 'Interpreter', 'latex');
            zlabel(ax, '$\omega_3$', 'Interpreter', 'latex');
            title(ax, 'Body-frame trajectory of $\omega$', 'Interpreter', 'latex');
            axis(ax, 'equal'); view(ax, 3);

        case 5
            plot3(ax, LBody(:,1), LBody(:,2), LBody(:,3), 'LineWidth', 1.6);
            xlabel(ax, '$L_1$', 'Interpreter', 'latex');
            ylabel(ax, '$L_2$', 'Interpreter', 'latex');
            zlabel(ax, '$L_3$', 'Interpreter', 'latex');
            title(ax, 'Body-frame trajectory of $L$', 'Interpreter', 'latex');
            axis(ax, 'equal'); view(ax, 3);

        case 6
            wn = wBody ./ max(vecnorm(wBody, 2, 2), eps);
            Ln = LBody ./ max(vecnorm(LBody, 2, 2), eps);
            plot3(ax, wn(:,1), wn(:,2), wn(:,3), 'LineWidth', 1.6, 'DisplayName', '$\omega/\|\omega\|$');
            plot3(ax, Ln(:,1), Ln(:,2), Ln(:,3), '--', 'LineWidth', 1.3, 'DisplayName', '$L/\|L\|$');
            xlabel(ax, '$x$', 'Interpreter', 'latex');
            ylabel(ax, '$y$', 'Interpreter', 'latex');
            zlabel(ax, '$z$', 'Interpreter', 'latex');
            title(ax, 'Body-frame normalized $\omega$ and $L$', 'Interpreter', 'latex');
            axis(ax, 'equal'); view(ax, 3);
            legend(ax, 'Interpreter', 'latex', 'Location', 'best');

        case 7
            [xs, ys, zs] = sphere(36);
            surf(ax, xs, ys, zs, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.15, 'HandleVisibility', 'off');
            plot3(ax, axesTips(:,1,1), axesTips(:,2,1), axesTips(:,3,1), 'LineWidth', 1.5, 'DisplayName', '$\hat e_1$');
            plot3(ax, axesTips(:,1,2), axesTips(:,2,2), axesTips(:,3,2), 'LineWidth', 1.5, 'DisplayName', '$\hat e_2$');
            plot3(ax, axesTips(:,1,3), axesTips(:,2,3), axesTips(:,3,3), 'LineWidth', 1.5, 'DisplayName', '$\hat e_3$');
            xlabel(ax, '$x$', 'Interpreter', 'latex');
            ylabel(ax, '$y$', 'Interpreter', 'latex');
            zlabel(ax, '$z$', 'Interpreter', 'latex');
            title(ax, 'Normalized body-axis tips in the lab frame', 'Interpreter', 'latex');
            axis(ax, 'equal'); view(ax, 3);
            legend(ax, 'Interpreter', 'latex', 'Location', 'best');
    end
end
