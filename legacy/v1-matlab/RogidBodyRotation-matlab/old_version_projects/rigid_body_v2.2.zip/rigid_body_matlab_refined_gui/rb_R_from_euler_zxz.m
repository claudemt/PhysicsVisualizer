function R = rb_R_from_euler_zxz(eulerAngles)
%RB_R_FROM_EULER_ZXZ Body-to-lab rotation from ZXZ Euler angles [phi theta psi].
    phi = eulerAngles(1);
    theta = eulerAngles(2);
    psi = eulerAngles(3);
    R = rb_rotz(phi) * rb_rotx(theta) * rb_rotz(psi);
end
