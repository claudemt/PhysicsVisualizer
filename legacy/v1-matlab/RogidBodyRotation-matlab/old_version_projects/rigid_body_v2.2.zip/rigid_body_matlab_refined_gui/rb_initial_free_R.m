function R0 = rb_initial_free_R(I, w0, phi0)
%RB_INITIAL_FREE_R Construct R0 so that lab z is parallel to constant L.

    Lb = I(:) .* w0(:);
    L = norm(Lb);
    if L < eps
        error('The angular momentum must be nonzero.');
    end
    kb = Lb / L;

    seed = [1;0;0];
    if abs(dot(seed, kb)) > 0.9
        seed = [0;1;0];
    end
    ub = seed - kb * dot(seed, kb);
    ub = ub / norm(ub);
    vb = cross(kb, ub);
    vb = vb / norm(vb);

    ex = [cos(phi0); sin(phi0); 0];
    ey = [-sin(phi0); cos(phi0); 0];
    ez = [0;0;1];

    B = [ub vb kb];
    Lframe = [ex ey ez];
    R0 = Lframe * B.';
end
