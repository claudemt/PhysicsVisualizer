function rb_play_animation(axOrFig, res, writeVideo, videoPath)
%RB_PLAY_ANIMATION Draw or export the body-axis animation.
%
% The animation intentionally does not draw L in the lab frame because L is
% constant there. Only the body axes and omega are animated.

    if nargin < 3
        writeVideo = false;
    end
    if nargin < 4
        videoPath = '';
    end

    if isa(axOrFig, 'matlab.ui.control.UIAxes') || isa(axOrFig, 'matlab.graphics.axis.Axes')
        ax = axOrFig;
        fig = ancestor(ax, 'figure');
    else
        fig = axOrFig;
        clf(fig);
        ax = axes('Parent', fig);
    end

    cla(ax);
    rb_style_axes(ax);

    [xs, ys, zs] = sphere(30);
    surf(ax, xs, ys, zs, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.12, 'HandleVisibility', 'off');
    axis(ax, 'equal');
    axis(ax, 1.25 * [-1 1 -1 1 -1 1]);
    view(ax, 3);
    xlabel(ax, '$x$', 'Interpreter', 'latex');
    ylabel(ax, '$y$', 'Interpreter', 'latex');
    zlabel(ax, '$z$', 'Interpreter', 'latex');
    title(ax, 'Body axes and $\omega$ in the lab frame', 'Interpreter', 'latex');

    n = numel(res.t);
    stride = max(1, floor(n / 240));

    e1 = squeeze(res.axesTips(:, :, 1));
    e2 = squeeze(res.axesTips(:, :, 2));
    e3 = squeeze(res.axesTips(:, :, 3));

    wLab = res.wLab;
    wMag = vecnorm(wLab, 2, 2);
    wScale = 0.9 / max(max(wMag), eps);

    h1 = plot3(ax, [0 e1(1,1)], [0 e1(1,2)], [0 e1(1,3)], 'LineWidth', 2.0);
    h2 = plot3(ax, [0 e2(1,1)], [0 e2(1,2)], [0 e2(1,3)], 'LineWidth', 2.0);
    h3 = plot3(ax, [0 e3(1,1)], [0 e3(1,2)], [0 e3(1,3)], 'LineWidth', 2.0);
    hw = quiver3(ax, 0, 0, 0, wScale*wLab(1,1), wScale*wLab(1,2), wScale*wLab(1,3), ...
        0, 'LineWidth', 2.0, 'MaxHeadSize', 0.6);

    trail1 = plot3(ax, nan, nan, nan, ':', 'LineWidth', 1.0);
    trail2 = plot3(ax, nan, nan, nan, ':', 'LineWidth', 1.0);
    trail3 = plot3(ax, nan, nan, nan, ':', 'LineWidth', 1.0);

    videoObj = [];
    if writeVideo
        [folderPath, baseName, ext] = fileparts(videoPath);
        if ~isempty(folderPath) && ~isfolder(folderPath)
            mkdir(folderPath);
        end
        try
            videoObj = VideoWriter(videoPath, 'MPEG-4');
        catch
            if isempty(ext)
                ext = '.avi';
            end
            videoPath = fullfile(folderPath, [baseName '.avi']);
            videoObj = VideoWriter(videoPath, 'Motion JPEG AVI');
        end
        videoObj.FrameRate = 30;
        open(videoObj);
    end

    for k = 1:stride:n
        set(h1, 'XData', [0 e1(k,1)], 'YData', [0 e1(k,2)], 'ZData', [0 e1(k,3)]);
        set(h2, 'XData', [0 e2(k,1)], 'YData', [0 e2(k,2)], 'ZData', [0 e2(k,3)]);
        set(h3, 'XData', [0 e3(k,1)], 'YData', [0 e3(k,2)], 'ZData', [0 e3(k,3)]);
        set(hw, 'UData', wScale*wLab(k,1), 'VData', wScale*wLab(k,2), 'WData', wScale*wLab(k,3));

        set(trail1, 'XData', e1(1:k,1), 'YData', e1(1:k,2), 'ZData', e1(1:k,3));
        set(trail2, 'XData', e2(1:k,1), 'YData', e2(1:k,2), 'ZData', e2(1:k,3));
        set(trail3, 'XData', e3(1:k,1), 'YData', e3(1:k,2), 'ZData', e3(1:k,3));

        drawnow;
        if writeVideo
            frame = getframe(fig);
            writeVideo(videoObj, frame);
        end
    end

    if ~isempty(videoObj)
        close(videoObj);
    end
end
