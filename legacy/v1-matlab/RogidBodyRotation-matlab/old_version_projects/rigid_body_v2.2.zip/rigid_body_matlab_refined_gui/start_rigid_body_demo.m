function start_rigid_body_demo()
%START_RIGID_BODY_DEMO Launch the GUI.
    rigid_body_gui();
end
