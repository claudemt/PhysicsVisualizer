function res = rb_sim_free_exact(p)
%RB_SIM_FREE_EXACT Exact body-frame free rotation away from the separatrix.
%
% If the initial state is numerically too close to the separatrix
% L^2 = 2 E I2, the code switches to a high-accuracy ODE fallback to avoid
% ill-conditioning in the limiting formulas.

    I = p.I(:);
    w0 = p.w0(:);
    if any(diff(I) < 0)
        error('For the exact free-rotation mode, require I1 <= I2 <= I3.');
    end
    if any(I <= 0)
        error('All inertia values must be positive.');
    end

    E = 0.5 * sum(I .* (w0.^2));
    Lb0 = I .* w0;
    L = norm(Lb0);
    L2 = L^2;
    delta = L2 - 2 * E * I(2);
    scale = max([1, abs(L2), abs(2 * E * I(2))]);
    tolSep = 1e-9 * scale;

    t = linspace(0, p.tEnd, p.nSamples).';

    if abs(delta) < tolSep
        res = rb_sim_free_ode_fallback(p);
        res.notes = 'Near-separatrix fallback used for numerical stability.';
        return;
    end

    I1 = I(1); I2 = I(2); I3 = I(3);
    A1 = sqrt(max(0, (2 * E * I3 - L2) / (I1 * (I3 - I1))));
    C1 = sqrt(max(0, (L2 - 2 * E * I1) / (I3 * (I3 - I1))));

    if delta < 0
        % Lecture case 1: L^2 < 2 E I2
        B1 = sqrt(max(0, (L2 - 2 * E * I1) / (I2 * (I2 - I1))));
        m = (I3 - I2) * (L2 - 2 * E * I1) / ((I2 - I1) * (2 * E * I3 - L2));
        a = sqrt((I2 - I1) * (2 * E * I3 - L2) / (I1 * I2 * I3));

        s1 = rb_sign_nonzero(w0(1));
        [K, ~] = ellipke(m);
        f = @(u) local_case1_misfit(u, m, w0, A1, B1, C1, s1);
        u0 = fminbnd(f, 0, 4 * K);
        [sn, cn, dn] = ellipj(a * t + u0, m);

        w1 = s1 * A1 * dn;
        w2 = B1 * sn;
        w3 = C1 * cn;
        branchName = 'case1';
    else
        % Lecture case 2: L^2 > 2 E I2
        B1 = sqrt(max(0, (2 * E * I3 - L2) / (I2 * (I3 - I2))));
        m = (I2 - I1) * (2 * E * I3 - L2) / ((I3 - I2) * (L2 - 2 * E * I1));
        a = sqrt((I3 - I2) * (L2 - 2 * E * I1) / (I1 * I2 * I3));

        s3 = rb_sign_nonzero(w0(3));
        [K, ~] = ellipke(m);
        f = @(u) local_case2_misfit(u, m, w0, A1, B1, C1, s3);
        u0 = fminbnd(f, 0, 4 * K);
        [sn, cn, dn] = ellipj(a * t + u0, m);

        w1 = A1 * cn;
        w2 = B1 * sn;
        w3 = s3 * C1 * dn;
        branchName = 'case2';
    end

    wBody = [w1 w2 w3];
    R0 = rb_initial_free_R(I, w0, p.phi0);
    q = rb_q_from_R(R0);

    qPath = zeros(numel(t), 4);
    qPath(1, :) = q.';
    for k = 1:(numel(t) - 1)
        dt = t(k+1) - t(k);
        wMid = 0.5 * (wBody(k, :) + wBody(k+1, :)).';
        dq = rb_q_from_rotvec(wMid * dt);
        q = rb_qmult(q, dq);
        q = rb_qnormalize(q);
        qPath(k+1, :) = q.';
    end

    n = numel(t);
    R = zeros(3,3,n);
    axesTips = zeros(n, 3, 3);
    wLab = zeros(n, 3);
    LBody = I.' .* wBody;
    LLab = zeros(n, 3);

    for k = 1:n
        Rk = rb_R_from_q(qPath(k, :).');
        R(:,:,k) = Rk;
        axesTips(k,:,1) = Rk(:,1).' / norm(Rk(:,1));
        axesTips(k,:,2) = Rk(:,2).' / norm(Rk(:,2));
        axesTips(k,:,3) = Rk(:,3).' / norm(Rk(:,3));
        wLab(k,:) = (Rk * wBody(k,:).').';
        LLab(k,:) = (Rk * LBody(k,:).').';
    end

    res = struct();
    res.mode = 'free';
    res.branch = branchName;
    res.t = t;
    res.I = I;
    res.wBody = wBody;
    res.wLab = wLab;
    res.LBody = LBody;
    res.LLab = LLab;
    res.R = R;
    res.axesTips = axesTips;
    res.energy = 0.5 * sum(wBody.^2 .* I.', 2);
    res.LNorm = vecnorm(LBody, 2, 2);
    res.parameters = p;
    res.notes = 'Exact body-frame free rotation.';
end

function y = local_case1_misfit(u, m, w0, A1, B1, C1, s1)
    [sn, cn, dn] = ellipj(u, m);
    pred = [s1 * A1 * dn; B1 * sn; C1 * cn];
    y = sum((pred - w0(:)).^2);
end

function y = local_case2_misfit(u, m, w0, A1, B1, C1, s3)
    [sn, cn, dn] = ellipj(u, m);
    pred = [A1 * cn; B1 * sn; s3 * C1 * dn];
    y = sum((pred - w0(:)).^2);
end
