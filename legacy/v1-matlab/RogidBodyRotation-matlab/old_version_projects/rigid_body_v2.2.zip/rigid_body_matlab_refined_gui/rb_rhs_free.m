function dydt = rb_rhs_free(~, y, I)
%RB_RHS_FREE Quaternion-based torque-free rigid-body equations.
    w = y(1:3);
    q = rb_qnormalize(y(4:7));
    Iw = I .* w;
    wdot = -cross(w, Iw) ./ I;
    qdot = 0.5 * rb_qmult(q, [0; w]);
    dydt = [wdot; qdot];
end
