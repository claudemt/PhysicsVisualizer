function s = rb_parse_scalar(txt, nameText)
%RB_PARSE_SCALAR Parse a scalar from text.
    v = rb_parse_numeric_vector(txt, 1, nameText);
    s = v(1);
end
