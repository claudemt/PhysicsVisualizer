function R = rb_R_from_q(q)
%RB_R_FROM_Q Convert quaternion to body-to-lab rotation matrix.
    q = rb_qnormalize(q);
    e1 = rb_qrot(q, [1;0;0]);
    e2 = rb_qrot(q, [0;1;0]);
    e3 = rb_qrot(q, [0;0;1]);
    R = [e1 e2 e3];
end
