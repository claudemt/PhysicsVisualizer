function q = rb_qnormalize(q)
%RB_QNORMALIZE Normalize a quaternion.
    q = q(:);
    nq = norm(q);
    if nq < eps
        q = [1;0;0;0];
    else
        q = q / nq;
    end
end
