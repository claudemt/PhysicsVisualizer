# Change Log

## This revision

### Scope reduced
- Removed all extra modes.
- Kept only:
  - free rotation
  - fixed point in gravity

### Output reduced and fixed
- Kept exactly **7 figures + 1 animation**
- Added export folder generation with timestamp
- Added `parameters.txt`

### GUI resize behavior changed
- Rebuilt around `uifigure`
- Rebuilt around `uigridlayout`
- Added `SizeChangedFcn`
- Disabled `AutoResizeChildren`

### Tip normalization fixed
- Body-axis tips in the lab frame are explicitly normalized before plotting and animation export.

### Plot text simplified
- Removed fragile bold-math strings
- Replaced them with safer LaTeX labels such as `$\omega_x$`, `$\omega_1$`, and `$\hat e_1$`

### Animation simplified
- Removed the lab-frame `L` arrow from the animation
- Kept body axes and `omega` only

### Lab-frame omega display changed
- Fig. 1 now shows only `omega_x` and `omega_y`
- `omega_z` is omitted there in the free-rotation convention because it is constant
