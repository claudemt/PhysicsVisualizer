function vLab = rb_qrot(q, vBody)
%RB_QROT Rotate a 3-vector from body to lab frame using quaternion q.
    q = rb_qnormalize(q);
    p = [0; vBody(:)];
    qc = [q(1); -q(2:4)];
    tmp = rb_qmult(q, rb_qmult(p, qc));
    vLab = tmp(2:4);
end
