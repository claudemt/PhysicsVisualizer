function outDir = rb_export_outputs(res, inputData, rootFolder)
%RB_EXPORT_OUTPUTS Export 7 PNG files, 1 animation video, and 1 parameters TXT.

    if nargin < 3 || isempty(rootFolder)
        rootFolder = fullfile(fileparts(mfilename('fullpath')), 'rigid_body_gui_output');
    end
    if ~isfolder(rootFolder)
        mkdir(rootFolder);
    end

    stamp = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
    outDir = fullfile(rootFolder, stamp);
    mkdir(outDir);

    fig = figure('Visible', 'on', 'Color', 'w', 'Position', [100 80 980 760]);
    ax = axes('Parent', fig);

    for k = 1:7
        clf(fig);
        ax = axes('Parent', fig);
        rb_style_axes(ax);
        rb_render_single_plot(ax, res, k);
        exportgraphics(ax, fullfile(outDir, sprintf('figure_%02d.png', k)), 'Resolution', 180);
    end

    rb_play_animation(fig, res, true, fullfile(outDir, 'animation.mp4'));
    rb_write_parameters(fullfile(outDir, 'parameters.txt'), res, inputData);

    close(fig);
end
