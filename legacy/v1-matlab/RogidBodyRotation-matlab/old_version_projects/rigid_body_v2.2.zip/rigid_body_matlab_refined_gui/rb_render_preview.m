function rb_render_preview(ax, res)
%RB_RENDER_PREVIEW Fill the seven figure tabs plus animation preview.

    t = res.t(:);
    wLab = res.wLab;
    wBody = res.wBody;
    LBody = res.LBody;
    axesTips = res.axesTips;

    for k = 1:numel(ax)
        cla(ax{k});
        rb_style_axes(ax{k});
    end

    % Fig 1: lab-frame x,y only
    plot(ax{1}, t, wLab(:,1), 'LineWidth', 1.5, 'DisplayName', '$\omega_x$');
    plot(ax{1}, t, wLab(:,2), 'LineWidth', 1.5, 'DisplayName', '$\omega_y$');
    xlabel(ax{1}, '$t$', 'Interpreter', 'latex');
    ylabel(ax{1}, '$\omega$', 'Interpreter', 'latex');
    title(ax{1}, 'Lab $\omega_x,\omega_y$ vs $t$', 'Interpreter', 'latex');
    legend(ax{1}, 'Interpreter', 'latex', 'Location', 'best');

    % Fig 2: lab-frame trajectory
    plot3(ax{2}, wLab(:,1), wLab(:,2), wLab(:,3), 'LineWidth', 1.6);
    xlabel(ax{2}, '$\omega_x$', 'Interpreter', 'latex');
    ylabel(ax{2}, '$\omega_y$', 'Interpreter', 'latex');
    zlabel(ax{2}, '$\omega_z$', 'Interpreter', 'latex');
    title(ax{2}, 'Lab-frame trajectory of $\omega$', 'Interpreter', 'latex');
    axis(ax{2}, 'equal');
    view(ax{2}, 3);

    % Fig 3: body components
    plot(ax{3}, t, wBody(:,1), 'LineWidth', 1.5, 'DisplayName', '$\omega_1$');
    plot(ax{3}, t, wBody(:,2), 'LineWidth', 1.5, 'DisplayName', '$\omega_2$');
    plot(ax{3}, t, wBody(:,3), 'LineWidth', 1.5, 'DisplayName', '$\omega_3$');
    xlabel(ax{3}, '$t$', 'Interpreter', 'latex');
    ylabel(ax{3}, '$\omega$', 'Interpreter', 'latex');
    title(ax{3}, 'Body $\omega_1,\omega_2,\omega_3$ vs $t$', 'Interpreter', 'latex');
    legend(ax{3}, 'Interpreter', 'latex', 'Location', 'best');

    % Fig 4: body omega trajectory
    plot3(ax{4}, wBody(:,1), wBody(:,2), wBody(:,3), 'LineWidth', 1.6);
    xlabel(ax{4}, '$\omega_1$', 'Interpreter', 'latex');
    ylabel(ax{4}, '$\omega_2$', 'Interpreter', 'latex');
    zlabel(ax{4}, '$\omega_3$', 'Interpreter', 'latex');
    title(ax{4}, 'Body-frame trajectory of $\omega$', 'Interpreter', 'latex');
    axis(ax{4}, 'equal');
    view(ax{4}, 3);

    % Fig 5: body L trajectory
    plot3(ax{5}, LBody(:,1), LBody(:,2), LBody(:,3), 'LineWidth', 1.6);
    xlabel(ax{5}, '$L_1$', 'Interpreter', 'latex');
    ylabel(ax{5}, '$L_2$', 'Interpreter', 'latex');
    zlabel(ax{5}, '$L_3$', 'Interpreter', 'latex');
    title(ax{5}, 'Body-frame trajectory of $L$', 'Interpreter', 'latex');
    axis(ax{5}, 'equal');
    view(ax{5}, 3);

    % Fig 6: normalized omega/L overlay
    wn = wBody ./ max(vecnorm(wBody, 2, 2), eps);
    Ln = LBody ./ max(vecnorm(LBody, 2, 2), eps);
    plot3(ax{6}, wn(:,1), wn(:,2), wn(:,3), 'LineWidth', 1.6, 'DisplayName', '$\omega/\|\omega\|$');
    plot3(ax{6}, Ln(:,1), Ln(:,2), Ln(:,3), '--', 'LineWidth', 1.3, 'DisplayName', '$L/\|L\|$');
    xlabel(ax{6}, '$x$', 'Interpreter', 'latex');
    ylabel(ax{6}, '$y$', 'Interpreter', 'latex');
    zlabel(ax{6}, '$z$', 'Interpreter', 'latex');
    title(ax{6}, 'Body-frame normalized $\omega$ and $L$', 'Interpreter', 'latex');
    axis(ax{6}, 'equal');
    view(ax{6}, 3);
    legend(ax{6}, 'Interpreter', 'latex', 'Location', 'best');

    % Fig 7: normalized body-axis tips in the lab frame
    [xs, ys, zs] = sphere(36);
    surf(ax{7}, xs, ys, zs, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.15, 'HandleVisibility', 'off');
    plot3(ax{7}, axesTips(:,1,1), axesTips(:,2,1), axesTips(:,3,1), 'LineWidth', 1.5, 'DisplayName', '$\hat e_1$');
    plot3(ax{7}, axesTips(:,1,2), axesTips(:,2,2), axesTips(:,3,2), 'LineWidth', 1.5, 'DisplayName', '$\hat e_2$');
    plot3(ax{7}, axesTips(:,1,3), axesTips(:,2,3), axesTips(:,3,3), 'LineWidth', 1.5, 'DisplayName', '$\hat e_3$');
    xlabel(ax{7}, '$x$', 'Interpreter', 'latex');
    ylabel(ax{7}, '$y$', 'Interpreter', 'latex');
    zlabel(ax{7}, '$z$', 'Interpreter', 'latex');
    title(ax{7}, 'Normalized body-axis tips in the lab frame', 'Interpreter', 'latex');
    axis(ax{7}, 'equal');
    view(ax{7}, 3);
    legend(ax{7}, 'Interpreter', 'latex', 'Location', 'best');

    % Fig 8: animation preview
    rb_play_animation(ax{8}, res, false, '');
end
