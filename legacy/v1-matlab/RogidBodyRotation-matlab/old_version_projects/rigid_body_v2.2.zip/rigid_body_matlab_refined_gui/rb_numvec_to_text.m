function txt = rb_numvec_to_text(v)
%RB_NUMVEC_TO_TEXT Convert a numeric vector to a compact string.
    v = v(:).';
    parts = arrayfun(@(x) sprintf('%.12g', x), v, 'UniformOutput', false);
    txt = ['[' strjoin(parts, ' ') ']'];
end
