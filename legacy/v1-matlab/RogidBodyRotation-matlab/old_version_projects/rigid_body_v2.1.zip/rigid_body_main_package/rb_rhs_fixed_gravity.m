function dx = rb_rhs_fixed_gravity(~, x, p)
%RB_RHS_FIXED_GRAVITY ODE right-hand side for a rigid body about a fixed point in gravity.
%
% State
%   x = [w1; w2; w3; R(:)]
% where R maps inertial vector components to body vector components.

w = x(1:3);
R = reshape(x(4:end), 3, 3);

Ivec = p.I(:);
Lbody = Ivec .* w;
FgBody = R * [0; 0; -p.M * p.g];
tau = cross(p.aBody(:), FgBody);

wdot = (tau - cross(w, Lbody)) ./ Ivec;
Rdot = -rb_skew(w) * R;

dx = [wdot; Rdot(:)];
end
