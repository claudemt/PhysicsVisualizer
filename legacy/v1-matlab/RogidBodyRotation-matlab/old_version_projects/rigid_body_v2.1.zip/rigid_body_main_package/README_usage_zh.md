# 刚体转动 GUI（精简版）

主函数：

```matlab
rigid_body_main
```

## 这版只保留两个核心模式

1. **Free rotation**
   - 使用你讲义中的自由转动解析分支：
     - \(L^2 < 2EI_2\)
     - \(L^2 > 2EI_2\)
     - \(L^2 = 2EI_2\)
   - 体坐标下的 \(\omega_1,\omega_2,\omega_3\) 按椭圆函数/双曲函数严格生成
   - 地面系量由欧拉角和旋转矩阵恢复

2. **Fixed point in gravity**
   - 不再要求旋转对称
   - 在刚体固定点的主轴系中数值积分
   - 运动方程：
     \[
     I\dot{\omega} + \omega \times (I\omega) = \tau_g
     \]
   - 其中
     \[
     \tau_g = r_C \times R(0,0,-Mg)^T
     \]

## GUI 特点

- 所有界面为英文
- 右侧仅保留 7 个预览标签页
- 采用可缩放布局：
  - 宽窗口：左侧控制，右侧预览
  - 窄窗口：上方控制，下方预览
- 所有图标题、坐标轴、图例使用 LaTeX

## 每次运行自动导出

默认输出根目录：

```text
<主函数所在文件夹>/rigid_body_main_output/
```

每次点击 **Run and export** 都会自动创建一个时间戳子目录，例如：

```text
rigid_body_main_output/20260309_153045/
```

其中包含：

- `01_omega_xyz_vs_t.png`
- `02_omega_xyz_phase.png`
- `03_omega_123_vs_t.png`
- `04_omega_123_phase.png`
- `05_body_omega_tip.png`
- `06_body_L_tip.png`
- `07_inertial_omega_tip.png`
- `08_animation.mp4` 或 `08_animation.avi`
- `parameters.txt`

## 七张图的含义

1. 地面系分量 \(\omega_x,\omega_y,\omega_z\) 关于 \(t\) 的曲线  
2. 地面系分量空间中的轨迹 \((\omega_x,\omega_y,\omega_z)\)  
3. 刚体系分量 \(\omega_1,\omega_2,\omega_3\) 关于 \(t\) 的曲线  
4. 刚体系分量空间中的轨迹 \((\omega_1,\omega_2,\omega_3)\)  
5. 刚体系下角速度矢量尖端轨迹  
6. 刚体系下角动量矢量尖端轨迹  
7. 地面系下角速度矢量尖端轨迹  

动画保持为你指定的形式：**刚体三个轴、角速度、角动量在地面系下的演化**。

## 输入说明

### Free rotation

- `Inertia [I1 I2 I3]`
- `Initial body omega [w1 w2 w3]`
- `Initial phi0`
- `Final time`
- `Samples`

注意：该模式要求输入满足 `I1 <= I2 <= I3`。

### Fixed point in gravity

- `Inertia about fixed point [I1 I2 I3]`
- `Mass M`
- `Gravity g`
- `Body vector r_C = [a1 a2 a3]`
- `Initial Euler [phi theta psi]`
- `Initial body omega [w1 w2 w3]`
- `Final time, samples`

## 建议先测试的预设

- `Intermediate-axis theorem`
- `Stable near-axis-3 spin`
- `General asymmetric top`
- `Near-steady precession`

## 说明

我这里无法直接启动 MATLAB 做最终 GUI 点击测试，所以这版是按标准 MATLAB 语法与函数组织重写的。  
如果你需要下一轮，我建议专门再做两件事：

- 按你的课堂审美继续压缩图形风格
- 再把固定点重力页增加成“向量法讲解模式”
