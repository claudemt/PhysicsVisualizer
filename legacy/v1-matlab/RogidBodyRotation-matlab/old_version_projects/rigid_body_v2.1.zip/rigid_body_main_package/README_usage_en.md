# Rigid Body Motion Explorer

Main entry point:

```matlab
rigid_body_main
```

## Retained modes

- **Free rotation**
  - exact elliptic-function branches from the lecture
- **Fixed point in gravity**
  - general rigid body, no symmetry requirement

## Exported content per run

A timestamped folder is created under

```text
<package folder>/rigid_body_main_output/
```

Each run exports:

- 7 PNG figures
- 1 animation video
- 1 parameter text file

## The seven figures

1. `\omega_x,\omega_y,\omega_z` versus time
2. phase curve in `(\omega_x,\omega_y,\omega_z)`
3. `\omega_1,\omega_2,\omega_3` versus time
4. phase curve in `(\omega_1,\omega_2,\omega_3)`
5. body-frame tip trajectory of `\omega`
6. body-frame tip trajectory of `L`
7. inertial-frame tip trajectory of `\omega`

## Animation

The animation shows:

- the three body axes
- the angular velocity vector
- the angular momentum vector

all in the inertial frame.
