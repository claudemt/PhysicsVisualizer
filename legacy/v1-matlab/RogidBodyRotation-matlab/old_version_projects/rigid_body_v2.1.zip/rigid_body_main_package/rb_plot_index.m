function info = rb_plot_index(ax, res, idx)
%RB_PLOT_INDEX Draw one of the seven requested plots on a given axes handle.
t = res.t(:);
wI = res.omegaInertial;
wB = res.omegaBody;
LB = res.LBody;

cla(ax);
hold(ax, 'on');
grid(ax, 'on');
box(ax, 'on');

switch idx
    case 1
        plot(ax, t, wI(:,1), 'LineWidth', 1.8, 'DisplayName', '$\omega_x$');
        plot(ax, t, wI(:,2), 'LineWidth', 1.8, 'DisplayName', '$\omega_y$');
        plot(ax, t, wI(:,3), 'LineWidth', 1.8, 'DisplayName', '$\omega_z$');
        xlabel(ax, '$t$', 'Interpreter', 'latex');
        ylabel(ax, '$\omega_i$', 'Interpreter', 'latex');
        title(ax, '$\omega_x(t),\ \omega_y(t),\ \omega_z(t)$', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        info.filename = '01_omega_xyz_vs_t.png';

    case 2
        plot3(ax, wI(:,1), wI(:,2), wI(:,3), 'LineWidth', 1.8);
        plot3(ax, wI(1,1), wI(1,2), wI(1,3), 'o', 'MarkerSize', 7, 'LineWidth', 1.3, 'DisplayName', '$t_0$');
        plot3(ax, wI(end,1), wI(end,2), wI(end,3), 's', 'MarkerSize', 7, 'LineWidth', 1.3, 'DisplayName', '$t_f$');
        xlabel(ax, '$\omega_x$', 'Interpreter', 'latex');
        ylabel(ax, '$\omega_y$', 'Interpreter', 'latex');
        zlabel(ax, '$\omega_z$', 'Interpreter', 'latex');
        title(ax, '$(\omega_x,\omega_y,\omega_z)$ component-space trajectory', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        axis(ax, 'equal'); view(ax, 3);
        info.filename = '02_omega_xyz_phase.png';

    case 3
        plot(ax, t, wB(:,1), 'LineWidth', 1.8, 'DisplayName', '$\omega_1$');
        plot(ax, t, wB(:,2), 'LineWidth', 1.8, 'DisplayName', '$\omega_2$');
        plot(ax, t, wB(:,3), 'LineWidth', 1.8, 'DisplayName', '$\omega_3$');
        xlabel(ax, '$t$', 'Interpreter', 'latex');
        ylabel(ax, '$\omega_i$', 'Interpreter', 'latex');
        title(ax, '$\omega_1(t),\ \omega_2(t),\ \omega_3(t)$', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        info.filename = '03_omega_123_vs_t.png';

    case 4
        plot3(ax, wB(:,1), wB(:,2), wB(:,3), 'LineWidth', 1.8);
        plot3(ax, wB(1,1), wB(1,2), wB(1,3), 'o', 'MarkerSize', 7, 'LineWidth', 1.3, 'DisplayName', '$t_0$');
        plot3(ax, wB(end,1), wB(end,2), wB(end,3), 's', 'MarkerSize', 7, 'LineWidth', 1.3, 'DisplayName', '$t_f$');
        xlabel(ax, '$\omega_1$', 'Interpreter', 'latex');
        ylabel(ax, '$\omega_2$', 'Interpreter', 'latex');
        zlabel(ax, '$\omega_3$', 'Interpreter', 'latex');
        title(ax, '$(\omega_1,\omega_2,\omega_3)$ component-space trajectory', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        axis(ax, 'equal'); view(ax, 3);
        info.filename = '04_omega_123_phase.png';

    case 5
        plot3(ax, wB(:,1), wB(:,2), wB(:,3), 'LineWidth', 2.0, 'DisplayName', '$\boldsymbol{\omega}$ tip');
        quiver3(ax, 0,0,0, wB(1,1),wB(1,2),wB(1,3), 0, 'LineWidth', 1.4, 'MaxHeadSize', 0.35, 'DisplayName', '$\boldsymbol{\omega}(t_0)$');
        xlabel(ax, '$\hat{\mathbf e}_1$', 'Interpreter', 'latex');
        ylabel(ax, '$\hat{\mathbf e}_2$', 'Interpreter', 'latex');
        zlabel(ax, '$\hat{\mathbf e}_3$', 'Interpreter', 'latex');
        title(ax, 'Body-frame tip trajectory of $\boldsymbol{\omega}$', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        axis(ax, 'equal'); view(ax, 3);
        info.filename = '05_body_omega_tip.png';

    case 6
        plot3(ax, LB(:,1), LB(:,2), LB(:,3), 'LineWidth', 2.0, 'DisplayName', '$\mathbf L$ tip');
        quiver3(ax, 0,0,0, LB(1,1),LB(1,2),LB(1,3), 0, 'LineWidth', 1.4, 'MaxHeadSize', 0.35, 'DisplayName', '$\mathbf L(t_0)$');
        xlabel(ax, '$\hat{\mathbf e}_1$', 'Interpreter', 'latex');
        ylabel(ax, '$\hat{\mathbf e}_2$', 'Interpreter', 'latex');
        zlabel(ax, '$\hat{\mathbf e}_3$', 'Interpreter', 'latex');
        title(ax, 'Body-frame tip trajectory of $\mathbf L$', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        axis(ax, 'equal'); view(ax, 3);
        info.filename = '06_body_L_tip.png';

    case 7
        plot3(ax, wI(:,1), wI(:,2), wI(:,3), 'LineWidth', 2.0, 'DisplayName', '$\boldsymbol{\omega}$ tip');
        quiver3(ax, 0,0,0, wI(1,1),wI(1,2),wI(1,3), 0, 'LineWidth', 1.4, 'MaxHeadSize', 0.35, 'DisplayName', '$\boldsymbol{\omega}(t_0)$');
        xlabel(ax, '$\hat{\mathbf x}$', 'Interpreter', 'latex');
        ylabel(ax, '$\hat{\mathbf y}$', 'Interpreter', 'latex');
        zlabel(ax, '$\hat{\mathbf z}$', 'Interpreter', 'latex');
        title(ax, 'Inertial-frame tip trajectory of $\boldsymbol{\omega}$', 'Interpreter', 'latex');
        legend(ax, 'Interpreter', 'latex', 'Location', 'best');
        axis(ax, 'equal'); view(ax, 3);
        info.filename = '07_inertial_omega_tip.png';

    otherwise
        error('Plot index must be 1..7.');
end

ax.FontSize = 13;
ax.LineWidth = 1.0;
end
