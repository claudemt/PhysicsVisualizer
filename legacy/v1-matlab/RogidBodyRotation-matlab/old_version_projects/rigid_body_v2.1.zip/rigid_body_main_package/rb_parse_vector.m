function v = rb_parse_vector(txt, nExpected, labelText)
%RB_PARSE_VECTOR Parse a numeric row vector from a text field.
if isstring(txt) || ischar(txt)
    raw = sscanf(char(txt), '%f');
else
    error('%s must be entered as text.', labelText);
end
if numel(raw) ~= nExpected
    error('%s must contain exactly %d numeric entries.', labelText, nExpected);
end
v = raw(:).';
end
