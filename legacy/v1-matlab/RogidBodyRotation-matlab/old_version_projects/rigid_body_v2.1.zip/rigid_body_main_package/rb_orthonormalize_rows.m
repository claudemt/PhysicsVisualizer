function R = rb_orthonormalize_rows(Rin)
%RB_ORTHONORMALIZE_ROWS Project a 3x3 matrix to the nearest proper rotation matrix.
[U, ~, V] = svd(Rin);
R = U * V';
if det(R) < 0
    U(:,3) = -U(:,3);
    R = U * V';
end
end
