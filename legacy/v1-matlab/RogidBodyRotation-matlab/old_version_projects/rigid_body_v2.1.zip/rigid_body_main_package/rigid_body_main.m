function rigid_body_main()
%RIGID_BODY_MAIN Responsive GUI for rigid-body free rotation and fixed-point motion in gravity.
%
% Features
%   1) Free rotation using the exact elliptic-function branches from the lecture notes
%   2) Fixed-point motion in gravity for a general rigid body using Euler equations about the fixed point
%   3) Seven exported figures + one animation + one parameter text file per run
%
% Output folder
%   <this_folder>/rigid_body_main_output/YYYYMMDD_HHMMSS/
%
% The GUI uses uifigure + uigridlayout and adjusts its layout in SizeChangedFcn.

app = struct();
app.result = [];
app.currentOutputFolder = "";

presets = rb_defaults();

build_ui();
apply_preset("Free rotation", presets.free(1).name);
apply_preset("Fixed point in gravity", presets.fixed(1).name);
refresh_layout();

    function build_ui()
        here = fileparts(mfilename('fullpath'));
        app.defaultOutputRoot = fullfile(here, [mfilename '_output']);

        app.fig = uifigure( ...
            'Name', 'Rigid Body Motion Explorer', ...
            'Position', [60 60 1500 900], ...
            'Color', [0.98 0.98 0.98], ...
            'SizeChangedFcn', @(~,~) refresh_layout());

        app.main = uigridlayout(app.fig, [1 2]);
        app.main.RowHeight = {'1x'};
        app.main.ColumnWidth = {360, '1x'};
        app.main.Padding = [10 10 10 10];
        app.main.RowSpacing = 8;
        app.main.ColumnSpacing = 8;

        app.leftPanel = uipanel(app.main, 'Title', 'Controls');
        app.leftPanel.Layout.Row = 1;
        app.leftPanel.Layout.Column = 1;

        app.rightPanel = uipanel(app.main, 'Title', 'Preview');
        app.rightPanel.Layout.Row = 1;
        app.rightPanel.Layout.Column = 2;

        left = uigridlayout(app.leftPanel, [7 1]);
        left.RowHeight = {'fit', 'fit', '1x', 'fit', 'fit', 'fit', 170};
        left.ColumnWidth = {'1x'};
        left.Padding = [8 8 8 8];
        left.RowSpacing = 8;

        header = uigridlayout(left, [2 2]);
        header.RowHeight = {'fit', 'fit'};
        header.ColumnWidth = {90, '1x'};
        header.Layout.Row = 1;
        header.Layout.Column = 1;

        lbl = uilabel(header, 'Text', 'Mode', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
        lbl.Layout.Row = 1; lbl.Layout.Column = 1;
        app.modeDropdown = uidropdown(header, ...
            'Items', {'Free rotation', 'Fixed point in gravity'}, ...
            'Value', 'Free rotation', ...
            'ValueChangedFcn', @(~,~) on_mode_changed());
        app.modeDropdown.Layout.Row = 1;
        app.modeDropdown.Layout.Column = 2;

        lbl = uilabel(header, 'Text', 'Preset', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
        lbl.Layout.Row = 2; lbl.Layout.Column = 1;
        app.presetDropdown = uidropdown(header, ...
            'Items', {presets.free.name}, ...
            'Value', presets.free(1).name, ...
            'ValueChangedFcn', @(~,~) on_preset_changed());
        app.presetDropdown.Layout.Row = 2;
        app.presetDropdown.Layout.Column = 2;

        app.modeNote = uitextarea(left, 'Editable', 'off');
        app.modeNote.Layout.Row = 2;
        app.modeNote.Layout.Column = 1;

        app.inputTabs = uitabgroup(left);
        app.inputTabs.Layout.Row = 3;
        app.inputTabs.Layout.Column = 1;

        app.freeTab = uitab(app.inputTabs, 'Title', 'Free');
        app.fixedTab = uitab(app.inputTabs, 'Title', 'Fixed');

        build_free_controls();
        build_fixed_controls();

        outGrid = uigridlayout(left, [2 3]);
        outGrid.RowHeight = {'fit', 'fit'};
        outGrid.ColumnWidth = {85, '1x', 70};
        outGrid.Layout.Row = 4;
        outGrid.Layout.Column = 1;

        uilabel(outGrid, 'Text', 'Output root', 'FontWeight', 'bold');
        app.outputRootField = uieditfield(outGrid, 'text', 'Value', app.defaultOutputRoot);
        app.outputRootField.Layout.Row = 1;
        app.outputRootField.Layout.Column = 2;
        app.browseButton = uibutton(outGrid, 'Text', 'Browse', ...
            'ButtonPushedFcn', @(~,~) on_browse_output());
        app.browseButton.Layout.Row = 1;
        app.browseButton.Layout.Column = 3;

        app.outputHint = uilabel(outGrid, ...
            'Text', 'Each run creates a timestamped subfolder with 7 PNG files, 1 video, and 1 parameter text file.', ...
            'WordWrap', 'on');
        app.outputHint.Layout.Row = 2;
        app.outputHint.Layout.Column = [1 3];

        btnGrid = uigridlayout(left, [1 4]);
        btnGrid.ColumnWidth = {'1x','1x','1x','1x'};
        btnGrid.RowHeight = {'fit'};
        btnGrid.Layout.Row = 5;
        btnGrid.Layout.Column = 1;

        app.runButton = uibutton(btnGrid, 'Text', 'Run and export', ...
            'ButtonPushedFcn', @(~,~) on_run());
        app.playButton = uibutton(btnGrid, 'Text', 'Play animation', ...
            'ButtonPushedFcn', @(~,~) on_play());
        app.openButton = uibutton(btnGrid, 'Text', 'Open folder', ...
            'ButtonPushedFcn', @(~,~) on_open_folder());
        app.clearButton = uibutton(btnGrid, 'Text', 'Clear preview', ...
            'ButtonPushedFcn', @(~,~) on_clear());

        app.statusLabel = uilabel(left, 'Text', 'Status: idle', 'FontWeight', 'bold');
        app.statusLabel.Layout.Row = 6;
        app.statusLabel.Layout.Column = 1;

        app.logBox = uitextarea(left, 'Editable', 'off');
        app.logBox.Layout.Row = 7;
        app.logBox.Layout.Column = 1;
        app.logBox.Value = {'Ready.'};

        preview = uigridlayout(app.rightPanel, [1 1]);
        preview.RowHeight = {'1x'};
        preview.ColumnWidth = {'1x'};
        preview.Padding = [6 6 6 6];

        app.plotTabs = uitabgroup(preview);
        app.plotTabs.Layout.Row = 1;
        app.plotTabs.Layout.Column = 1;

        tabNames = { ...
            '1  omega xyz vs t', ...
            '2  omega xyz phase', ...
            '3  omega 123 vs t', ...
            '4  omega 123 phase', ...
            '5  body omega tip', ...
            '6  body L tip', ...
            '7  inertial omega tip'};
        app.axes = gobjects(7,1);
        for k = 1:7
            tab = uitab(app.plotTabs, 'Title', tabNames{k});
            gridBox = uigridlayout(tab, [1 1]);
            gridBox.RowHeight = {'1x'};
            gridBox.ColumnWidth = {'1x'};
            gridBox.Padding = [6 6 6 6];
            app.axes(k) = uiaxes(gridBox);
            app.axes(k).Layout.Row = 1;
            app.axes(k).Layout.Column = 1;
            grid(app.axes(k), 'on');
            hold(app.axes(k), 'on');
            app.axes(k).FontSize = 13;
            app.axes(k).LineWidth = 1.0;
            app.axes(k).Box = 'on';
        end

        on_mode_changed();
    end

    function build_free_controls()
        g = uigridlayout(app.freeTab, [6 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {145, '1x'};
        g.Padding = [8 8 8 8];
        g.RowSpacing = 8;

        make_label(g, 1, 'Inertia [I1 I2 I3]');
        app.freeI = uieditfield(g, 'text', 'Value', '');
        app.freeI.Layout.Row = 1; app.freeI.Layout.Column = 2;

        make_label(g, 2, 'Initial body omega [w1 w2 w3]');
        app.freeW0 = uieditfield(g, 'text', 'Value', '');
        app.freeW0.Layout.Row = 2; app.freeW0.Layout.Column = 2;

        make_label(g, 3, 'Initial phi0');
        app.freePhi0 = uieditfield(g, 'numeric', 'Value', 0.0);
        app.freePhi0.Layout.Row = 3; app.freePhi0.Layout.Column = 2;

        make_label(g, 4, 'Final time');
        app.freeTEnd = uieditfield(g, 'numeric', 'Value', 30.0);
        app.freeTEnd.Layout.Row = 4; app.freeTEnd.Layout.Column = 2;

        make_label(g, 5, 'Samples');
        app.freeNSamples = uieditfield(g, 'numeric', 'Value', 1600, 'RoundFractionalValues','on');
        app.freeNSamples.Layout.Row = 5; app.freeNSamples.Layout.Column = 2;

        help = uilabel(g, ...
            'Text', ['Assume I1 <= I2 <= I3. The inertial z axis is chosen along the constant angular momentum vector.' newline ...
                     'Free rotation uses the exact elliptic-function branches from the lecture.'], ...
            'WordWrap', 'on');
        help.Layout.Row = 6; help.Layout.Column = [1 2];
    end

    function build_fixed_controls()
        g = uigridlayout(app.fixedTab, [8 2]);
        g.RowHeight = {'fit','fit','fit','fit','fit','fit','fit','1x'};
        g.ColumnWidth = {145, '1x'};
        g.Padding = [8 8 8 8];
        g.RowSpacing = 8;

        make_label(g, 1, 'Inertia about fixed point [I1 I2 I3]');
        app.fixedI = uieditfield(g, 'text', 'Value', '');
        app.fixedI.Layout.Row = 1; app.fixedI.Layout.Column = 2;

        make_label(g, 2, 'Mass M');
        app.fixedM = uieditfield(g, 'numeric', 'Value', 1.0);
        app.fixedM.Layout.Row = 2; app.fixedM.Layout.Column = 2;

        make_label(g, 3, 'Gravity g');
        app.fixedG = uieditfield(g, 'numeric', 'Value', 9.81);
        app.fixedG.Layout.Row = 3; app.fixedG.Layout.Column = 2;

        make_label(g, 4, 'Body vector r_C = [a1 a2 a3]');
        app.fixedA = uieditfield(g, 'text', 'Value', '');
        app.fixedA.Layout.Row = 4; app.fixedA.Layout.Column = 2;

        make_label(g, 5, 'Initial Euler [phi theta psi]');
        app.fixedEuler0 = uieditfield(g, 'text', 'Value', '');
        app.fixedEuler0.Layout.Row = 5; app.fixedEuler0.Layout.Column = 2;

        make_label(g, 6, 'Initial body omega [w1 w2 w3]');
        app.fixedW0 = uieditfield(g, 'text', 'Value', '');
        app.fixedW0.Layout.Row = 6; app.fixedW0.Layout.Column = 2;

        make_label(g, 7, 'Final time, samples');
        line = uigridlayout(g, [1 2]);
        line.RowHeight = {'fit'}; line.ColumnWidth = {'1x','1x'};
        line.Layout.Row = 7; line.Layout.Column = 2;
        app.fixedTEnd = uieditfield(line, 'numeric', 'Value', 12.0);
        app.fixedNSamples = uieditfield(line, 'numeric', 'Value', 1800, 'RoundFractionalValues','on');

        help = uilabel(g, ...
            'Text', ['General rigid body about a fixed point in gravity:' newline ...
                     'I*omega_dot + omega x (I*omega) = tau_g, with tau_g = r_C x R*[0 0 -Mg]^T.'], ...
            'WordWrap', 'on');
        help.Layout.Row = 8; help.Layout.Column = [1 2];
    end

    function lbl = make_label(parent, row, txt)
        lbl = uilabel(parent, 'Text', txt, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
        lbl.Layout.Row = row;
        lbl.Layout.Column = 1;
    end

    function on_mode_changed()
        mode = app.modeDropdown.Value;
        if strcmp(mode, 'Free rotation')
            app.inputTabs.SelectedTab = app.freeTab;
            app.presetDropdown.Items = {presets.free.name};
            app.presetDropdown.Value = presets.free(1).name;
            app.modeNote.Value = { ...
                'Free rotation mode', ...
                'Exact body angular velocity uses the lecture elliptic-function formulas.', ...
                'The seven plots and the animation are exported automatically after each run.'};
        else
            app.inputTabs.SelectedTab = app.fixedTab;
            app.presetDropdown.Items = {presets.fixed.name};
            app.presetDropdown.Value = presets.fixed(1).name;
            app.modeNote.Value = { ...
                'Fixed point in gravity mode', ...
                'General rigid body, no symmetry requirement.', ...
                'Dynamics are integrated about the fixed point in the body principal frame.'};
        end
        on_preset_changed();
    end

    function on_preset_changed()
        apply_preset(app.modeDropdown.Value, app.presetDropdown.Value);
    end

    function apply_preset(mode, presetName)
        if strcmp(mode, 'Free rotation')
            idx = find(strcmp({presets.free.name}, presetName), 1, 'first');
            if isempty(idx); return; end
            p = presets.free(idx);
            app.freeI.Value = rb_vec_to_str(p.I);
            app.freeW0.Value = rb_vec_to_str(p.w0);
            app.freePhi0.Value = p.phi0;
            app.freeTEnd.Value = p.tEnd;
            app.freeNSamples.Value = p.nSamples;
        else
            idx = find(strcmp({presets.fixed.name}, presetName), 1, 'first');
            if isempty(idx); return; end
            p = presets.fixed(idx);
            app.fixedI.Value = rb_vec_to_str(p.I);
            app.fixedM.Value = p.M;
            app.fixedG.Value = p.g;
            app.fixedA.Value = rb_vec_to_str(p.aBody);
            app.fixedEuler0.Value = rb_vec_to_str(p.euler0);
            app.fixedW0.Value = rb_vec_to_str(p.w0);
            app.fixedTEnd.Value = p.tEnd;
            app.fixedNSamples.Value = p.nSamples;
        end
    end

    function refresh_layout()
        if ~isfield(app, 'fig') || ~isvalid(app.fig) || ~isfield(app, 'leftPanel') || isempty(app.leftPanel)
            return;
        end
        pos = app.fig.Position;
        width = pos(3);
        if width < 1180
            app.main.RowHeight = {360, '1x'};
            app.main.ColumnWidth = {'1x'};
            app.leftPanel.Layout.Row = 1; app.leftPanel.Layout.Column = 1;
            app.rightPanel.Layout.Row = 2; app.rightPanel.Layout.Column = 1;
        else
            app.main.RowHeight = {'1x'};
            app.main.ColumnWidth = {360, '1x'};
            app.leftPanel.Layout.Row = 1; app.leftPanel.Layout.Column = 1;
            app.rightPanel.Layout.Row = 1; app.rightPanel.Layout.Column = 2;
        end
    end

    function on_browse_output()
        target = uigetdir(app.outputRootField.Value, 'Select output root folder');
        if isequal(target,0)
            return;
        end
        app.outputRootField.Value = target;
    end

    function on_run()
        try
            app.statusLabel.Text = 'Status: running...';
            drawnow;

            cfg = collect_inputs();
            if strcmp(cfg.mode, 'free')
                res = rb_simulate_free_exact(cfg);
            else
                res = rb_simulate_fixed_gravity(cfg);
            end

            rb_make_plots(app.axes, res);
            outInfo = rb_export_outputs(res, app.outputRootField.Value);
            app.result = res;
            app.currentOutputFolder = outInfo.outputFolder;

            app.statusLabel.Text = 'Status: completed';
            app.logBox.Value = [ ...
                {['Completed: ' res.summaryLine]}, ...
                {['Output folder: ' outInfo.outputFolder]}, ...
                outInfo.files(:).'];
        catch ME
            app.statusLabel.Text = 'Status: failed';
            app.logBox.Value = {['Error: ' ME.message]};
            uialert(app.fig, ME.message, 'Computation failed');
        end
    end

    function on_play()
        if isempty(app.result)
            uialert(app.fig, 'Please run a case first.', 'No result');
            return;
        end
        try
            rb_make_animation(app.result, "", true);
        catch ME
            app.logBox.Value = {['Animation error: ' ME.message]};
            uialert(app.fig, ME.message, 'Animation failed');
        end
    end

    function on_open_folder()
        folder = app.currentOutputFolder;
        if strlength(folder) == 0 || ~isfolder(folder)
            folder = app.outputRootField.Value;
        end
        if ~isfolder(folder)
            uialert(app.fig, 'The target folder does not exist yet.', 'Folder missing');
            return;
        end
        if ispc
            winopen(folder);
        elseif ismac
            system(sprintf('open "%s" &', folder));
        else
            system(sprintf('xdg-open "%s" >/dev/null 2>&1 &', folder));
        end
    end

    function on_clear()
        for k = 1:numel(app.axes)
            cla(app.axes(k));
            grid(app.axes(k), 'on');
            hold(app.axes(k), 'on');
            app.axes(k).Title.String = '';
        end
        app.result = [];
        app.statusLabel.Text = 'Status: idle';
        app.logBox.Value = {'Preview cleared.'};
    end

    function cfg = collect_inputs()
        modeText = app.modeDropdown.Value;
        if strcmp(modeText, 'Free rotation')
            cfg = struct();
            cfg.mode = 'free';
            cfg.caseName = app.presetDropdown.Value;
            cfg.I = rb_parse_vector(app.freeI.Value, 3, 'Inertia [I1 I2 I3]');
            cfg.w0 = rb_parse_vector(app.freeW0.Value, 3, 'Initial body omega');
            cfg.phi0 = app.freePhi0.Value;
            cfg.tEnd = app.freeTEnd.Value;
            cfg.nSamples = round(app.freeNSamples.Value);
            if any(cfg.I <= 0)
                error('All inertia values must be positive.');
            end
            if ~(cfg.I(1) <= cfg.I(2) && cfg.I(2) <= cfg.I(3))
                error('For the exact free-rotation formulas, enter inertia as I1 <= I2 <= I3.');
            end
            if ~isfinite(cfg.tEnd) || cfg.tEnd <= 0
                error('Final time must be positive.');
            end
            if cfg.nSamples < 100
                error('Samples must be at least 100.');
            end
        else
            cfg = struct();
            cfg.mode = 'fixed';
            cfg.caseName = app.presetDropdown.Value;
            cfg.I = rb_parse_vector(app.fixedI.Value, 3, 'Inertia [I1 I2 I3]');
            cfg.M = app.fixedM.Value;
            cfg.g = app.fixedG.Value;
            cfg.aBody = rb_parse_vector(app.fixedA.Value, 3, 'Body vector r_C');
            cfg.euler0 = rb_parse_vector(app.fixedEuler0.Value, 3, 'Initial Euler [phi theta psi]');
            cfg.w0 = rb_parse_vector(app.fixedW0.Value, 3, 'Initial body omega');
            cfg.tEnd = app.fixedTEnd.Value;
            cfg.nSamples = round(app.fixedNSamples.Value);
            if any(cfg.I <= 0)
                error('All inertia values must be positive.');
            end
            if ~isfinite(cfg.M) || cfg.M <= 0
                error('Mass M must be positive.');
            end
            if ~isfinite(cfg.g) || cfg.g < 0
                error('Gravity g must be nonnegative.');
            end
            if norm(cfg.aBody) <= 0
                error('The body vector r_C cannot be zero for fixed-point gravity motion.');
            end
            if ~isfinite(cfg.tEnd) || cfg.tEnd <= 0
                error('Final time must be positive.');
            end
            if cfg.nSamples < 100
                error('Samples must be at least 100.');
            end
        end
    end
end

function s = rb_vec_to_str(v)
s = strtrim(sprintf('%.12g ', v));
end
