function R = rb_passive_rotm_313x(phi, theta, psi)
%RB_PASSIVE_ROTM_313X Passive 3-1-3 Euler rotation used in the lecture notes.
%
% [e1; e2; e3] = R [ex; ey; ez]
% where ex,ey,ez are inertial basis vectors and e1,e2,e3 are body basis vectors.

cph = cos(phi);  sph = sin(phi);
cth = cos(theta); sth = sin(theta);
cps = cos(psi);  sps = sin(psi);

R = [ ...
    cps*cph - sps*sph*cth,   sph*cps + cth*cph*sps,   sth*sps; ...
   -sps*cph - cps*sph*cth,  -sph*sps + cth*cph*cps,  sth*cps; ...
    sth*sph,                -sth*cph,                cth];
end
