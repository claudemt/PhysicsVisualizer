function out = rb_simulate_fixed_gravity(p)
%RB_SIMULATE_FIXED_GRAVITY Fixed-point motion in gravity for a general rigid body.
%
% Inputs
%   p.I      = inertia about fixed point in body principal frame
%   p.M
%   p.g
%   p.aBody  = vector from fixed point to center of mass in the body frame
%   p.euler0 = [phi0 theta0 psi0]
%   p.w0     = initial angular velocity in body frame
%   p.tEnd
%   p.nSamples

I = p.I(:).';
phi0 = p.euler0(1);
theta0 = p.euler0(2);
psi0 = p.euler0(3);
R0 = rb_passive_rotm_313x(phi0, theta0, psi0);
x0 = [p.w0(:); R0(:)];

tspan = linspace(0, p.tEnd, p.nSamples);
opts = odeset('RelTol', 1e-9, 'AbsTol', 1e-11);
sol = ode113(@(t,x) rb_rhs_fixed_gravity(t, x, p), tspan, x0, opts);

t = sol.x(:);
X = sol.y.';
n = numel(t);

wBody = X(:,1:3);
R = zeros(3,3,n);
omegaXYZ = zeros(n,3);
LBody = zeros(n,3);
Lxyz = zeros(n,3);
rCxyz = zeros(n,3);
E = zeros(n,1);

for k = 1:n
    Rk = reshape(X(k,4:end), 3, 3);
    Rk = rb_orthonormalize_rows(Rk);
    R(:,:,k) = Rk;

    wk = wBody(k,:).';
    Lk = I(:) .* wk;

    omegaXYZ(k,:) = (Rk' * wk).';
    LBody(k,:) = Lk.';
    Lxyz(k,:) = (Rk' * Lk).';
    rCxyz(k,:) = (Rk' * p.aBody(:)).';

    E(k) = 0.5 * sum(wk .* Lk) + p.M * p.g * rCxyz(k,3);
end

% Recover Euler angles from R for logging only
phi = zeros(n,1);
theta = zeros(n,1);
psi = zeros(n,1);
for k = 1:n
    [phi(k), theta(k), psi(k)] = local_inverse_euler_313x(R(:,:,k));
end
phi = unwrap(phi);
psi = unwrap(psi);

out = struct();
out.mode = 'fixed';
out.caseName = p.caseName;
out.t = t;
out.omegaBody = wBody;
out.omegaInertial = omegaXYZ;
out.LBody = LBody;
out.LInertial = Lxyz;
out.R = R;
out.euler = [phi, theta, psi];
out.inertia = I;
out.mass = p.M;
out.rCBody = p.aBody(:).';
out.E = E;
out.Lmag = sqrt(sum(Lxyz.^2,2));
out.caseNameDetail = 'Fixed point in gravity';
out.period = NaN;
out.phase0 = NaN;
out.nu = NaN;
out.m = NaN;
out.summaryLine = sprintf('Fixed point in gravity, E(t0) = %.6g, E(tf) = %.6g', E(1), E(end));
out.parameters = struct( ...
    'mode', 'fixed', ...
    'caseName', p.caseName, ...
    'I', I, ...
    'M', p.M, ...
    'g', p.g, ...
    'aBody', p.aBody(:).', ...
    'euler0', p.euler0(:).', ...
    'w0', p.w0(:).', ...
    'tEnd', p.tEnd, ...
    'nSamples', p.nSamples, ...
    'E0', E(1), ...
    'Ef', E(end));
end

function [phi, theta, psi] = local_inverse_euler_313x(R)
% Solve the lecture convention
% R(3,3) = cos(theta)
theta = acos(max(min(R(3,3), 1), -1));
s = sin(theta);

if abs(s) < 1e-10
    % Degenerate: combine phi and psi
    phi = atan2(R(1,2), R(1,1));
    psi = 0;
else
    phi = atan2(R(3,1), -R(3,2));
    psi = atan2(R(1,3), R(2,3));
end
end
