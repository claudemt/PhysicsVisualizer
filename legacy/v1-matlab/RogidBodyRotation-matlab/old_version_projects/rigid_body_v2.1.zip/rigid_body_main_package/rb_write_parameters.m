function [filename, filepath] = rb_write_parameters(res, outputFolder)
%RB_WRITE_PARAMETERS Write a human-readable parameter text file.

filename = 'parameters.txt';
filepath = fullfile(outputFolder, filename);

fid = fopen(filepath, 'w');
if fid < 0
    error('Could not create parameter text file.');
end
cleanup = onCleanup(@() fclose(fid));

fprintf(fid, 'Rigid Body Motion Explorer\n');
fprintf(fid, 'Generated at: %s\n\n', datestr(now, 31));
fprintf(fid, 'Mode: %s\n', res.mode);
fprintf(fid, 'Preset: %s\n', res.caseName);
fprintf(fid, 'Detail: %s\n', res.caseNameDetail);
fprintf(fid, 'Inertia: [%g %g %g]\n', res.inertia(1), res.inertia(2), res.inertia(3));

if strcmp(res.mode, 'fixed')
    fprintf(fid, 'Mass: %g\n', res.mass);
    fprintf(fid, 'Body vector r_C: [%g %g %g]\n', res.rCBody(1), res.rCBody(2), res.rCBody(3));
end

fprintf(fid, '\nTime span\n');
fprintf(fid, 't0 = %g\n', res.t(1));
fprintf(fid, 'tf = %g\n', res.t(end));
fprintf(fid, 'samples = %d\n', numel(res.t));

fprintf(fid, '\nInitial body omega\n');
fprintf(fid, '[%g %g %g]\n', res.omegaBody(1,1), res.omegaBody(1,2), res.omegaBody(1,3));

fprintf(fid, '\nInitial inertial omega\n');
fprintf(fid, '[%g %g %g]\n', res.omegaInertial(1,1), res.omegaInertial(1,2), res.omegaInertial(1,3));

fprintf(fid, '\nFinal body omega\n');
fprintf(fid, '[%g %g %g]\n', res.omegaBody(end,1), res.omegaBody(end,2), res.omegaBody(end,3));

fprintf(fid, '\nFinal inertial omega\n');
fprintf(fid, '[%g %g %g]\n', res.omegaInertial(end,1), res.omegaInertial(end,2), res.omegaInertial(end,3));

if strcmp(res.mode, 'free')
    fprintf(fid, '\nFree-rotation invariants\n');
    fprintf(fid, 'E = %g\n', res.E);
    fprintf(fid, '|L| = %g\n', res.Lmag);
    fprintf(fid, 'case = %s\n', res.caseNameDetail);
    fprintf(fid, 'period = %g\n', res.period);
    fprintf(fid, 'elliptic m = %g\n', res.m);
    fprintf(fid, 'frequency scale nu = %g\n', res.nu);
else
    fprintf(fid, '\nFixed-point energy statistics\n');
    fprintf(fid, 'E(t0) = %g\n', res.E(1));
    fprintf(fid, 'E(tf) = %g\n', res.E(end));
    fprintf(fid, 'min(E) = %g\n', min(res.E));
    fprintf(fid, 'max(E) = %g\n', max(res.E));
    fprintf(fid, '|L(t0)| = %g\n', res.Lmag(1));
    fprintf(fid, '|L(tf)| = %g\n', res.Lmag(end));
end
end
