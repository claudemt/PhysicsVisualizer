function start_rigid_body_demo()
%START_RIGID_BODY_DEMO Convenience alias.
rigid_body_main();
end
