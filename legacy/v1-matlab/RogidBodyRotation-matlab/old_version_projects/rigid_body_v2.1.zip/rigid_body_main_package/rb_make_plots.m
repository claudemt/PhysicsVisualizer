function figInfo = rb_make_plots(ax, res)
%RB_MAKE_PLOTS Render all seven previews.
figInfo = repmat(struct('filename',''), 7, 1);
for k = 1:7
    figInfo(k) = rb_plot_index(ax(k), res, k);
end
end
