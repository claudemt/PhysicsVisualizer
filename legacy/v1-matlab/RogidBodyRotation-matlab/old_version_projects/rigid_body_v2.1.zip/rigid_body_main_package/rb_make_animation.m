function [filename, filepath] = rb_make_animation(res, outputFolder, showFigure)
%RB_MAKE_ANIMATION Create the requested inertial-frame animation.
%
% If outputFolder is empty, no file is written and a visible figure is shown.
% If showFigure is true, a visible figure is used for playback.

if nargin < 2
    outputFolder = "";
end
if nargin < 3
    showFigure = false;
end

writeFile = strlength(string(outputFolder)) > 0;
filename = "";
filepath = "";

if showFigure
    fig = figure('Color', 'w', 'Name', 'Rigid Body Animation', 'Position', [120 80 980 760]);
else
    fig = figure('Visible', 'off', 'Color', 'w', 'Position', [120 80 980 760]);
end

ax = axes(fig);
hold(ax, 'on'); grid(ax, 'on'); box(ax, 'on');
axis(ax, 'equal');
view(ax, 3);
xlabel(ax, '$x$', 'Interpreter', 'latex');
ylabel(ax, '$y$', 'Interpreter', 'latex');
zlabel(ax, '$z$', 'Interpreter', 'latex');
title(ax, 'Body axes, $\boldsymbol{\omega}$, and $\mathbf{L}$ in the inertial frame', 'Interpreter', 'latex');

omegaI = res.omegaInertial;
LI = res.LInertial;
R = res.R;
n = numel(res.t);

scale = max([vecnorm(omegaI,2,2); vecnorm(LI,2,2); 1]);
lim = 1.15 * scale;
xlim(ax, [-lim lim]); ylim(ax, [-lim lim]); zlim(ax, [-lim lim]);

plot3(ax, omegaI(:,1), omegaI(:,2), omegaI(:,3), '--', 'LineWidth', 0.8, 'HandleVisibility','off');
plot3(ax, LI(:,1), LI(:,2), LI(:,3), ':', 'LineWidth', 0.8, 'HandleVisibility','off');

hx = quiver3(ax, 0,0,0, 1,0,0, 0, 'LineWidth', 2.0, 'DisplayName', '$\hat{\mathbf e}_1$');
hy = quiver3(ax, 0,0,0, 0,1,0, 0, 'LineWidth', 2.0, 'DisplayName', '$\hat{\mathbf e}_2$');
hz = quiver3(ax, 0,0,0, 0,0,1, 0, 'LineWidth', 2.0, 'DisplayName', '$\hat{\mathbf e}_3$');

hw = quiver3(ax, 0,0,0, omegaI(1,1), omegaI(1,2), omegaI(1,3), 0, ...
    'LineWidth', 2.4, 'MaxHeadSize', 0.35, 'DisplayName', '$\boldsymbol{\omega}$');
hL = quiver3(ax, 0,0,0, LI(1,1), LI(1,2), LI(1,3), 0, ...
    'LineWidth', 2.4, 'MaxHeadSize', 0.35, 'DisplayName', '$\mathbf{L}$');

legend(ax, 'Interpreter', 'latex', 'Location', 'northeastoutside');

if writeFile
    try
        filename = '08_animation.mp4';
        filepath = fullfile(outputFolder, filename);
        vw = VideoWriter(filepath, 'MPEG-4');
        vw.FrameRate = 30;
        open(vw);
    catch
        filename = '08_animation.avi';
        filepath = fullfile(outputFolder, filename);
        vw = VideoWriter(filepath, 'Motion JPEG AVI');
        vw.FrameRate = 30;
        open(vw);
    end
else
    vw = [];
end

nFrame = min(n, 360);
idx = unique(round(linspace(1, n, nFrame)));

for j = 1:numel(idx)
    k = idx(j);
    Rk = R(:,:,k);

    e1 = Rk(1,:).';
    e2 = Rk(2,:).';
    e3 = Rk(3,:).';

    set(hx, 'UData', e1(1)*scale*0.55, 'VData', e1(2)*scale*0.55, 'WData', e1(3)*scale*0.55);
    set(hy, 'UData', e2(1)*scale*0.55, 'VData', e2(2)*scale*0.55, 'WData', e2(3)*scale*0.55);
    set(hz, 'UData', e3(1)*scale*0.55, 'VData', e3(2)*scale*0.55, 'WData', e3(3)*scale*0.55);

    set(hw, 'UData', omegaI(k,1), 'VData', omegaI(k,2), 'WData', omegaI(k,3));
    set(hL, 'UData', LI(k,1), 'VData', LI(k,2), 'WData', LI(k,3));

    title(ax, sprintf('Body axes, $\\boldsymbol{\\omega}$, and $\\mathbf{L}$ in the inertial frame, $t=%.3f$', res.t(k)), ...
        'Interpreter', 'latex');

    drawnow;
    if writeFile
        frame = getframe(fig);
        writeVideo(vw, frame);
    elseif showFigure
        pause(0.02);
    end
end

if writeFile
    close(vw);
end

if ~showFigure
    close(fig);
end
end
