function outInfo = rb_export_outputs(res, outputRoot)
%RB_EXPORT_OUTPUTS Export 7 PNG figures, 1 animation video, and 1 parameter text file.

if nargin < 2 || strlength(string(outputRoot)) == 0
    here = fileparts(which('rigid_body_main'));
    outputRoot = fullfile(here, 'rigid_body_main_output');
end

timestamp = datestr(now, 'yyyymmdd_HHMMSS');
outputFolder = fullfile(char(outputRoot), timestamp);
if ~isfolder(outputFolder)
    mkdir(outputFolder);
end

files = strings(0,1);

for k = 1:7
    fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 980 760]);
    ax = axes(fig);
    rb_plot_index(ax, res, k);
    set(ax, 'FontSize', 13, 'LineWidth', 1.0);
    drawnow;
    info = rb_plot_index(ax, res, k);
    fpath = fullfile(outputFolder, info.filename);
    exportgraphics(ax, fpath, 'Resolution', 180);
    files(end+1,1) = string(info.filename); %#ok<AGROW>
    close(fig);
end

[paramName, paramPath] = rb_write_parameters(res, outputFolder);
files(end+1,1) = string(paramName);

[videoName, ~] = rb_make_animation(res, outputFolder, false);
files(end+1,1) = string(videoName);

outInfo = struct();
outInfo.outputFolder = outputFolder;
outInfo.files = cellstr(files);
outInfo.parameterFile = paramPath;
end
