function out = rb_simulate_free_exact(p)
%RB_SIMULATE_FREE_EXACT Exact free rigid-body body-rate formulas + kinematic reconstruction.
%
% Required fields
%   p.I        = [I1 I2 I3], with I1 <= I2 <= I3
%   p.w0       = [w1(0) w2(0) w3(0)]
%   p.phi0     = initial phi
%   p.tEnd
%   p.nSamples

I = p.I(:).';
w0 = p.w0(:).';
I1 = I(1); I2 = I(2); I3 = I(3);

E = 0.5*(I1*w0(1)^2 + I2*w0(2)^2 + I3*w0(3)^2);
L2 = (I1*w0(1))^2 + (I2*w0(2))^2 + (I3*w0(3))^2;
L = sqrt(L2);

if L <= 1e-14 || E <= 1e-14
    error('Initial angular velocity cannot be identically zero.');
end

t = linspace(0, p.tEnd, p.nSamples).';
w = zeros(numel(t), 3);

tol = 1e-10 * max([1, abs(L2), abs(2*E*I2)]);
tolSym = 1e-11 * max(I);
caseId = 0;
caseName = '';
period = NaN;
m = NaN;
nu = NaN;
phase0 = NaN;

if abs(I2 - I1) <= tolSym && abs(I3 - I2) > tolSym
    % Symmetric body with I1 = I2, exact formula from the lecture.
    caseId = 4;
    caseName = 'I_1 = I_2 symmetric body';
    Axy = hypot(w0(1), w0(2));
    alpha0 = atan2(w0(2), w0(1));
    Omega = w0(3) * (I3 - I1) / I1;
    w(:,1) = Axy * cos(Omega*t + alpha0);
    w(:,2) = Axy * sin(Omega*t + alpha0);
    w(:,3) = w0(3);
    nu = abs(Omega);
    if abs(Omega) > 1e-14
        period = 2*pi/abs(Omega);
    else
        period = inf;
    end
    phase0 = alpha0;

elseif abs(I3 - I2) <= tolSym
    error('The package currently supports the exact symmetric free case I1 = I2, not I2 = I3.');

else
    sepDelta = L2 - 2*E*I2;
    if abs(sepDelta) <= tol
        caseId = 3;
        caseName = 'L^2 = 2 E I_2';
        wSep = sqrt(2*E/I2);
        Omega = wSep * sqrt((I2-I1)*(I3-I2)/(I1*I3));

        A = wSep * sqrt(I2*(I3-I2)/(I1*(I3-I1)));
        C = wSep * sqrt(I2*(I2-I1)/(I3*(I3-I1)));

        s1 = local_safe_sign(w0(1));
        s3 = local_safe_sign(w0(3));
        s2 = local_safe_sign(w0(2));
        ratio = max(min(w0(2)/(s2*wSep), 1-1e-12), -1+1e-12);
        tau0 = atanh(ratio);
        tau = Omega*t + tau0;
        sechTau = 1./cosh(tau);

        w(:,1) = s1*A*sechTau;
        w(:,2) = s2*wSep*tanh(tau);
        w(:,3) = s3*C*sechTau;

        period = inf;
        m = 1.0;
        nu = Omega;
        phase0 = tau0;
    elseif sepDelta < 0
        caseId = 1;
        caseName = 'L^2 < 2 E I_2';

        A = sqrt((2*E*I3 - L2)/(I1*(I3-I1)));
        B = sqrt((L2 - 2*E*I1)/(I2*(I2-I1)));
        C = sqrt((L2 - 2*E*I1)/(I3*(I3-I1)));
        m = ((I3-I2)*(L2 - 2*E*I1))/((I2-I1)*(2*E*I3 - L2));
        m = local_clamp(m, 0, 1-1e-12);
        nu = sqrt((I2-I1)*(2*E*I3 - L2)/(I1*I2*I3));
        s1 = local_safe_sign(w0(1));
        phase0 = local_fit_phase_case1(w0, A, B, C, m, s1);

        u = nu*t + phase0;
        [sn, cn, dn] = ellipj(u, m);

        w(:,1) = s1*A*dn;
        w(:,2) = s1*B*sn;
        w(:,3) = C*cn;

        K = ellipke(m);
        period = 4*K/nu;
    else
        caseId = 2;
        caseName = 'L^2 > 2 E I_2';

        A = sqrt((2*E*I3 - L2)/(I1*(I3-I1)));
        B = sqrt((2*E*I3 - L2)/(I2*(I3-I2)));
        C = sqrt((L2 - 2*E*I1)/(I3*(I3-I1)));
        m = ((I2-I1)*(2*E*I3 - L2))/((I3-I2)*(L2 - 2*E*I1));
        m = local_clamp(m, 0, 1-1e-12);
        nu = sqrt((I3-I2)*(L2 - 2*E*I1)/(I1*I2*I3));
        s3 = local_safe_sign(w0(3));
        phase0 = local_fit_phase_case2(w0, A, B, C, m, s3);

        u = nu*t + phase0;
        [sn, cn, dn] = ellipj(u, m);

        w(:,1) = A*cn;
        w(:,2) = s3*B*sn;
        w(:,3) = s3*C*dn;

        K = ellipke(m);
        period = 4*K/nu;
    end
end

Lbody = [I1*w(:,1), I2*w(:,2), I3*w(:,3)];

theta0 = acos(local_clamp((I3*w0(3))/L, -1, 1));
psi0 = atan2(I1*w0(1), I2*w0(2));
R = local_reconstruct_rotation(t, w, p.phi0, theta0, psi0);

omegaXYZ = zeros(numel(t), 3);
Lxyz = zeros(numel(t), 3);
for k = 1:numel(t)
    omegaXYZ(k,:) = (R(:,:,k)' * w(k,:).').';
    Lxyz(k,:) = (R(:,:,k)' * Lbody(k,:).').';
end

euler = zeros(numel(t), 3);
for k = 1:numel(t)
    euler(k,:) = local_inverse_euler_313x(R(:,:,k));
end
euler(:,1) = unwrap(euler(:,1));
euler(:,3) = unwrap(euler(:,3));

Echeck = 0.5*(I1*w(:,1).^2 + I2*w(:,2).^2 + I3*w(:,3).^2);
Lcheck = sqrt(sum(Lbody.^2,2));
driftE = max(abs(Echeck - E))/max(abs(E),1);
driftL = max(abs(Lcheck - L))/max(abs(L),1);

out = struct();
out.mode = 'free';
out.caseName = p.caseName;
out.t = t;
out.omegaBody = w;
out.omegaInertial = omegaXYZ;
out.LBody = Lbody;
out.LInertial = Lxyz;
out.R = R;
out.euler = euler;
out.inertia = I;
out.mass = NaN;
out.rCBody = [NaN NaN NaN];
out.E = E;
out.Lmag = L;
out.caseId = caseId;
out.caseNameDetail = caseName;
out.period = period;
out.phase0 = phase0;
out.nu = nu;
out.m = m;
out.summaryLine = sprintf('Free rotation, %s, E = %.6g, |L| = %.6g', caseName, E, L);
out.parameters = struct( ...
    'mode', 'free', ...
    'caseName', p.caseName, ...
    'I', I, ...
    'w0', w0, ...
    'phi0', p.phi0, ...
    'tEnd', p.tEnd, ...
    'nSamples', p.nSamples, ...
    'E', E, ...
    'Lmag', L, ...
    'caseNameDetail', caseName, ...
    'period', period, ...
    'phase0', phase0, ...
    'm', m, ...
    'nu', nu, ...
    'maxRelativeDriftE', driftE, ...
    'maxRelativeDriftL', driftL);
end

function R = local_reconstruct_rotation(t, wBody, phi0, theta0, psi0)
n = numel(t);
R = zeros(3,3,n);
R(:,:,1) = rb_passive_rotm_313x(phi0, theta0, psi0);
R(:,:,1) = rb_orthonormalize_rows(R(:,:,1));
for k = 1:n-1
    dt = t(k+1) - t(k);
    wMid = 0.5*(wBody(k,:) + wBody(k+1,:));
    ang = norm(wMid) * dt;
    if ang < 1e-14
        A = eye(3);
    else
        u = wMid(:) / norm(wMid);
        K = rb_skew(u);
        A = eye(3) - sin(ang)*K + (1-cos(ang))*(K*K);
    end
    R(:,:,k+1) = rb_orthonormalize_rows(A * R(:,:,k));
end
end

function e = local_inverse_euler_313x(R)
theta = acos(local_clamp(R(3,3), -1, 1));
s = sin(theta);
if abs(s) < 1e-10
    phi = atan2(R(1,2), R(1,1));
    psi = 0;
else
    phi = atan2(R(3,1), -R(3,2));
    psi = atan2(R(1,3), R(2,3));
end
e = [phi, theta, psi];
end

function s = local_safe_sign(x)
if x < 0
    s = -1;
else
    s = 1;
end
end

function y = local_clamp(x, lo, hi)
y = min(max(x, lo), hi);
end

function u0 = local_fit_phase_case1(w0, A, B, C, m, s1)
K = ellipke(m);
uGrid = linspace(0, 4*K, 4001);
[sn, cn, dn] = ellipj(uGrid, m);
err = (s1*A*dn - w0(1)).^2 + (s1*B*sn - w0(2)).^2 + (C*cn - w0(3)).^2;
[~, idx] = min(err);
left = uGrid(max(1, idx-2));
right = uGrid(min(numel(uGrid), idx+2));
fun = @(u) local_phase_err_case1(u, w0, A, B, C, m, s1);
if right > left
    u0 = fminbnd(fun, left, right);
else
    u0 = uGrid(idx);
end
if u0 > 2*K
    u0 = u0 - 4*K;
end
end

function val = local_phase_err_case1(u, w0, A, B, C, m, s1)
[sn, cn, dn] = ellipj(u, m);
val = (s1*A*dn - w0(1)).^2 + (s1*B*sn - w0(2)).^2 + (C*cn - w0(3)).^2;
end

function u0 = local_fit_phase_case2(w0, A, B, C, m, s3)
K = ellipke(m);
uGrid = linspace(0, 4*K, 4001);
[sn, cn, dn] = ellipj(uGrid, m);
err = (A*cn - w0(1)).^2 + (s3*B*sn - w0(2)).^2 + (s3*C*dn - w0(3)).^2;
[~, idx] = min(err);
left = uGrid(max(1, idx-2));
right = uGrid(min(numel(uGrid), idx+2));
fun = @(u) local_phase_err_case2(u, w0, A, B, C, m, s3);
if right > left
    u0 = fminbnd(fun, left, right);
else
    u0 = uGrid(idx);
end
if u0 > 2*K
    u0 = u0 - 4*K;
end
end

function val = local_phase_err_case2(u, w0, A, B, C, m, s3)
[sn, cn, dn] = ellipj(u, m);
val = (A*cn - w0(1)).^2 + (s3*B*sn - w0(2)).^2 + (s3*C*dn - w0(3)).^2;
end
