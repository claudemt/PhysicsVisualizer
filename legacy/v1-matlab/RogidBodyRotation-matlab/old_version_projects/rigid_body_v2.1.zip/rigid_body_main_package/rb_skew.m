function S = rb_skew(v)
%RB_SKEW Cross-product matrix.
v = v(:);
S = [   0   -v(3)  v(2); ...
      v(3)    0   -v(1); ...
     -v(2)  v(1)    0   ];
end
