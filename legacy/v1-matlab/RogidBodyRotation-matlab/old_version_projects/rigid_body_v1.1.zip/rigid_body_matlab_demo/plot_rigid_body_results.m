function plot_rigid_body_results(result, p)
%PLOT_RIGID_BODY_RESULTS  统一画出课堂最需要的几类图

    t = result.t;
    w = result.omegaB;
    euler = result.euler;
    E = result.E;
    Lnorm = result.Lnorm;
    Delta = result.Delta;

    idxMin = result.idxMin;
    idxMid = result.idxMid;
    idxMax = result.idxMax;

    % ---- 图 1：四组时间序列 ----
    figure('Name', ['Rigid Body Time Series - ' p.displayName], 'Color', 'w');
    subplot(2,2,1);
    plot(t, w(:,1), 'LineWidth', 1.2); hold on;
    plot(t, w(:,2), 'LineWidth', 1.2);
    plot(t, w(:,3), 'LineWidth', 1.2);
    grid on;
    xlabel('t');
    ylabel('\omega_i');
    legend('\omega_1', '\omega_2', '\omega_3', 'Location', 'best');
    title('体坐标中的角速度分量');

    subplot(2,2,2);
    plot(t, euler(:,1), 'LineWidth', 1.2); hold on;
    plot(t, euler(:,2), 'LineWidth', 1.2);
    plot(t, euler(:,3), 'LineWidth', 1.2);
    grid on;
    xlabel('t');
    ylabel('angle (rad)');
    legend('\phi', '\theta', '\psi', 'Location', 'best');
    title('欧拉角（3-1-3）');

    subplot(2,2,3);
    plot(t, E / E(1), 'LineWidth', 1.3); hold on;
    plot(t, Lnorm / Lnorm(1), 'LineWidth', 1.3);
    grid on;
    xlabel('t');
    ylabel('normalized value');
    legend('E / E_0', '|L| / |L_0|', 'Location', 'best');
    title('能量与角动量模长');

    subplot(2,2,4);
    plot(t, Delta, 'LineWidth', 1.3); hold on;
    plot([t(1), t(end)], [0, 0], 'k--');
    grid on;
    xlabel('t');
    ylabel('\Delta = |L|^2 - 2 E I_{mid}');
    title(sprintf('分界指标（中间惯量轴 = %d）', idxMid));

    annotation('textbox', [0.13, 0.01, 0.78, 0.06], ...
               'String', sprintf(['%s | stable axes: %d (min inertia), %d (max inertia); ' ...
                                  'unstable axis: %d (middle inertia)'], ...
                                  p.displayName, idxMin, idxMax, idxMid), ...
               'FitBoxToText', 'on', 'EdgeColor', 'none');

    % ---- 图 2：omega 在体坐标中的轨迹 ----
    figure('Name', ['Omega Trajectory - ' p.displayName], 'Color', 'w');
    plot3(w(:,1), w(:,2), w(:,3), 'LineWidth', 1.5); hold on;
    plot3(w(1,1), w(1,2), w(1,3), 'o', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot3(w(end,1), w(end,2), w(end,3), 's', 'MarkerSize', 8, 'LineWidth', 1.5);
    grid on;
    axis equal;
    xlabel('\omega_1');
    ylabel('\omega_2');
    zlabel('\omega_3');
    title('体坐标中 \omega 的轨迹（Poinsot 直观图）');

    if p.c1 == 0 && p.c2 == 0 && isempty(p.torqueFcn)
        draw_quadrics(result, p);
        legend('\omega(t)', 'start', 'end', 'E = const ellipsoid', '|L| = const ellipsoid', ...
               'Location', 'best');
    else
        legend('\omega(t)', 'start', 'end', 'Location', 'best');
    end
    view(40, 24);

    % ---- 图 3：单位球上的体轴轨迹 ----
    figure('Name', ['Body Axes on Unit Sphere - ' p.displayName], 'Color', 'w');
    [sx, sy, sz] = sphere(40);
    surf(sx, sy, sz, 'FaceAlpha', 0.05, 'EdgeAlpha', 0.2, 'FaceColor', [0.9, 0.9, 0.9]); hold on;

    axis1 = squeeze(result.axisTips(:, :, 1));
    axis2 = squeeze(result.axisTips(:, :, 2));
    axis3 = squeeze(result.axisTips(:, :, 3));

    plot3(axis1(:,1), axis1(:,2), axis1(:,3), 'LineWidth', 1.3);
    plot3(axis2(:,1), axis2(:,2), axis2(:,3), 'LineWidth', 1.3);
    plot3(axis3(:,1), axis3(:,2), axis3(:,3), 'LineWidth', 1.5);

    Lden = repmat(max(result.Lnorm, eps), 1, 3);
    Ln = result.LI ./ Lden;
    if max(max(Ln, [], 1) - min(Ln, [], 1)) < 1e-6
        plot3(Ln(1,1), Ln(1,2), Ln(1,3), 'kp', 'MarkerSize', 10, 'LineWidth', 1.5);
        legend('unit sphere', 'axis 1 tip', 'axis 2 tip', 'axis 3 tip', 'fixed L direction', ...
               'Location', 'best');
    else
        plot3(Ln(:,1), Ln(:,2), Ln(:,3), 'k--', 'LineWidth', 1.2);
        legend('unit sphere', 'axis 1 tip', 'axis 2 tip', 'axis 3 tip', 'L direction', ...
               'Location', 'best');
    end

    plot3(axis1(1,1), axis1(1,2), axis1(1,3), 'o', 'LineWidth', 1.2);
    plot3(axis3(1,1), axis3(1,2), axis3(1,3), 'o', 'LineWidth', 1.2);
    grid on;
    axis equal;
    xlabel('x');
    ylabel('y');
    zlabel('z');
    title('体轴在惯性系单位球上的轨迹');
    view(42, 20);
end

function draw_quadrics(result, p)
    E0 = result.E(1);
    L0 = result.Lnorm(1);

    [sx, sy, sz] = sphere(36);

    aE = sqrt(2 * E0 / p.I(1));
    bE = sqrt(2 * E0 / p.I(2));
    cE = sqrt(2 * E0 / p.I(3));

    aL = L0 / p.I(1);
    bL = L0 / p.I(2);
    cL = L0 / p.I(3);

    surf(aE * sx, bE * sy, cE * sz, 'FaceAlpha', 0.08, 'EdgeAlpha', 0.08, ...
         'FaceColor', [0.2, 0.5, 1.0], 'EdgeColor', [0.2, 0.5, 1.0]);
    surf(aL * sx, bL * sy, cL * sz, 'FaceAlpha', 0.08, 'EdgeAlpha', 0.08, ...
         'FaceColor', [1.0, 0.5, 0.2], 'EdgeColor', [1.0, 0.5, 0.2]);
end
