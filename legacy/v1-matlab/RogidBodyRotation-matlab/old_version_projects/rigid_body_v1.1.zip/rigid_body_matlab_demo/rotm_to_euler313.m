function [phi, theta, psi] = rotm_to_euler313(R)
%ROTM_TO_EULER313  从方向余弦矩阵提取讲义中的 3-1-3 欧拉角
%
% 约定：
%   [x1hat; x2hat; x3hat] = R * [xhat; yhat; zhat]
%
% 一般情形：
%   cos(theta) = R(3,3)
%   tan(phi)   = R(3,1) / (-R(3,2))
%   tan(psi)   = R(1,3) / R(2,3)
%
% 在 theta = 0 或 pi 处会出现欧拉角奇异；这里做了一个简单处理：
%   令 phi = 0，把总绕 z 轴的转角并到 psi 中。

    r33 = max(-1, min(1, R(3,3)));
    theta = acos(r33);

    sth = sin(theta);
    tol = 1e-10;

    if abs(sth) > tol
        phi = atan2(R(3,1), -R(3,2));
        psi = atan2(R(1,3), R(2,3));
    else
        phi = 0;
        if r33 > 0
            % theta ~ 0, 只有 psi + phi 有意义，此处并到 psi
            psi = atan2(R(1,2), R(1,1));
        else
            % theta ~ pi, 只有 psi - phi 有意义，此处并到 psi
            psi = atan2(-R(1,2), -R(1,1));
        end
    end
end
