%RUN_DEMO_EXAMPLES  一键运行若干典型案例
%
% 说明：每个案例之间会停一下，方便你和学生讨论。

close all; clc;

disp('案例 1：非对称刚体自由转动');
p = get_preset_case('free_asymmetric');
main_rigid_body_demo(p);
disp('按任意键继续到案例 2 ...');
pause;

disp('案例 2：中间惯量轴不稳定（网球拍定理）');
p = get_preset_case('intermediate_unstable');
main_rigid_body_demo(p);
disp('按任意键继续到案例 3 ...');
pause;

disp('案例 3：线性阻尼');
p = get_preset_case('linear_drag');
main_rigid_body_demo(p);
disp('按任意键继续到案例 4 ...');
pause;

disp('案例 4：临界分支扫描');
p = get_preset_case('separatrix_scan');
main_rigid_body_demo(p);
disp('示例结束。');
