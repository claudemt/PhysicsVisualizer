function dydt = rigid_body_rhs(t, y, p)
%RIGID_BODY_RHS  刚体欧拉方程 + 姿态矩阵演化
%
% 状态：
%   y = [w1; w2; w3; R(:)]
% 其中 R 把惯性系坐标变换到体坐标：v_body = R * v_inertial

    I = p.I(:);
    w = y(1:3);
    R = reshape(y(4:end), 3, 3);

    tau = drag_torque(w, p);

    if ~isempty(p.torqueFcn)
        tauExtra = p.torqueFcn(t, w, R, p);
        tau = tau + reshape(tauExtra, 3, 1);
    end

    wdot = zeros(3, 1);
    wdot(1) = ((I(2) - I(3)) / I(1)) * w(2) * w(3) + tau(1) / I(1);
    wdot(2) = ((I(3) - I(1)) / I(2)) * w(3) * w(1) + tau(2) / I(2);
    wdot(3) = ((I(1) - I(2)) / I(3)) * w(1) * w(2) + tau(3) / I(3);

    Rdot = -skew3(w) * R;

    dydt = [wdot; Rdot(:)];
end
