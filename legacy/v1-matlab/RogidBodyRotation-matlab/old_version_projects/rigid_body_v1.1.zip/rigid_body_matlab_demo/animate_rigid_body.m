function animate_rigid_body(result, p)
%ANIMATE_RIGID_BODY  3D 动画：把主惯量对应成“等效均匀椭球”并显示其转动
%
% 这个动画对学生最直观：
% 1) 黑色箭头表示角动量 L 在空间中的方向（自由转动时应几乎固定）。
% 2) 红/绿/蓝线分别是刚体的 1/2/3 号主轴。
% 3) 体轴相对 L 的进动与章动，会让“欧拉角不是抽象符号”这件事变得很清楚。

    [a, b, c] = inertia_to_ellipsoid_axes(p.I);
    scale = p.bodyScale / max([a, b, c, eps]);
    a = a * scale;
    b = b * scale;
    c = c * scale;

    [xs, ys, zs] = sphere(24);
    Xb = a * xs;
    Yb = b * ys;
    Zb = c * zs;

    figure('Name', ['Animation - ' p.displayName], 'Color', 'w');
    axis equal;
    grid on;
    view(36, 22);
    hold on;
    xlabel('x'); ylabel('y'); zlabel('z');
    title(['3D 动画 - ' p.displayName]);

    lim = 1.6 * max([a, b, c, max(result.Lnorm / max(result.Lnorm(1), eps))]);
    xlim([-lim, lim]); ylim([-lim, lim]); zlim([-lim, lim]);

    surfHandle = [];
    ax1 = [];
    ax2 = [];
    ax3 = [];
    hL = [];
    hw = [];

    skip = max(1, round(p.animationSkip));
    for k = 1:skip:numel(result.t)
        Rk = result.R(:, :, k);
        P = Rk' * [Xb(:)'; Yb(:)'; Zb(:)'];
        X = reshape(P(1, :), size(Xb));
        Y = reshape(P(2, :), size(Yb));
        Z = reshape(P(3, :), size(Zb));

        e1 = Rk'(:, 1) * a;
        e2 = Rk'(:, 2) * b;
        e3 = Rk'(:, 3) * c;

        Lvec = result.LI(k, :).';
        wvec = result.omegaI(k, :).';

        if isempty(surfHandle)
            surfHandle = surf(X, Y, Z, 'FaceAlpha', 0.45, 'EdgeAlpha', 0.12, ...
                              'FaceColor', [0.7, 0.8, 1.0], 'EdgeColor', [0.5, 0.5, 0.5]);
            ax1 = plot3([0, e1(1)], [0, e1(2)], [0, e1(3)], 'r-', 'LineWidth', 2.0);
            ax2 = plot3([0, e2(1)], [0, e2(2)], [0, e2(3)], 'g-', 'LineWidth', 2.0);
            ax3 = plot3([0, e3(1)], [0, e3(2)], [0, e3(3)], 'b-', 'LineWidth', 2.2);
            hL = plot3([0, Lvec(1)], [0, Lvec(2)], [0, Lvec(3)], 'k-', 'LineWidth', 2.4);
            hw = plot3([0, wvec(1)], [0, wvec(2)], [0, wvec(3)], 'm--', 'LineWidth', 1.8);
            legend('body', 'axis 1', 'axis 2', 'axis 3', 'L', '\omega', 'Location', 'best');
        else
            set(surfHandle, 'XData', X, 'YData', Y, 'ZData', Z);
            set(ax1, 'XData', [0, e1(1)], 'YData', [0, e1(2)], 'ZData', [0, e1(3)]);
            set(ax2, 'XData', [0, e2(1)], 'YData', [0, e2(2)], 'ZData', [0, e2(3)]);
            set(ax3, 'XData', [0, e3(1)], 'YData', [0, e3(2)], 'ZData', [0, e3(3)]);
            set(hL, 'XData', [0, Lvec(1)], 'YData', [0, Lvec(2)], 'ZData', [0, Lvec(3)]);
            set(hw, 'XData', [0, wvec(1)], 'YData', [0, wvec(2)], 'ZData', [0, wvec(3)]);
        end

        drawnow;
    end
end

function [a, b, c] = inertia_to_ellipsoid_axes(I)
% 假设单位质量的均匀椭球：
% I1 = (b^2 + c^2) / 5, I2 = (a^2 + c^2) / 5, I3 = (a^2 + b^2) / 5
% 反解得：
% a^2 = 5/2 * (I2 + I3 - I1), 等等

    I = I(:);
    a2 = 2.5 * (I(2) + I(3) - I(1));
    b2 = 2.5 * (I(1) + I(3) - I(2));
    c2 = 2.5 * (I(1) + I(2) - I(3));

    a = sqrt(max(a2, 0));
    b = sqrt(max(b2, 0));
    c = sqrt(max(c2, 0));

    if any([a, b, c] < 1e-12)
        % 极端情况下给一个最小厚度，避免图形退化
        a = max(a, 0.1);
        b = max(b, 0.1);
        c = max(c, 0.1);
    end
end
