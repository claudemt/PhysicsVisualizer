function R = euler313_to_rotm(phi, theta, psi)
%EULER313_TO_ROTM  讲义中的 3-1-3 欧拉角到方向余弦矩阵
%
% 满足：
%   [x1hat; x2hat; x3hat] = R * [xhat; yhat; zhat]

    cphi = cos(phi);
    sphi = sin(phi);
    cth = cos(theta);
    sth = sin(theta);
    cpsi = cos(psi);
    spsi = sin(psi);

    R = [ cpsi * cphi - spsi * sphi * cth,   sphi * cpsi + cth * cphi * spsi,   sth * spsi;
         -spsi * cphi - cpsi * sphi * cth,  -sphi * spsi + cth * cphi * cpsi,   sth * cpsi;
          sth * sphi,                       -sth * cphi,                         cth      ];
end
