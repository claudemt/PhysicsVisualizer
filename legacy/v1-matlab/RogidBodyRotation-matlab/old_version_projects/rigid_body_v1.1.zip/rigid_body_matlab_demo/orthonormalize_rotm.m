function R = orthonormalize_rotm(R)
%ORTHONORMALIZE_ROTM  用 SVD 把数值积分得到的矩阵重新投影到 SO(3)

    [U, ~, V] = svd(R);
    M = eye(3);
    if det(U * V') < 0
        M(3,3) = -1;
    end
    R = U * M * V';
end
