function tau = torque_custom_template(t, w, R, p)
%TORQUE_CUSTOM_TEMPLATE  自定义外力矩模板
%
% 用法示例：
%   p = get_preset_case('free_asymmetric');
%   p.torqueFcn = @torque_custom_template;
%   main_rigid_body_demo(p);
%
% 输入：
%   t  - 当前时间
%   w  - 当前体坐标角速度列向量 [w1; w2; w3]
%   R  - 当前方向余弦矩阵，满足 v_body = R * v_inertial
%   p  - 参数结构体
%
% 返回：
%   tau - 体坐标中的外力矩列向量 [tau1; tau2; tau3]
%
% 下面给一个很弱的周期驱动力矩作为示例。
% 你也可以改成重力矩、控制力矩、磁力矩等。

tau = [0.03 * cos(0.6 * t);
       0.00;
       0.00];
end
