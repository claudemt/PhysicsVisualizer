function result = main_rigid_body_demo(p)
%MAIN_RIGID_BODY_DEMO  刚体转动教学演示主函数
%
%   result = main_rigid_body_demo()
%   result = main_rigid_body_demo(p)
%
% 推荐第一次直接运行：
%   main_rigid_body_demo
%
% 也可以用结构体传参：
%   p = get_preset_case('intermediate_unstable');
%   p.makeAnimation = true;
%   result = main_rigid_body_demo(p);
%
% 主要输入字段：
%   p.I        = [I1 I2 I3] 主惯量（对应体坐标主轴）
%   p.w0       = [w10 w20 w30] 初始角速度（体坐标分量）
%   p.euler0   = [phi0 theta0 psi0] 初始欧拉角，采用讲义中的 3-1-3 约定
%   p.c1       = 线性阻尼系数，tau = -c1 * omega
%   p.c2       = 二次阻尼系数，tau = -c2 * |omega| * omega
%   p.tEnd     = 积分终止时间
%   p.nSteps   = 采样点数
%   p.makeAnimation = 是否播放 3D 动画
%   p.doBranchScan  = 是否执行临界分支扫描
%   p.torqueFcn     = 自定义外力矩函数句柄 tau = f(t,w,R,p)
%
% 输出 result 包含：
%   result.t, result.omegaB, result.omegaI
%   result.euler (phi, theta, psi)
%   result.E, result.Lnorm, result.Delta
%   result.R, result.LI, result.axisTips
%
% 注：
% 1) 这里的动力学积分采用欧拉方程 + 方向余弦矩阵，而不是直接对欧拉角积分，
%    这样数值上更稳健，也避免在 theta = 0 或 pi 附近出现假奇异。
% 2) 对学生教学时，建议先看 omega_i(t)、E(t)、|L|(t)、Delta(t)，
%    再看欧拉角；最后再看 3D 动画和单位球上的体轴轨迹。

    if nargin < 1 || isempty(p)
        p = interactive_setup();
    end

    p = complete_params(p);

    result = simulate_rigid_body(p);

    plot_rigid_body_results(result, p);
    print_summary(result, p);

    if p.makeAnimation
        animate_rigid_body(result, p);
    end

    if p.doBranchScan
        result.branchScan = scan_branch_near_separatrix(p);
    end
end

function p = interactive_setup()
    clc;
    disp('===========================================================');
    disp(' 刚体转动教学演示（MATLAB）');
    disp('===========================================================');
    disp(' 1. 非对称刚体的自由转动');
    disp(' 2. 中间惯量轴不稳定（网球拍定理）');
    disp(' 3. 线性阻尼：tau = -c1 * omega');
    disp(' 4. 二次阻尼：tau = -c2 * |omega| * omega');
    disp(' 5. 临界分支扫描（靠近分界面）');
    disp(' 6. 旋转对称刚体的稳定进动');
    s = input('请选择预设案例编号 [2]: ', 's');
    if isempty(s)
        s = '2';
    end

    switch str2double(s)
        case 1
            p = get_preset_case('free_asymmetric');
        case 2
            p = get_preset_case('intermediate_unstable');
        case 3
            p = get_preset_case('linear_drag');
        case 4
            p = get_preset_case('quadratic_drag');
        case 5
            p = get_preset_case('separatrix_scan');
        case 6
            p = get_preset_case('symmetric_top');
        otherwise
            warning('未识别编号，自动使用“中间惯量轴不稳定”预设。');
            p = get_preset_case('intermediate_unstable');
    end

    disp(' ');
    disp('按回车可直接接受默认值。');
    p.I = ask_vector('输入主惯量 [I1 I2 I3]', p.I);
    p.w0 = ask_vector('输入初始角速度 [w10 w20 w30]', p.w0);
    p.euler0 = ask_vector('输入初始欧拉角 [phi0 theta0 psi0] (rad)', p.euler0);
    p.tEnd = ask_scalar('输入仿真总时长 tEnd', p.tEnd);
    p.nSteps = round(ask_scalar('输入采样点数 nSteps', p.nSteps));
    p.c1 = ask_scalar('输入线性阻尼系数 c1', p.c1);
    p.c2 = ask_scalar('输入二次阻尼系数 c2', p.c2);

    s = input(sprintf('是否播放 3D 动画? y/n [%s]: ', yn(p.makeAnimation)), 's');
    if ~isempty(s)
        p.makeAnimation = strcmpi(s, 'y');
    end

    s = input(sprintf('是否做临界分支扫描? y/n [%s]: ', yn(p.doBranchScan)), 's');
    if ~isempty(s)
        p.doBranchScan = strcmpi(s, 'y');
    end
end

function x = ask_scalar(prompt, defaultValue)
    s = input(sprintf('%s [%.6g]: ', prompt, defaultValue), 's');
    if isempty(s)
        x = defaultValue;
    else
        x = str2double(s);
        if isnan(x)
            warning('输入无效，使用默认值。');
            x = defaultValue;
        end
    end
end

function v = ask_vector(prompt, defaultValue)
    fmt = sprintf('%.6g ', defaultValue);
    s = input(sprintf('%s [%s]: ', prompt, strtrim(fmt)), 's');
    if isempty(s)
        v = defaultValue;
        return;
    end
    tmp = str2num(s); %#ok<ST2NM>
    if numel(tmp) ~= numel(defaultValue)
        warning('输入维数不对，使用默认值。');
        v = defaultValue;
    else
        v = reshape(tmp, 1, []);
    end
end

function s = yn(flag)
    if flag
        s = 'y';
    else
        s = 'n';
    end
end

function print_summary(result, p)
    I = p.I(:);
    [Is, idx] = sort(I);
    idxMin = idx(1);
    idxMid = idx(2);
    idxMax = idx(3);

    fprintf('\n================ 仿真摘要 ================\n');
    fprintf('案例名称：%s\n', p.displayName);
    fprintf('主惯量：I = [%.6g, %.6g, %.6g]\n', I(1), I(2), I(3));
    fprintf('最小/中间/最大惯量轴索引 = [%d, %d, %d]\n', idxMin, idxMid, idxMax);
    fprintf('按大小排序后的惯量 = [%.6g, %.6g, %.6g]\n', Is(1), Is(2), Is(3));
    fprintf('初始角速度 w0 = [%.6g, %.6g, %.6g]\n', p.w0(1), p.w0(2), p.w0(3));
    fprintf('初始能量 E0 = %.8g\n', result.E(1));
    fprintf('初始角动量模长 |L0| = %.8g\n', result.Lnorm(1));
    fprintf('初始 separatrix 指标 Delta0 = L^2 - 2 E I_mid = %.8g\n', result.Delta(1));

    if abs(result.Delta(1)) < 1e-8 * max(1, abs(result.Lnorm(1))^2)
        fprintf('解释：初始条件非常接近分界面（separatrix）。\n');
    elseif result.Delta(1) > 0
        fprintf('解释：自由转动时更接近“最大惯量轴族”。\n');
    else
        fprintf('解释：自由转动时更接近“最小惯量轴族”。\n');
    end

    if p.c1 == 0 && p.c2 == 0 && isempty(p.torqueFcn)
        fprintf('本次是自由转动：理论上 E 与 |L| 应保持常数。\n');
    else
        fprintf('本次含阻尼/外力矩：E 与 |L| 一般不再守恒。\n');
        fprintf('探测时刻的分支指标 branchMetric = %.6g\n', result.branchMetric);
        if result.branchMetric > 0
            fprintf('探测结果：更偏向最大惯量轴分支。\n');
        elseif result.branchMetric < 0
            fprintf('探测结果：更偏向最小惯量轴分支。\n');
        else
            fprintf('探测结果：非常接近临界态，或探测时刻尚不足以区分。\n');
        end
    end

    fprintf('建议学生先看图 1 的四个时间序列，再看 3D 图和动画。\n');
    fprintf('==========================================\n\n');
end
