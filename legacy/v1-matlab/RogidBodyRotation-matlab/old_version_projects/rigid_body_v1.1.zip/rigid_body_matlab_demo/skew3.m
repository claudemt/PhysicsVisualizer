function S = skew3(v)
%SKEW3  由三维向量构造反对称矩阵，使得 S*x = v x x

    v = v(:);
    S = [   0,   -v(3),  v(2);
          v(3),    0,   -v(1);
         -v(2),  v(1),    0  ];
end
