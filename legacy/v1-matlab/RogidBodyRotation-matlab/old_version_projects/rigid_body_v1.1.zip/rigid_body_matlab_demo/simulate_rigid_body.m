function result = simulate_rigid_body(p)
%SIMULATE_RIGID_BODY  积分刚体欧拉方程，并在后处理中计算可视化量

    p = complete_params(p);

    R0 = euler313_to_rotm(p.euler0(1), p.euler0(2), p.euler0(3));
    y0 = [p.w0(:); R0(:)];

    tGrid = linspace(0, p.tEnd, p.nSteps);
    opts = odeset('RelTol', p.RelTol, 'AbsTol', p.AbsTol);

    [t, y] = ode45(@(tt, yy) rigid_body_rhs(tt, yy, p), tGrid, y0, opts);

    n = numel(t);
    omegaB = y(:, 1:3);
    R = zeros(3, 3, n);
    omegaI = zeros(n, 3);
    LB = zeros(n, 3);
    LI = zeros(n, 3);
    axisTips = zeros(n, 3, 3);  % (time, xyz, axisIndex)
    phi = zeros(n, 1);
    theta = zeros(n, 1);
    psi = zeros(n, 1);

    for k = 1:n
        Rk = reshape(y(k, 4:end), 3, 3);
        Rk = orthonormalize_rotm(Rk);
        R(:, :, k) = Rk;

        wk = omegaB(k, :).';
        LBk = p.I(:) .* wk;
        LIk = Rk' * LBk;
        omegaIk = Rk' * wk;

        LB(k, :) = LBk.';
        LI(k, :) = LIk.';
        omegaI(k, :) = omegaIk.';

        axisTips(k, :, 1) = Rk'(:, 1).';
        axisTips(k, :, 2) = Rk'(:, 2).';
        axisTips(k, :, 3) = Rk'(:, 3).';

        [phi(k), theta(k), psi(k)] = rotm_to_euler313(Rk);
    end

    phi = unwrap(phi);
    psi = unwrap(psi);

    E = 0.5 * (p.I(1) * omegaB(:, 1).^2 + p.I(2) * omegaB(:, 2).^2 + p.I(3) * omegaB(:, 3).^2);
    Lnorm = sqrt(sum(LB.^2, 2));
    omegaNorm = sqrt(sum(omegaB.^2, 2));

    [~, idxSorted] = sort(p.I);
    idxMin = idxSorted(1);
    idxMid = idxSorted(2);
    idxMax = idxSorted(3);

    Delta = Lnorm.^2 - 2 * E * p.I(idxMid);

    probeIdx = find(omegaNorm <= p.probeFraction * max(omegaNorm(1), eps), 1, 'first');
    if isempty(probeIdx)
        probeIdx = max(2, round(0.65 * n));
    end
    branchMetric = abs(omegaB(probeIdx, idxMax)) - abs(omegaB(probeIdx, idxMin));

    result = struct();
    result.t = t;
    result.omegaB = omegaB;
    result.omegaI = omegaI;
    result.omegaNorm = omegaNorm;
    result.R = R;
    result.LB = LB;
    result.LI = LI;
    result.Lnorm = Lnorm;
    result.E = E;
    result.Delta = Delta;
    result.euler = [phi, theta, psi];
    result.axisTips = axisTips;
    result.idxMin = idxMin;
    result.idxMid = idxMid;
    result.idxMax = idxMax;
    result.probeIdx = probeIdx;
    result.branchMetric = branchMetric;
end
