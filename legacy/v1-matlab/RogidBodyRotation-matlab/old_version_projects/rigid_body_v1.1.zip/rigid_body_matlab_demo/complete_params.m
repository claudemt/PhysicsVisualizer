function p = complete_params(p)
%COMPLETE_PARAMS  补齐参数结构体中的默认字段

    if nargin < 1 || isempty(p)
        p = struct();
    end

    p = set_default(p, 'I', [1, 2, 3]);
    p = set_default(p, 'w0', [0.03, 2.2, 0.01]);
    p = set_default(p, 'euler0', [0.2, 0.9, 0.1]);  % [phi0 theta0 psi0]
    p = set_default(p, 'tEnd', 30);
    p = set_default(p, 'nSteps', 1600);
    p = set_default(p, 'RelTol', 1e-9);
    p = set_default(p, 'AbsTol', 1e-9);
    p = set_default(p, 'c1', 0);
    p = set_default(p, 'c2', 0);
    p = set_default(p, 'makeAnimation', false);
    p = set_default(p, 'doBranchScan', false);
    p = set_default(p, 'torqueFcn', []);
    p = set_default(p, 'caseName', 'custom');
    p = set_default(p, 'displayName', p.caseName);
    p = set_default(p, 'probeFraction', 0.7);   % 速度衰减到初值的多少时用来判断“分支”
    p = set_default(p, 'bodyScale', 1.0);
    p = set_default(p, 'animationSkip', 5);

    p.I = reshape(p.I, 1, []);
    p.w0 = reshape(p.w0, 1, []);
    p.euler0 = reshape(p.euler0, 1, []);

    if numel(p.I) ~= 3
        error('p.I 必须是长度为 3 的向量。');
    end
    if numel(p.w0) ~= 3
        error('p.w0 必须是长度为 3 的向量。');
    end
    if numel(p.euler0) ~= 3
        error('p.euler0 必须是长度为 3 的向量。');
    end
    if any(p.I <= 0)
        error('主惯量必须都为正。');
    end
    if p.tEnd <= 0
        error('p.tEnd 必须为正。');
    end
    if p.nSteps < 50
        error('p.nSteps 太小，建议至少 50。');
    end

    if ~isfield(p, 'branchScan') || isempty(p.branchScan)
        p.branchScan = struct();
    end

    bs = p.branchScan;
    [~, idxSorted] = sort(p.I);
    idxMin = idxSorted(1);
    idxMid = idxSorted(2);
    idxMax = idxSorted(3);

    bs = set_default(bs, 'omegaMid', max(1.0, abs(p.w0(idxMid))));
    bs = set_default(bs, 'epsMin', 0.06);
    bs = set_default(bs, 'deltaMax', 0.08);
    bs = set_default(bs, 'nScan', 31);
    bs = set_default(bs, 'useDampingClassifier', (p.c1 ~= 0 || p.c2 ~= 0 || ~isempty(p.torqueFcn)));
    bs = set_default(bs, 'showExampleTrajectories', true);
    bs = set_default(bs, 'timeProbeFraction', p.probeFraction);

    % 由 Delta = 0 推得的临界扰动
    crit = sqrt(p.I(idxMin) * (p.I(idxMid) - p.I(idxMin)) / ...
               (p.I(idxMax) * (p.I(idxMax) - p.I(idxMid))));
    bs = set_default(bs, 'criticalRatioWmaxToWmin', crit);

    p.branchScan = bs;
end

function s = set_default(s, name, value)
    if ~isfield(s, name) || isempty(s.(name))
        s.(name) = value;
    end
end
