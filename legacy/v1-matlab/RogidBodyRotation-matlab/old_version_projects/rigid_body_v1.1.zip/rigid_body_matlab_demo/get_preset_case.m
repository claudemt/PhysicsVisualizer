function p = get_preset_case(caseName)
%GET_PRESET_CASE  返回若干适合课堂展示的预设案例
%
% 可选 caseName:
%   'free_asymmetric'
%   'intermediate_unstable'
%   'linear_drag'
%   'quadratic_drag'
%   'separatrix_scan'
%   'symmetric_top'

    if nargin < 1 || isempty(caseName)
        caseName = 'intermediate_unstable';
    end

    switch lower(caseName)
        case 'free_asymmetric'
            p.caseName = 'free_asymmetric';
            p.displayName = '非对称刚体的自由转动';
            p.I = [1.0, 1.8, 3.0];
            p.w0 = [0.55, 0.20, 1.35];
            p.euler0 = [0.3, 0.8, 0.2];
            p.tEnd = 32;
            p.nSteps = 1800;
            p.c1 = 0;
            p.c2 = 0;
            p.makeAnimation = false;
            p.doBranchScan = false;

        case 'intermediate_unstable'
            p.caseName = 'intermediate_unstable';
            p.displayName = '中间惯量轴不稳定（网球拍定理）';
            p.I = [1.0, 2.0, 3.0];
            p.w0 = [0.04, 2.2, 0.01];
            p.euler0 = [0.2, 0.9, 0.1];
            p.tEnd = 30;
            p.nSteps = 1800;
            p.c1 = 0;
            p.c2 = 0;
            p.makeAnimation = false;
            p.doBranchScan = false;

        case 'linear_drag'
            p.caseName = 'linear_drag';
            p.displayName = '线性阻尼：tau = -c1 * omega';
            p.I = [1.0, 2.0, 3.0];
            p.w0 = [0.04, 2.2, 0.01];
            p.euler0 = [0.2, 0.9, 0.1];
            p.tEnd = 45;
            p.nSteps = 2200;
            p.c1 = 0.08;
            p.c2 = 0;
            p.makeAnimation = false;
            p.doBranchScan = false;

        case 'quadratic_drag'
            p.caseName = 'quadratic_drag';
            p.displayName = '二次阻尼：tau = -c2 * |omega| * omega';
            p.I = [1.0, 2.0, 3.0];
            p.w0 = [0.04, 2.2, 0.01];
            p.euler0 = [0.2, 0.9, 0.1];
            p.tEnd = 24;
            p.nSteps = 1800;
            p.c1 = 0;
            p.c2 = 0.06;
            p.makeAnimation = false;
            p.doBranchScan = false;

        case 'separatrix_scan'
            p.caseName = 'separatrix_scan';
            p.displayName = '临界分支扫描（靠近 separatrix）';
            p.I = [1.0, 2.0, 3.0];
            p.w0 = [0.06, 2.3, 0.01];
            p.euler0 = [0.2, 0.9, 0.1];
            p.tEnd = 35;
            p.nSteps = 1800;
            p.c1 = 0.02;
            p.c2 = 0;
            p.makeAnimation = false;
            p.doBranchScan = true;
            p.branchScan = struct('omegaMid', 2.3, ...
                                  'epsMin', 0.06, ...
                                  'deltaMax', 0.08, ...
                                  'nScan', 31);

        case 'symmetric_top'
            p.caseName = 'symmetric_top';
            p.displayName = '旋转对称刚体的稳定进动';
            p.I = [1.2, 1.2, 2.8];
            p.w0 = [0.80, 0.00, 3.60];
            p.euler0 = [0.2, 0.6, 0.1];
            p.tEnd = 18;
            p.nSteps = 1400;
            p.c1 = 0;
            p.c2 = 0;
            p.makeAnimation = false;
            p.doBranchScan = false;

        otherwise
            error('未知预设案例：%s', caseName);
    end

    p = complete_params(p);
end
