function tau = drag_torque(w, p)
%DRAG_TORQUE  简化阻尼模型
%
%   tau = -c1 * w - c2 * |w| * w
%
% 说明：
% 1) 这是很适合课堂演示的“各向同性外阻尼力矩”模型。
% 2) 它使 dE/dt = tau · w <= 0，因此能量单调下降。
% 3) 但它是外力矩，不会保持总角动量守恒；长期看会把转动全部耗散掉。
% 4) 若想演示“固定 |L| 下的耗散趋向最大惯量轴”，可进一步自定义 torqueFcn。

    wn = sqrt(sum(w.^2));
    tau = -p.c1 * w - p.c2 * wn * w;
end
