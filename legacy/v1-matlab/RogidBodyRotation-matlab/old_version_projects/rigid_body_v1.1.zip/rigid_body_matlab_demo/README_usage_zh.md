# 刚体转动 MATLAB 教学包

这个文件夹的目标不是“把讲义公式再抄一遍”，而是把公式变成 **学生一眼能看懂的时间序列、几何图像和动画**。

## 文件结构

- `main_rigid_body_demo.m`  
  交互式主函数。第一次用它就够了。

- `get_preset_case.m`  
  预设几个最适合课堂演示的案例。

- `simulate_rigid_body.m`  
  数值积分 + 后处理，生成 `omega`、欧拉角、能量、角动量、体轴轨迹等。

- `rigid_body_rhs.m`  
  欧拉方程的右端；如果以后要加重力矩、控制力矩、磁力矩，主要改这里。

- `drag_torque.m`  
  阻尼模型：  
  `tau = -c1 * omega - c2 * |omega| * omega`

- `euler313_to_rotm.m` / `rotm_to_euler313.m`  
  讲义里的欧拉角与方向余弦矩阵互转（3-1-3 约定）。

- `plot_rigid_body_results.m`  
  统一出图：  
  `omega_i(t)`、欧拉角、`E(t)`、`|L|(t)`、`\Delta(t)`、`omega` 的 3D 轨迹、体轴在单位球上的轨迹。

- `animate_rigid_body.m`  
  3D 动画。对学生最直观。

- `scan_branch_near_separatrix.m`  
  靠近临界面时做参数扫描，演示“极小初值差异 -> 完全不同分支”。

## 推荐课堂顺序

### 第 1 步：先让学生看“守恒量几何”，不要先讲椭圆函数
对于自由刚体，先看两件事：

1. 能量  
   `E = 1/2 (I1 w1^2 + I2 w2^2 + I3 w3^2)`

2. 角动量模长  
   `|L|^2 = I1^2 w1^2 + I2^2 w2^2 + I3^2 w3^2`

在 `omega` 空间里：
- `E = const` 是一个椭球
- `|L| = const` 也是一个椭球
- 刚体真实运动就是这两个曲面的交线

这比直接给 `sn/cn/dn` 更容易形成直觉。

### 第 2 步：再讲“哪根轴稳定，哪根轴不稳定”
对 `I_min < I_mid < I_max` 的非对称刚体：
- 纯绕最小惯量轴转动：稳定
- 纯绕最大惯量轴转动：稳定
- 纯绕中间惯量轴转动：不稳定

在代码里，这个分界量写成
`Delta = |L|^2 - 2 E I_mid`

- `Delta < 0`：更接近最小惯量轴那一族
- `Delta > 0`：更接近最大惯量轴那一族
- `Delta = 0`：临界分界面（separatrix）

### 第 3 步：最后再让学生看欧拉角
欧拉角是“结果描述”，不是最适合入门的第一视角。
建议先看：
- `w1(t), w2(t), w3(t)`
- `E(t), |L|(t), Delta(t)`
- 体轴在惯性系单位球上的轨迹
- 3D 动画

等学生已经知道“身体怎么翻、哪根轴在绕谁进动”之后，再回去看 `phi, theta, psi`。

## 最简运行方式

### 方式 A：完全交互式
在 MATLAB 当前目录切换到本文件夹后，直接运行：

```matlab
main_rigid_body_demo
```

### 方式 B：用预设案例
```matlab
p = get_preset_case('intermediate_unstable');
main_rigid_body_demo(p);
```

### 方式 C：自己给参数
```matlab
p.I = [1 2 3];
p.w0 = [0.04 2.2 0.01];
p.euler0 = [0.2 0.9 0.1];
p.c1 = 0.05;
p.c2 = 0.00;
p.tEnd = 40;
p.nSteps = 2000;
p.makeAnimation = true;
p.doBranchScan = false;

main_rigid_body_demo(p);
```

## 最值得演示的四个案例

### 1) 非对称自由转动
```matlab
main_rigid_body_demo(get_preset_case('free_asymmetric'));
```
学生会看到：
- `E` 和 `|L|` 近似严格守恒
- `omega` 在固定曲线上运动
- 欧拉角有明显的进动/章动结构

### 2) 中间惯量轴不稳定（网球拍定理）
```matlab
main_rigid_body_demo(get_preset_case('intermediate_unstable'));
```
学生会看到：
- 明明初始几乎沿 2 轴转，后来却突然“翻过去”
- 不是数值错误，而是动力学本来就不稳定

### 3) 加线性或二次阻尼
```matlab
main_rigid_body_demo(get_preset_case('linear_drag'));
main_rigid_body_demo(get_preset_case('quadratic_drag'));
```
学生会看到：
- `E(t)` 明显下降
- `|L|(t)` 也会下降（因为这是外阻尼力矩）
- 轨迹不再闭合，而是往内螺旋

### 4) 临界分支扫描
```matlab
main_rigid_body_demo(get_preset_case('separatrix_scan'));
```
学生会看到：
- 一个非常小的初始扰动变化，就会把系统送到另一边分支
- 这正是“临界状态附近非常敏感”的最直接图像

## 关于阻尼模型的教学提醒

这里用的是
`tau = -c1 * omega - c2 * |omega| * omega`

它的优点是：
- 简单
- 物理意义清楚
- 可立即看出 `dE/dt = tau · omega < 0`

但它是 **外力矩**，所以：
- 总角动量一般不守恒
- 长时间后会把整体转动都耗散掉

如果你想讲“内部耗散但总角动量近似守恒”的版本，可以在 `rigid_body_rhs.m` 里改成你自己的 `torqueFcn`。

## 如何把它讲成“物理”而不是“公式”

最有效的话术通常不是“我们现在解一个非线性常微分方程”，而是：

1. **学生先猜**
   - “你觉得绕长轴、短轴、中间轴，哪个最稳？”
   - “加一点点扰动之后会怎样？”

2. **先给图，不先给结论**
   - 让学生先看 `omega_i(t)` 和动画
   - 让他们自己说出“2 轴附近会翻”

3. **再回到守恒量**
   - 为什么 1 轴/3 轴稳定而 2 轴不稳定？
   - 因为 `E=const` 与 `|L|=const` 的交线在几何上就不同

4. **最后再连到讲义公式**
   - 讲义把自由转动分成  
     `L^2 < 2 E I2`、`L^2 = 2 E I2`、`L^2 > 2 E I2`
   - 你的数值图像正好把这三类情况可视化了

## 可继续扩展的方向

这套代码已经给你一个很稳的“骨架”，以后可以直接扩展：

- 加定点约束与重力矩（重对称陀螺）
- 加磁力矩、电力矩或控制力矩
- 加参数扫描热图
- 保存动画为视频/GIF
- 把不同初值的结果排成多图比较
- 加解析解与数值解的对照
