function scanResult = scan_branch_near_separatrix(p)
%SCAN_BRANCH_NEAR_SEPARATRIX
% 在中间惯量轴附近做一维扫描，演示“极小扰动差异导致不同分支”
%
% 设计思想：
% 设初始角速度主要沿中间惯量轴：
%   w0 = eps * e_min + Omega_mid * e_mid + wmax * e_max
%
% 对自由刚体，分界面由 Delta = |L|^2 - 2 E I_mid = 0 给出。
% 把上式代入上面的初值，立刻得到一个临界比值：
%   |wmax / eps|_crit = sqrt( I_min (I_mid - I_min) / [ I_max (I_max - I_mid) ] )
%
% 扫描 wmax = wmax_crit + delta，就能非常直观地演示
% “从最小惯量轴族切换到最大惯量轴族”的分界过程。
%
% 若 p 含阻尼，则这里用“在速度衰减到某个比例时，哪一轴更占主导”作为分支判据。

    p = complete_params(p);
    bs = p.branchScan;

    I = p.I(:);
    [~, idx] = sort(I);
    idxMin = idx(1);
    idxMid = idx(2);
    idxMax = idx(3);

    epsMin = bs.epsMin;
    omegaMid = bs.omegaMid;
    crit = epsMin * bs.criticalRatioWmaxToWmin;
    deltaList = linspace(-bs.deltaMax, bs.deltaMax, bs.nScan);

    Delta0 = zeros(bs.nScan, 1);
    outcome = zeros(bs.nScan, 1);
    family = zeros(bs.nScan, 1);

    sampleNeg = [];
    sampleZero = [];
    samplePos = [];

    for k = 1:bs.nScan
        pk = p;
        pk.doBranchScan = false;
        pk.makeAnimation = false;

        w0 = zeros(1, 3);
        w0(idxMin) = epsMin;
        w0(idxMid) = omegaMid;
        w0(idxMax) = crit + deltaList(k);
        pk.w0 = w0;

        rk = simulate_rigid_body(pk);

        Delta0(k) = rk.Delta(1);

        if bs.useDampingClassifier
            outcome(k) = rk.branchMetric;
        else
            outcome(k) = Delta0(k);
        end

        family(k) = sign(outcome(k));

        if k == 1
            sampleNeg = rk;
        elseif k == ceil(bs.nScan / 2)
            sampleZero = rk;
        elseif k == bs.nScan
            samplePos = rk;
        end
    end

    figure('Name', ['Separatrix Scan - ' p.displayName], 'Color', 'w');

    subplot(2,2,1);
    plot(deltaList, Delta0, 'o-', 'LineWidth', 1.2);
    hold on;
    plot([deltaList(1), deltaList(end)], [0, 0], 'k--');
    grid on;
    xlabel('\delta in w_{max}(0)');
    ylabel('\Delta_0 = |L_0|^2 - 2 E_0 I_{mid}');
    title('初始点相对分界面的哪一侧');

    subplot(2,2,2);
    stem(deltaList, family, 'filled', 'LineWidth', 1.2);
    grid on;
    xlabel('\delta in w_{max}(0)');
    ylabel('branch');
    set(gca, 'YTick', [-1, 0, 1]);
    set(gca, 'YTickLabel', {'min-axis family', 'critical', 'max-axis family'});
    title('分支判据输出');

    subplot(2,2,3);
    hold on;
    if ~isempty(sampleNeg)
        plot(sampleNeg.t, sampleNeg.omegaB(:, idxMid), 'LineWidth', 1.2);
    end
    if ~isempty(sampleZero)
        plot(sampleZero.t, sampleZero.omegaB(:, idxMid), 'LineWidth', 1.2);
    end
    if ~isempty(samplePos)
        plot(samplePos.t, samplePos.omegaB(:, idxMid), 'LineWidth', 1.2);
    end
    grid on;
    xlabel('t');
    ylabel(sprintf('\\omega_{%d}', idxMid));
    title('三个代表性样本的中间轴分量');
    legend('\delta < 0', '\delta \approx 0', '\delta > 0', 'Location', 'best');

    subplot(2,2,4);
    hold on;
    if ~isempty(sampleNeg)
        plot3(sampleNeg.omegaB(:,1), sampleNeg.omegaB(:,2), sampleNeg.omegaB(:,3), 'LineWidth', 1.2);
    end
    if ~isempty(sampleZero)
        plot3(sampleZero.omegaB(:,1), sampleZero.omegaB(:,2), sampleZero.omegaB(:,3), 'LineWidth', 1.2);
    end
    if ~isempty(samplePos)
        plot3(samplePos.omegaB(:,1), samplePos.omegaB(:,2), samplePos.omegaB(:,3), 'LineWidth', 1.2);
    end
    grid on;
    axis equal;
    xlabel('\omega_1');
    ylabel('\omega_2');
    zlabel('\omega_3');
    title('\omega 空间中的三条代表轨迹');
    view(38, 22);

    annotation('textbox', [0.11, 0.01, 0.82, 0.08], 'EdgeColor', 'none', ...
               'String', sprintf(['eps = %.4g, Omega_mid = %.4g, critical ratio w_{max}/w_{min} = %.6g. ', ...
                                  '当扫描穿过 delta = 0 附近时，系统会从最小惯量轴族切换到最大惯量轴族。'], ...
                                  epsMin, omegaMid, bs.criticalRatioWmaxToWmin));

    scanResult = struct();
    scanResult.deltaList = deltaList;
    scanResult.Delta0 = Delta0;
    scanResult.outcome = outcome;
    scanResult.family = family;
    scanResult.criticalWmax = crit;
end
